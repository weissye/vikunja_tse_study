"""CLI for OpenAPI-only verifier/concurrency generation."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

from .parsing.loader import load_and_resolve, load_raw
from .parsing.normalize import normalize
from .verification import derive_verification
from .render.verification_js import render_verification_js


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="openapi_to_sbt.verification_cli")
    parser.add_argument("--openapi", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--max-field-pairs", type=int, default=6)
    parser.add_argument("--fail-on-contract-only", action="store_true")
    args = parser.parse_args(argv)
    source = Path(args.openapi)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    try:
        resolved, unsupported = load_and_resolve(str(source))
        raw = load_raw(str(source))
        doc = normalize(resolved, raw)
        result = derive_verification(doc, source.read_bytes(), max(1, args.max_field_pairs))
        result["unsupported_refs"] = unsupported
        manifest = out / f"verification-manifest.{args.name}.json"
        coverage = out / f"verifier-coverage.{args.name}.json"
        concurrency = out / f"concurrency-plan.{args.name}.json"
        verification_js = out / f"verification.{args.name}.js"
        manifest.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        coverage.write_text(json.dumps({
            "schema_version": 1, "source": result["source"], "policy": result["policy"],
            "counts": result["counts"], "coverage_complete": result["coverage_complete"],
            "manual_assumptions": result["manual_assumptions"],
            "mutation_coverage": result["mutation_coverage"],
        }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        concurrency.write_text(json.dumps({
            "schema_version": 1, "source": result["source"], "policy": result["policy"],
            "oracles": result["concurrency_oracles"],
        }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        verification_js.write_text(render_verification_js(result, args.name), encoding="utf-8")
    except Exception as exc:
        print(f"ERROR: verifier generation failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps({"name": args.name, **result["counts"],
                      "coverage_complete": result["coverage_complete"]}, sort_keys=True))
    print("OPENAPI_VERIFIER_GENERATION_PASS")
    if args.fail_on_contract_only and result["counts"]["contract_only_mutations"]:
        print("OPENAPI_VERIFIER_STATE_COVERAGE_INCOMPLETE")
        return 3
    return 0 if result["coverage_complete"] and not unsupported else 3


if __name__ == "__main__":
    raise SystemExit(main())
