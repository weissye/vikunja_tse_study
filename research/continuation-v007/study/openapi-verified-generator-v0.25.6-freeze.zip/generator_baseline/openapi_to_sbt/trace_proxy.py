"""Configurable authenticated proxy that preserves verifier-ready HTTP traces."""
from __future__ import annotations

import argparse
import http.client
import json
import os
import threading
import time
import urllib.parse
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

HOP_BY_HOP = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
              "te", "trailers", "transfer-encoding", "upgrade"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _decode(raw: bytes) -> Any:
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return raw.decode("utf-8", errors="replace")


def build_server(args: argparse.Namespace) -> ThreadingHTTPServer:
    target = urllib.parse.urlsplit(args.target)
    if target.scheme not in {"http", "https"} or not target.hostname:
        raise ValueError("--target must be an absolute HTTP(S) URL")
    target_port = target.port or (443 if target.scheme == "https" else 80)
    prefix = (target.path.rstrip("/") + "/" + args.api_prefix.strip("/")).rstrip("/")
    if prefix == "/":
        prefix = ""
    token = os.environ.get(args.bearer_token_env, "").strip() if args.bearer_token_env else ""
    if args.require_bearer_token and not token:
        raise ValueError(f"required bearer token environment variable is empty: {args.bearer_token_env}")
    trace_path = Path(args.trace)
    trace_path.parent.mkdir(parents=True, exist_ok=True)
    lock, sequence = threading.Lock(), {"value": 0}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self): self.forward()
        def do_POST(self): self.forward()
        def do_PUT(self): self.forward()
        def do_PATCH(self): self.forward()
        def do_DELETE(self): self.forward()
        def do_HEAD(self): self.forward()
        def do_OPTIONS(self): self.forward()
        def log_message(self, *_args): return

        def forward(self):
            received_utc, received_ns = _now(), time.perf_counter_ns()
            length = int(self.headers.get("Content-Length", "0") or 0)
            request_body = self.rfile.read(length) if length else b""
            headers = {k: v for k, v in self.headers.items()
                       if k.lower() not in HOP_BY_HOP and k.lower() not in {"host", "authorization"}}
            if token:
                headers["Authorization"] = f"Bearer {token}"
            model_path = self.path if self.path.startswith("/") else "/" + self.path
            upstream_path = prefix + model_path
            cls = http.client.HTTPSConnection if target.scheme == "https" else http.client.HTTPConnection
            connection = cls(target.hostname, target_port, timeout=args.timeout)
            status, response_body = 502, b""
            upstream_started_utc, upstream_started_ns = _now(), time.perf_counter_ns()
            try:
                connection.request(self.command, upstream_path, body=request_body, headers=headers)
                response = connection.getresponse()
                status, response_body = response.status, response.read()
                self.send_response(status)
                for key, value in response.getheaders():
                    if key.lower() not in HOP_BY_HOP and key.lower() != "content-length":
                        self.send_header(key, value)
                self.send_header("Content-Length", str(len(response_body)))
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(response_body)
            finally:
                upstream_completed_ns, upstream_completed_utc = time.perf_counter_ns(), _now()
                connection.close()
                event = {
                    "timestamp_utc": upstream_completed_utc,
                    "request_received_utc": received_utc,
                    "upstream_started_utc": upstream_started_utc,
                    "upstream_completed_utc": upstream_completed_utc,
                    "proxy_queue_ns": upstream_started_ns - received_ns,
                    "upstream_duration_ns": upstream_completed_ns - upstream_started_ns,
                    "method": self.command, "model_path": model_path,
                    "sut_path": upstream_path, "request": _decode(request_body),
                    "request_content_type": self.headers.get("Content-Type"),
                    "status": status, "response": _decode(response_body),
                    "epoch_id": self.headers.get("X-Provengo-Epoch-Id"),
                    "operation_id": self.headers.get("X-Provengo-Operation-Id"),
                    "request_id": self.headers.get("X-Request-ID"),
                    "proxy_worker": threading.current_thread().name,
                }
                with lock, trace_path.open("a", encoding="utf-8") as handle:
                    event["trace_sequence"] = sequence["value"]
                    sequence["value"] += 1
                    handle.write(json.dumps(event, sort_keys=True) + "\n")

    server = ThreadingHTTPServer((args.listen_host, args.listen_port), Handler)
    server.daemon_threads = True
    return server


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--listen-host", default="127.0.0.1")
    parser.add_argument("--listen-port", type=int, default=3457)
    parser.add_argument("--target", required=True)
    parser.add_argument("--api-prefix", default="")
    parser.add_argument("--trace", required=True)
    parser.add_argument("--bearer-token-env", default="")
    parser.add_argument("--require-bearer-token", action="store_true")
    parser.add_argument("--timeout", type=float, default=60.0)
    args = parser.parse_args(argv)
    server = build_server(args)
    print(f"OPENAPI_SBT_TRACE_PROXY_READY http://{args.listen_host}:{args.listen_port}", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
