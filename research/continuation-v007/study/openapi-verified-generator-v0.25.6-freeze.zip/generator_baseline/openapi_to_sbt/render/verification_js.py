"""Render a Provengo concurrency overlay from an OpenAPI-derived plan."""
from __future__ import annotations
import json
import re
from typing import Any, Dict, List


def _js(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _value(field: Dict[str, Any], suffix: str) -> Any:
    enum = field.get("enum") or []
    if enum:
        return enum[0 if suffix == "a" else min(1, len(enum) - 1)]
    kind = field.get("type")
    if kind == "string":
        return f"sbt_generated_{suffix}_{field['name']}"
    if kind == "boolean":
        return suffix == "a"
    low = field.get("minimum")
    high = field.get("maximum")
    base = int(low) if isinstance(low, (int, float)) else 1
    candidate = base if suffix == "a" else base + 1
    if isinstance(high, (int, float)):
        candidate = min(candidate, int(high))
    return candidate


def _safe(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]", "_", value)


def render_verification_js(derived: Dict[str, Any], name: str) -> str:
    executable = [o for o in derived["concurrency_oracles"]
                  if o.get("runtime", {}).get("ready") and o["kind"] != "update-delete-linearizable"]
    lines: List[str] = [
        "//@provengo summon rest",
        f"// OpenAPI-only generated verifier/concurrency overlay for {name}.",
        "// No application names, business rules, or hidden SUT facts are inputs.",
        'var sbtConcurrencyAdapterUrl = (typeof sbtConcurrencyAdapterUrl !== "undefined") ? sbtConcurrencyAdapterUrl : "http://127.0.0.1:3459";',
        'const __sbtAdapter = new RESTSession(sbtConcurrencyAdapterUrl, "sbt-generated-concurrency", {headers:{"Content-Type":"application/json"}});',
        f"const __sbtVerificationCoverage = {_js(derived['counts'])};",
        'bthread("sbt:verification-coverage", function(){ sync({request:Event("SBT:VerificationCoverageReady", __sbtVerificationCoverage)}); });',
        'function __sbtCreateEvent(entityKey){ return EventSet("SBT created resource", function(e){ return !!(e && e.name && e.name.indexOf("Done: ")===0 && e.data && e.data.__entityKey===entityKey && e.data.__httpResponse); }); }',
    ]
    for index, oracle in enumerate(executable):
        runtime, fields = oracle["runtime"], oracle["fields"]
        bodies = []
        if oracle["kind"] == "disjoint-writes-commute":
            suffixes = ["a", "b", "c", "d"]
            bodies = [{field["name"]: _value(field, suffixes[i])}
                      for i, field in enumerate(fields)]
        else:
            bodies = [{fields[0]["name"]: _value(fields[0], "a")},
                      {fields[0]["name"]: _value(fields[0], "b")}]
        ident = _safe(oracle["oracle_id"])
        binding = runtime["path_binding_from_create_response"]
        path_expr = _js(oracle["path_template"])
        lines.extend([
            f'bthread("sbt:concurrency:{ident}", function(){{',
            f'  var __created = sync({{waitFor:__sbtCreateEvent({_js(runtime["entity_key"])})}});',
            f'  sync({{request:Event("SBT:ConcurrencyReady:{index}",{{oracle_id:{_js(oracle["oracle_id"])}}})}});',
            f'  sync({{waitFor:Event("SBT:ConcurrencyPermit:{index}")}});',
            f'  var __path = {path_expr};',
        ])
        for parameter, response_field in binding.items():
            lines.append(f'  __path = __path.replace({_js("{" + parameter + "}")}, String(__created.data.__httpResponse[{_js(response_field)}]));')
        for parameter, request_parameter in runtime.get("path_binding_from_create_request_path", {}).items():
            lines.append(f'  __path = __path.replace({_js("{" + parameter + "}")}, String(__created.data[{_js(request_parameter)}]));')
        lines.extend([
            f'  var __bodies = {_js(bodies)};',
            '  var __baseline = null;',
            '  svc.get(__path,{expectedResponseCodes:[200],callback:function(r){try{__baseline=JSON.parse(r.body);}catch(e){__baseline=null;}}});',
        ])
        if oracle["method"] == "PUT":
            request_fields = [field["name"] for field in oracle.get("request_fields", [])]
            lines.extend([
                f'  var __requestFields = {_js(request_fields)};',
                '  for(var __m=0;__m<__bodies.length;__m++){var __full={}; for(var __n=0;__n<__requestFields.length;__n++){var __rf=__requestFields[__n]; if(__baseline && __baseline[__rf]!==undefined){__full[__rf]=__baseline[__rf];}} for(var __override in __bodies[__m]){__full[__override]=__bodies[__m][__override];} __bodies[__m]=__full;}',
            ])
        method_lower = oracle["method"].lower()
        media_type = oracle.get("media_type") or "application/json"
        lines.extend([
            f'  var __controlEpoch = "generated-control-{index}";',
            f'  for(var __i=0;__i<__bodies.length;__i++){{ svc.{method_lower}(__path,{{body:JSON.stringify(__bodies[__i]),headers:{{"Content-Type":{_js(media_type)},"X-Provengo-Epoch-Id":__controlEpoch,"X-Provengo-Operation-Id":__controlEpoch+"-op-"+__i}},expectedResponseCodes:' + _js(oracle["success_statuses"]) + '}); }',
            '  svc.get(__path,{headers:{"X-Provengo-Epoch-Id":__controlEpoch,"X-Provengo-Operation-Id":__controlEpoch+"-observe"},expectedResponseCodes:[200]});',
            f'  if(__baseline){{ var __reset={{}}; for(var __j=0;__j<__bodies.length;__j++){{for(var __f in __bodies[__j]){{if(__baseline[__f]!==undefined){{__reset[__f]=__baseline[__f];}}}}}} svc.{method_lower}(__path,{{body:JSON.stringify(__reset),headers:{{"Content-Type":{_js(media_type)}}},expectedResponseCodes:' + _js(oracle["success_statuses"]) + '}); }',
            f'  var __epoch = "generated-epoch-{index}";',
            '  var __ops=[]; for(var __k=0;__k<__bodies.length;__k++){__ops.push({operation_id:__epoch+"-op-"+__k,method:' + _js(oracle["method"]) + ',path:__path,body:__bodies[__k],delay_ms:0,headers:{"Content-Type":' + _js(media_type) + '}});}',
            f'  __sbtAdapter.post("/epochs",{{body:JSON.stringify({{epoch_id:__epoch,scenario:{_js(oracle["oracle_id"])},operations:__ops}}),expectedResponseCodes:[200]}});',
            '  svc.get(__path,{headers:{"X-Provengo-Epoch-Id":__epoch,"X-Provengo-Operation-Id":__epoch+"-observe"},expectedResponseCodes:[200]});',
            f'  sync({{request:Event("SBT:ConcurrencyClosed:{index}",{{oracle_id:{_js(oracle["oracle_id"])},path:__path}})}});',
            '});',
        ])
    lines.append('function __sbtNamedEvent(__name){ return EventSet("SBT named event "+__name,function(e){return !!(e&&e.name===__name);}); }')
    lines.append('function __sbtAnyConcurrencyReady(){ return EventSet("SBT any concurrency ready",function(e){return !!(e&&e.name&&e.name.indexOf("SBT:ConcurrencyReady:")===0);}); }')
    lines.append('function __sbtAnyHttpDelete(){ return EventSet("SBT any HTTP DELETE",function(e){return !!(e&&e.name==="DELETE");}); }')
    lines.append('function __sbtConcurrencyBusyBlock(){ return EventSet("SBT concurrency admission or cleanup",function(e){return !!(e&&e.name&&(e.name==="DELETE"||e.name.indexOf("SBT:ConcurrencyReady:")===0));}); }')
    lines.append('bthread("sbt:concurrency-controller",function(){')
    # Admit each runtime-ready oracle independently. Some OpenAPI-derived
    # oracles can remain unrealizable in a concrete run because their producer
    # resource was never created. A global all-ready barrier would therefore
    # deadlock every otherwise executable oracle. While one oracle is active,
    # block additional Ready events so their requests remain pending and are
    # consumed by the controller after the active oracle closes.
    lines.append(f'  var __readySeen={{}}; var __readyCount=0; var __readyTotal={len(executable)};')
    lines.append('  while(__readyCount<__readyTotal){')
    lines.append('    var __readyEvent=sync({waitFor:__sbtAnyConcurrencyReady(),block:__sbtAnyHttpDelete()});')
    lines.append('    if(__readySeen[__readyEvent.name]){continue;}')
    lines.append('    __readySeen[__readyEvent.name]=true; __readyCount++;')
    lines.append('    var __readyIndex=__readyEvent.name.substring("SBT:ConcurrencyReady:".length);')
    lines.append('    sync({request:Event("SBT:ConcurrencyPermit:"+__readyIndex),block:__sbtConcurrencyBusyBlock()});')
    # Closed includes diagnostic payload; match it by name. Keep other Ready
    # requests blocked until the active oracle has completed.
    lines.append('    sync({waitFor:__sbtNamedEvent("SBT:ConcurrencyClosed:"+__readyIndex),block:__sbtConcurrencyBusyBlock()});')
    lines.append('  }')
    lines.append('  sync({request:Event("SBT:AllGeneratedConcurrencyClosed")});')
    lines.append('});')
    return "\n".join(lines) + "\n"
