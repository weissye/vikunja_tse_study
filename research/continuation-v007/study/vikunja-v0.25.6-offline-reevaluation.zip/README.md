# Vikunja v0.25.6 Offline Re-evaluation

This archive preserves the evaluator-only correction applied to the immutable
final Vikunja evidence collected on 2026-09-23.

Source evidence ZIP SHA-256:
`f7cf5897a75b86efa429982c7ea68178c8dd258d505b414c9a38c9fc1c59fbda`

No HTTP request was repeated and no SUT state was changed. The original trace
and generated oracle manifest were evaluated with generator version 0.25.6.

Results:

- original: 72 INCONCLUSIVE, 121 PASS, 42 VIOLATED;
- corrected: 74 INCONCLUSIVE, 121 PASS, 40 VIOLATED;
- concurrency: 48 INCONCLUSIVE, 10 PASS, 0 VIOLATED.

`generated-epoch-34` and `generated-epoch-52` are now INCONCLUSIVE with reason
`sequential-control-state-mismatch`. Their sequential PUT/PATCH controls asked
for `bucket_id` 1 or 2 and received HTTP 200, but the independent GET observed
0. Therefore they cannot support a concurrency-defect claim.

The 40 remaining violations are contract-layer findings. The confirmed no-op
PATCH/HTTP-304 family is unchanged by this correction.
