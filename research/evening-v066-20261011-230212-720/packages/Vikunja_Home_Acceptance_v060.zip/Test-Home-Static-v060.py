import json,sys,tempfile
from pathlib import Path
from unittest.mock import patch
import run_home_v060 as launcher
with tempfile.TemporaryDirectory() as directory:
 root=Path(directory)
 with patch.object(sys,'argv',['test','--study-root',str(root),'--jar',str(root/'unused.jar')]):assert launcher.main()==0
 run=next((root/'runs').iterdir())
 assert len(list(run.glob('static-case-*')))==2
 assert json.loads((run/'result_v060.json').read_text())['live_execution'] is False
print('V060_HOME_STATIC_PASS: selected pair regenerated without Docker, authentication or live requests')
