"""Prepare explicitly shared owned research resources; no forbidden requests."""
import copy,json,re
import relation_engine_v060 as engine

def prepare(target,backend,recovery,auth_a,auth_b,run):
 capsule=copy.deepcopy(recovery['capsule']);records=[]
 def call(actor,method,path,body=None):
  token=(auth_a if actor=='A' else auth_b).ensure()
  status,payload=engine.request(target+path,method=method,body=body,token=token)
  try:response=json.loads(payload)
  except ValueError:response=None
  records.append(dict(actor=actor,method=method,path=path,status=status,request=body,response=response));engine.write(run/'shared-prefix-evidence-v060.json',records)
  if not 200<=status<300:raise RuntimeError('Shared setup not accepted: '+actor+' '+method+' '+path+' HTTP '+str(status))
  return response
 user_a=call('A','GET','/user');user_b=call('B','GET','/user')
 if not user_a.get('id') or not user_b.get('id') or user_a['id']==user_b['id']:raise ValueError('Two different authenticated users required')
 engine.write(run/'client-identities-v060.json',{'clients':{'A':{'id':user_a['id'],'username':user_a['username']},'B':{'id':user_b['id'],'username':user_b['username']}},'same_user':False,'true_concurrency':False})
 def route(r):return r['detail_template'].replace('{'+r['route_parameter']+'}',str(capsule['bindings']['ROUTE_'+re.sub('[^A-Za-z0-9_]','_',r['logicalId'])]))
 selected=[r for r in capsule['resources'] if r['resourceType'] in ('ModelsProject','ModelsTask')]
 def verify(r,actual):
  expected=r['expected']
  for key,value in expected.items():
   if isinstance(value,str) and re.fullmatch(r'@\{[A-Za-z0-9_]+\}',value):value=capsule['bindings'][value[2:-1]]
   if actual.get(key)!=value:raise ValueError('Shared setup projection differs: '+r['logicalId']+'/'+key)
 for r in capsule['resources']:verify(r,call('A','GET',route(r)))
 for r in selected:
  if r['resourceType']!='ModelsProject':continue
  path=route(r)+'/users';shares=call('A','GET',path+'?s='+user_b['username']+'&per_page=50')
  matches=[x for x in shares if x.get('username')==user_b['username']]
  if matches:
   if len(matches)!=1 or matches[0].get('permission')!=1:raise ValueError('Existing sharing differs; no permission overwritten')
  else:call('A','PUT',path,{'username':user_b['username'],'permission':1})
  shares=call('A','GET',path+'?s='+user_b['username']+'&per_page=50')
  if len([x for x in shares if x.get('username')==user_b['username'] and x.get('permission')==1])!=1:raise ValueError('Read & Write permission not independently verified')
 for r in selected:
  for actor in ('A','B'):verify(r,call(actor,'GET',route(r)))
  if r['resourceType']=='ModelsTask':
   body=dict(r['expected']);body={k:capsule['bindings'][v[2:-1]] if isinstance(v,str) and re.fullmatch(r'@\{[A-Za-z0-9_]+\}',v) else v for k,v in body.items()}
   call('B','POST',route(r),body)
   for actor in ('A','B'):verify(r,call(actor,'GET',route(r)))
 baseline={'resources':{},'memberships':{}}
 for r in capsule['resources']:
  baseline['resources'][r['logicalId']]=call('A','GET',route(r))
  if r['resourceType']=='ModelsTask':
   labels=call('A','GET',route(r)+'/labels')
   if labels:raise ValueError('Expected empty task-label baseline; no links removed automatically')
   baseline['memberships'][r['logicalId']]=labels
 snapshot=backend.save('shared-authorized-checkpoint')
 engine.write(run/'shared-setup-v060.json',{'verified':True,'permission':1,'permission_source':'#/definitions/models.ProjectUser/properties/permission','sharing_source':'#/paths/~1projects~1{id}~1users/put','readable_resources':4,'second_user_task_updates_verified':2,'labels_mutated':False,'prefix_http_requests':len(records),'snapshot_hashes':snapshot['hashes'],'prefix_depth_parameter':False})
 result=copy.deepcopy(recovery);result.update(capsule=capsule,baseline=baseline,snapshot=snapshot)
 result['provenance'].update(shared_prefix_verified=True,shared_baseline_snapshot=True)
 return result
