import json,re,tempfile,copy
from pathlib import Path
from unittest.mock import patch
import prepare_shared_v059 as setup
import relation_engine_v059 as engine
from zipfile import ZipFile
root=Path(__file__).resolve().parent
with ZipFile(root/'accepted-review-v050.zip') as z:capsule=json.loads(z.read('checkpoint-model-v050.json'))
class Auth:
 def __init__(self,id):self.id=id
 def ensure(self):return str(self.id)
class Backend:
 def save(self,label):return {'folder':'fixture','hashes':{}}
with tempfile.TemporaryDirectory() as d:
 run=Path(d);objects={};shares={}
 for r in capsule['resources']:
  key=re.sub('[^A-Za-z0-9_]','_',r['logicalId']);path=r['detail_template'].replace('{'+r['route_parameter']+'}',str(capsule['bindings']['ROUTE_'+key]));objects[path]={k:capsule['bindings'][v[2:-1]] if isinstance(v,str) and re.fullmatch(r'@\{[A-Za-z0-9_]+\}',v) else v for k,v in r['expected'].items()}
 def request(url,method='GET',body=None,token=None):
  path=url.removeprefix('http://fixture');result=None;status=200
  if path=='/user':result={'id':int(token),'username':'owner' if token=='1' else 'peer'}
  elif '/users' in path:
   project=path.split('/users')[0]
   if method=='PUT':shares[project]=body;status=201;result=body
   else:result=[shares[project]] if project in shares else []
  elif path.endswith('/labels'):result=[]
  else:
   if method=='POST':objects[path].update(body)
   result=objects[path]
  return status,json.dumps(result).encode()
 with patch.object(engine,'request',request):
  result=setup.prepare('http://fixture',Backend(),{'capsule':capsule,'provenance':{}},Auth(1),Auth(2),run)
  assert len(shares)==2 and all(s['permission']==1 for s in shares.values())
  assert result['snapshot']['folder']=='fixture'
  evidence=json.loads((run/'shared-prefix-evidence-v059.json').read_text());assert sum(x['actor']=='B' and x['method']=='POST' for x in evidence)==2
  try:setup.prepare('http://fixture',Backend(),{'capsule':capsule,'provenance':{}},Auth(1),Auth(1),run)
  except ValueError:pass
  else:raise AssertionError('Identical users not blocked')
print('V059_SHARED_PREFIX_FIXTURE_PASS: sharing precedes peer updates; distinct users required. No live execution.')
