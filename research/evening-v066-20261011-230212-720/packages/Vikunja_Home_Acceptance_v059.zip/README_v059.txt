VIKUNJA HOME LIVE ACCEPTANCE v059

Scope: exactly the forward/alternate same-task disjoint-field pair from v057,
task 1, history depth 0, 104 checks per case (208 planned in the selected pair).
The fixed setup attaches four links and is counted separately from prefix depth.
Actions are sequential, not simultaneous. No live success is claimed in this ZIP.

Default home root D:\Yeshayahu\Temp\vikunja_tse_study.
Launcher Run-Home-Acceptance-v059.ps1; static first, then -RunLive.
Checks Python, Java, Docker, JAR hash, free disk, existing container and API,
then exact frozen Swagger bytes and exclusive storage mounts before execution.
Docker stderr warnings no longer fail a successful docker info command.
Supports exclusive home named volumes or bind mounts under StudyRoot\deployment\state.
Named-volume snapshots use the existing vikunja-increment8-2-files-init image.
Existing Docker deployment is retained; no image pull or volume deletion.

The original Context generator creates and verifies six NEW HOME resources using
its v031 bootstrap lifecycle. An actor-A route normalization adapter allows that
bootstrap to use the current original renderer. Home identifiers come from real
responses; historical fixture identifiers are used only in static mode/tests.
The bootstrap runs its two label lifecycles and restores its empty-link checkpoint.
Two existing research users are authenticated (SBT-tester, SBT-peer-v051).
If the peer account is absent from the local CLI list, registration is attempted
with the entered new research password. Existing passwords are never reset.
Registration denial is an infrastructure/setup stop, not a discovered bug.
Both projects explicitly grant peer Read & Write, independently verified by
share-entry readback and allowed task update/readback. Labels belong to A;
only A attaches them; peer removes an already attached link under task permission.

The shared baseline is saved after users/shares have been verified. Each case
replays from that same cold baseline. Original Stories/Interfaces/DAL/Context and
independent task/project and fully paginated membership observers are retained.
Both actors independently verify after each mutation. Negative title-array and
project-id-object tests follow, with independent unchanged-state verification.

A semantic failure is recorded and baseline restored before the next case.
Infrastructure or restore mismatch stops the campaign; no pass is fabricated.
Successful campaign completion is separate from semantic verdict. Inspect
checks_passed/failed/undetermined, native exit/result, final order comparison,
baseline restoration, and durable HTTP evidence in review_v059.zip.
Bootstrap checks and setup requests are additional to the 208 selected checks.
Private snapshots contain full local server state; they remain local and are
excluded from review ZIPs. Exact process memory/clock continuation is not claimed.

Output runs/home-acceptance-v059-*/review_v059.zip includes all actual generated JS,
per-case logs/checks, journal, shared-setup proofs, and home ID bindings.
Before-home-bootstrap and shared-authorized-checkpoint backups stay in that run's
.private-snapshots directory. Preserve that directory for any later continuation.

Here validation is static/fixture only, including plans, callback/DAL fault tests,
pagination, setup permissions, adapter selection and home orchestration tests.
Native Provengo and Docker acceptance must be executed on the home computer.
