import json,subprocess
import relation_engine_v059 as engine
import run_work_v023 as storage

def backend_for_home(target,run,study):
 c=json.loads(subprocess.run(['docker','inspect','vikunja-research-sut'],capture_output=True,text=True,check=True,timeout=30).stdout)[0]
 mounts=[m for m in c['Mounts'] if m['Destination'] in ('/db','/app/vikunja/files')]
 if len(mounts)!=2:raise ValueError('Expected two persistent mounts')
 if all(m['Type']=='volume' for m in mounts):return engine.DockerVolumeBackend('vikunja-research-sut','vikunja-increment8-2-files-init',target,'',run)
 if all(m['Type']=='bind' for m in mounts):return storage.BindBackend('vikunja-research-sut',target,run,study)
 raise ValueError('Unsupported or mixed storage; deployment preserved')
