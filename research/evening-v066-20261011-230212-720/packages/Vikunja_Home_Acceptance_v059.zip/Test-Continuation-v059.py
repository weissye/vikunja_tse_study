"""Campaign control test with real generated-JS fixture receipts, not native/live."""
import copy,json,re,sys,tempfile,subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import relation_engine_v059 as engine
from generate_v059 import catalog
root=Path(__file__).resolve().parent
capsule=json.loads((root/'fixture-checkpoint-model-v059.json').read_text())
class Auth:
 def ensure(self):return 'fixture'
class Backend:
 fixture_only=True
 token='fixture'
 client_auth={'A':Auth(),'B':Auth()}
 client_tokens={'A':'fixture','B':'fixture'}
 def __init__(self):self.restores=[];self.saves=[]
 def ensure_authenticated(self):return 'fixture'
 def save(self,label):self.saves.append(label);return {'folder':'fixture','hashes':{}}
 def restore(self,snapshot):self.restores.append(snapshot)

objects={};memberships={}
for r in capsule['resources']:
 key=re.sub('[^A-Za-z0-9_]','_',r['logicalId']);route=capsule['bindings']['ROUTE_'+key]
 path=r['detail_template'].replace('{'+r['route_parameter']+'}',str(route))
 objects[path]={k:capsule['bindings'][v[2:-1]] if isinstance(v,str) and re.fullmatch(r'@\{[A-Za-z0-9_]+\}',v) else v for k,v in r['expected'].items()}
 if r['resourceType']=='ModelsTask':objects[path+'/labels']=[];memberships[r['logicalId']]=[]
baseline={'resources':{r['logicalId']:objects[r['detail_template'].replace('{'+r['route_parameter']+'}',str(capsule['bindings']['ROUTE_'+re.sub('[^A-Za-z0-9_]','_',r['logicalId'])]))] for r in capsule['resources']},'memberships':memberships}
def request(url,**kwargs):return 200,json.dumps(objects[url.removeprefix('http://fixture')]).encode()
with tempfile.TemporaryDirectory() as directory:
 run=Path(directory);receipts=run/'fixture-receipts';receipts.mkdir()
 subprocess.run(['node',str(root/'Test-Pair-v059.js'),str(root/'selected-catalog-v059.json'),str(root/'generated'),str(root/'fixture-checkpoint-model-v059.json'),str(receipts)],check=True,capture_output=True,text=True)
 original_run=subprocess.run
 def native(command,**kwargs):
  if command[0]!='java':return original_run(command,**kwargs)
  index=int(Path(command[-1]).parent.name.split('-')[-1])-1
  lines=json.loads((receipts/('fail-0.json' if index==0 else 'pass-1.json')).read_text())
  lines.append('RELATION_CONTEXT '+json.dumps(capsule['resources']))
  if index==1:lines.extend(['RELATION_CASE_COMPLETED '+catalog()['items'][index]['case_id'],'Test Result: SUCCESS'])
  return SimpleNamespace(returncode=1 if index==0 else 0,stdout='\n'.join(lines),stderr='')
 backend=Backend();recovery={'capsule':copy.deepcopy(capsule),'baseline':baseline,'snapshot':{'folder':'fixture','hashes':{}},'provenance':{'fixture_only':True}}
 with patch.object(engine,'request',request),patch.object(engine.subprocess,'run',native):
  result=engine.run_relations(run,run/'fixture.jar','http://fixture','fixture',backend,recovery=recovery)
 assert result['status']=='V059_RELATION_ACCEPTANCE_COMPLETED',result
 assert result['completed_cases']==2 and result['semantic_candidate_count']==1
 assert result['checks_failed']>=1 and result['semantic_verdict']=='FAIL'
 assert len(backend.restores)==3 and 'finding-1' in backend.saves
 assert json.loads((run/'progress_v059.json').read_text())['next_index']==2
 assert result['live_execution'] is False
print('V059_CONTINUATION_FIXTURE_PASS: first failure preserved, baseline restored, second case completed; NOT NATIVE OR LIVE')
