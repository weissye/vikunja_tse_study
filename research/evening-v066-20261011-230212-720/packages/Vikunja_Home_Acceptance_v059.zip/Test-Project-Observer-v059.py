from project_observer_v059 import collect
views=[{'id':7,'project_id':76,'view_kind':'list','filter':None}]
def fetch(p):
 if p.endswith('/views'):return 200,views
 if 'page=1&' in p:return 200,[{'id':410,'project_id':76}]
 if 'page=2&' in p:return 200,[{'id':411,'project_id':76}]
 return 200,[]
r=collect('76',fetch);assert r['complete'] and r['ids']==[410,411] and r['pages']==3
for mode in ('duplicate','wrong-project','error','filtered','cap'):
 def bad(p):
  if p.endswith('/views'):return 200,[dict(views[0],filter={'filter':'done = true'})] if mode=='filtered' else views
  if mode=='error':return 429,{}
  if mode=='wrong-project':return 200,[{'id':410,'project_id':77}]
  if mode=='duplicate':return 200,[{'id':410,'project_id':76}]
  return 200,[{'id':int(p.split('page=')[1].split('&')[0]),'project_id':76}]
 assert collect('76',bad,max_pages=3)['complete'] is False
print('V059_PROJECT_PAGINATION_FIXTURE_PASS: short pages continue to empty; duplicate/wrong project/filter/rate limit/cap unresolved. Not live.')

import json
from pathlib import Path
from zipfile import ZipFile
with ZipFile(Path(__file__).parent/'accepted-review-v052.zip') as z:
 records=json.loads(z.read('http-evidence.json'))
live=next(r['response'] for r in records if r['path']=='/api/v1/projects/76/views')
if isinstance(live,str):live=json.loads(live)
def table_fetch(path):
 if path.endswith('/views'):return 200,live
 assert '/views/307/tasks?' in path,path
 return (200,[{'id':410,'project_id':76}]) if 'page=1&' in path else (200,[])
r=collect('76',table_fetch)
assert r['complete'] and r['view_kind']=='table' and r['view_id']==307 and r['ids']==[410]
print('V059_HISTORICAL_VIEW_REGRESSION_PASS: filtered list skipped; unfiltered table paginated. Fixture only.')
