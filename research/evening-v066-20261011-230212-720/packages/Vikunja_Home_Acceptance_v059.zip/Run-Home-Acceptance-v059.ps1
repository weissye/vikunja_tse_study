param(
 [switch]$RunLive,
 [string]$StudyRoot='D:\Yeshayahu\Temp\vikunja_tse_study',
 [string]$ProvengoJar=(Join-Path $StudyRoot 'Provengo-2026-01-10.uber.jar')
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_HOME_ACCEPTANCE v059 - search v057 depth 0'
Get-Command python -ErrorAction Stop | Out-Null
& python (Join-Path $PSScriptRoot 'Verify-v059.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
if ($RunLive) {
 foreach ($command in @('java','docker')) {Get-Command $command -ErrorAction Stop | Out-Null}
 if (-not (Test-Path -LiteralPath $ProvengoJar -PathType Leaf)) {throw "Provengo JAR missing: $ProvengoJar"}
 if ((Get-FileHash -LiteralPath $ProvengoJar -Algorithm SHA256).Hash -ne
     'dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b') {throw 'Provengo JAR mismatch.'}
 $drive=[System.IO.Path]::GetPathRoot($StudyRoot).Substring(0,1)
 if ((Get-PSDrive $drive).Free -lt 3GB) {throw 'At least 3 GB free required.'}
 $previousPreference=$ErrorActionPreference
 try {
  $ErrorActionPreference='Continue'
  & docker info 1>$null
  $dockerExit=$LASTEXITCODE
 } finally {$ErrorActionPreference=$previousPreference}
 if ($dockerExit -ne 0) {throw 'Open Docker Desktop, wait until ready, and retry.'}
 $previousPreference=$ErrorActionPreference
 try {
  $ErrorActionPreference='Continue'
  $raw=& docker inspect vikunja-research-sut
  $inspectExit=$LASTEXITCODE
 } finally {$ErrorActionPreference=$previousPreference}
 if ($inspectExit -ne 0) {throw 'Existing vikunja-research-sut container missing.'}
 $container=@((($raw -join "`n") | ConvertFrom-Json))[0]
 Write-Host "Existing image: $($container.Image)"
 $container.Mounts | Select-Object Type,Name,Source,Destination,RW | Format-Table -AutoSize
 if (-not $container.State.Running) {
  $previousPreference=$ErrorActionPreference
  try {
   $ErrorActionPreference='Continue'
   & docker start vikunja-research-sut
   $startExit=$LASTEXITCODE
  } finally {$ErrorActionPreference=$previousPreference}
  if ($startExit -ne 0) {throw 'Starting existing container failed.'}
 }
 $info=$null
 for ($attempt=1;$attempt -le 15;$attempt++) {
  try {$info=Invoke-RestMethod 'http://127.0.0.1:3456/api/v1/info' -TimeoutSec 3;break}
  catch {Start-Sleep -Seconds 2}
 }
 if ($null -eq $info -or $info.version -ne 'v2.6.0') {throw 'Expected local v2.6.0 API unavailable.'}
 Write-Host 'V059_DOCKER_AND_API_READY'
}
$arguments=@((Join-Path $PSScriptRoot 'run_home_v059.py'),'--study-root',$StudyRoot,'--jar',$ProvengoJar)
if ($RunLive) {$arguments+='--live'}
& python @arguments
if ($LASTEXITCODE -ne 0) {throw 'V059 acceptance incomplete. Preserve the printed review ZIP and private snapshots.'}
