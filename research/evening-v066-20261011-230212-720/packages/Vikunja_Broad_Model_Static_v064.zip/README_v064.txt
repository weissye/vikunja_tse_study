V064 BROAD STATIC MODEL
170 operation plans, 98 schema-reference dependency records, 23 create-candidate audits. Eight resource configurations generate 24 JS files with the original Context generator. Fifteen candidates remain blocked with exact reasons.
Generated families: projects, tasks, labels, saved filters, teams, project shares, project views, task comments. The latter five have no live acceptance in this delivery.
All operation plans include contract provenance, parameters, schema references, positive/negative template categories and readiness gates. These plans are not runnable JS for all 170 operations.
No live execution. No true concurrency. No full coverage claim. OpenAPI does not supply all semantic or authorization expectations.
Run Run-Broad-Model-v064.ps1 to regenerate into a fresh directory. Inspect each spec/js/stories.vikunja.js, interfaces.vikunja.js and dal.js. Never edit generated files as a substitute for generator changes.
The split-route parent inference fix is part of source/generator_v56/render/context_model.py.
