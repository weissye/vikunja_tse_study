# Broad model v064

Operations planned: 170. Schemas retained: 98. Generated families: 8. Blocked families: 15.

Generated JavaScript comes from the original generator, with Context, Stories, Interfaces, DAL and schema verifiers. Static generation is not execution. Parameter binding and oracle completeness must be verified before live delivery.

| Candidate collection | Generator status | Blocking reason |
|---|---|---|
| `/filters` | ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED |  |
| `/labels` | ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED |  |
| `/projects` | ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED |  |
| `/projects/{id}/tasks` | ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED |  |
| `/projects/{id}/teams` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /projects/{id}/teams |
| `/projects/{id}/users` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /projects/{id}/users |
| `/projects/{id}/views/{view}/buckets` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /projects/{id}/views/{view}/buckets |
| `/projects/{id}/webhooks` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /projects/{id}/webhooks |
| `/projects/{projectID}/duplicate` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /projects/{projectID}/duplicate |
| `/projects/{project}/shares` | ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED |  |
| `/projects/{project}/views` | ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED |  |
| `/subscriptions/{entity}/{entityID}` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /subscriptions/{entity}/{entityID} |
| `/tasks/{taskID}/assignees` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /tasks/{taskID}/assignees |
| `/tasks/{taskID}/assignees/bulk` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /tasks/{taskID}/assignees/bulk |
| `/tasks/{taskID}/comments` | ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED |  |
| `/tasks/{taskID}/duplicate` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /tasks/{taskID}/duplicate |
| `/tasks/{taskID}/labels/bulk` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /tasks/{taskID}/labels/bulk |
| `/tasks/{taskID}/relations` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /tasks/{taskID}/relations |
| `/tasks/{task}/labels` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /tasks/{task}/labels |
| `/teams` | ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED |  |
| `/teams/{id}/members` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /teams/{id}/members |
| `/tokens` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /tokens |
| `/{kind}/{id}/reactions` | GENERATOR_BLOCKED | ValueError: Ambiguous/missing item GET: /{kind}/{id}/reactions |

## Coverage completion gates

Every operation must have: resource/alias identity, prerequisite producer, route bindings, request builder, authorized identity, independent oracle, failure evidence and verified recovery.
Schema references may be cyclic and may describe representations rather than resources. Create dependencies and later link dependencies must be resolved separately.
Next implementation should address the blocked families shown above, retaining explicit reasons until each gate is fulfilled.