"""Whole-contract planning plus original Context-generator capability audit. STATIC ONLY."""
import json,re,sys,subprocess,hashlib,collections,argparse
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source'))
from generator_v56.parsing.swagger_context import normalize_context_contract
raw=json.loads((root/'contract.json').read_text());spec,_=normalize_context_contract(raw)
methods={'get','post','put','patch','delete','head','options'}
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=root/'generated-v064');args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
def refs(v):
 if isinstance(v,dict):
  if '$ref' in v:yield v['$ref']
  for k,x in v.items():
   if k!='$ref':yield from refs(x)
 elif isinstance(v,list):
  for x in v:yield from refs(x)
def schema(s,seen=None):
 seen=set(seen or [])
 if '$ref' in s:
  ref=s['$ref']
  if ref in seen:return {'cycle':ref}
  seen.add(ref);v=spec
  for k in ref.lstrip('#/').split('/'):v=v[k.replace('~1','/').replace('~0','~')]
  return schema(v,seen)
 return s
ops=[]
for path,item in spec['paths'].items():
 for method,o in item.items():
  if method not in methods:continue
  parameters=item.get('parameters',[])+o.get('parameters',[])
  responses=o.get('responses',{})
  body=o.get('requestBody',{}).get('content',{}).get('application/json',{}).get('schema',{})
  expanded=schema(body);negative=[]
  for field,s in expanded.get('properties',{}).items():
   s=schema(s)
   if s.get('readOnly'):continue
   t=s.get('type');bad={'string':[[],{}],'integer':[{},[]],'number':[{},[]],'boolean':[{},[]],'array':[{},False],'object':[[],False]}.get(t,[])
   for value in bad:negative.append({'field':field,'invalid_value':value,'rule':'TYPE_'+str(t).upper(),'source':'request_schema','oracle':'Expect rejection, separately classify documented status and independently compare observed state; requires justified writable-field and resource binding'})
   for key in ('minLength','maxLength','minimum','maximum','enum','pattern','minItems','maxItems'):
    if key in s:negative.append({'field':field,'rule':key,'constraint':s[key],'source':'request_schema','value_generation':'REQUIRES_SUPPORTED_CONSTRAINT_GENERATOR'})
  params=[{'name':p['name'],'location':p['in'],'schema':p.get('schema',{}),'required':p.get('required',False),'binding_status':'UNRESOLVED' if p['in']=='path' else 'CONTRACT_PARAMETER'} for p in parameters]
  categories=[]
  relationship_action=bool(re.search(r'/(assignees|labels|relations|members|teams|users|reactions)(/bulk)?$',path)) and '{' in path
  special_action='duplicate' if path.endswith('/duplicate') else 'bulk' if path.endswith('/bulk') else 'relationship' if relationship_action else 'resource'
  if method=='get':categories=['read','collection_pagination' if not path.endswith('}') else 'detail_read']
  elif method=='delete':categories=['delete','independent_absence','unrelated_resource_preservation']
  else:categories=['write','independent_readback','unrelated_resource_preservation','schema_negative']
  ops.append({'id':'OP-'+str(len(ops)+1).zfill(3),'method':method.upper(),'path':path,'source_pointer':'#/paths/'+path.replace('~','~0').replace('/','~1')+'/'+method,'parameters':params,'request_schema':body,'schema_references':sorted(set(refs(o))),'documented_success_codes':[int(k) for k in responses if k.isdigit() and 200<=int(k)<300],'documented_error_codes':[int(k) for k in responses if k.isdigit() and int(k)>=400],'action_family':special_action,'scenario_templates':categories+(['link_add_read_remove_read','unrelated_links_preserved'] if relationship_action else ['duplicate_preserves_source'] if special_action=='duplicate' else []),'negative_rules':negative,'required_context':['authorized research identity','resolved path/resource bindings','verified state prerequisites','independent readback or justified absence observer'],'planned_prefix_depths':[0,3,6,12],'execution_status':'PLANNED_NOT_EXECUTED','oracle_status':'REQUIRES_OPERATION_SPECIFIC_MAPPING','true_concurrency':False})
# Reference dependencies are retained as references, never silently promoted to ownership.
schemas=[{'schema':n,'references':sorted(set(refs(v))),'resource_identity_status':'UNRESOLVED'} for n,v in raw.get('definitions',{}).items()]
candidates=[p for p,item in spec['paths'].items() if sum(m in item and '201' in item[m].get('responses',{}) for m in ['put','post'])==1]
capabilities=[];core=['/projects','/projects/{id}/tasks','/labels']
for index,path in enumerate(candidates,1):
 resources=list(dict.fromkeys(core+[path]));folder=out/('family-'+str(index).zfill(2));folder.mkdir()
 cmd=[sys.executable,'-m','generator_v56','context-generate','--openapi',str(root/'contract.json'),'--output',str(folder/'spec/js'),'--name','vikunja','--base-url','http://127.0.0.1:3456/api/v1','--instances-per-entity','2','--seed','1','--negative-schema','--method-adapter',str(root/'method_adapter.json')]
 for p in resources:cmd+=['--resource',p]
 proc=subprocess.run(cmd,cwd=root/'source',capture_output=True,text=True,timeout=60);(folder/'generation.log').write_text(proc.stdout+proc.stderr)
 ok=proc.returncode==0
 capabilities.append({'candidate':path,'resources':resources,'status':'ORIGINAL_CONTEXT_JS_GENERATED_NOT_EXECUTED' if ok else 'GENERATOR_BLOCKED','generated_js':[str(x.relative_to(out)) for x in folder.rglob('*.js')],'reason':None if ok else (proc.stderr.strip().splitlines()[-1] if proc.stderr.strip() else proc.stdout[-500:])})
report={'version':'v064','status':'BROAD_STATIC_MODEL_COMPLETE','live_execution':False,'contract_sha256':hashlib.sha256((root/'contract.json').read_bytes()).hexdigest(),'operations':ops,'schema_reference_dependencies':schemas,'generator_capabilities':capabilities,'operation_count':len(ops),'schema_count':len(schemas),'generated_families':sum(c['status'].startswith('ORIGINAL') for c in capabilities),'blocked_families':sum(c['status']=='GENERATOR_BLOCKED' for c in capabilities),'scope':'All operations catalogued; original generator JS only where generation succeeds. No live or full semantic coverage claim.'}
(out/'MODEL_v064.json').write_text(json.dumps(report,indent=2))
lines=['# Broad model v064','',f"Operations planned: {len(ops)}. Schemas retained: {len(schemas)}. Generated families: {report['generated_families']}. Blocked families: {report['blocked_families']}.",'','Generated JavaScript comes from the original generator, with Context, Stories, Interfaces, DAL and schema verifiers. Static generation is not execution. Parameter binding and oracle completeness must be verified before live delivery.','', '| Candidate collection | Generator status | Blocking reason |','|---|---|---|']
for c in capabilities:lines.append('| `'+c['candidate']+'` | '+c['status']+' | '+str(c['reason'] or '') .replace('|','/')+' |')
lines+=['','## Coverage completion gates','','Every operation must have: resource/alias identity, prerequisite producer, route bindings, request builder, authorized identity, independent oracle, failure evidence and verified recovery.','Schema references may be cyclic and may describe representations rather than resources. Create dependencies and later link dependencies must be resolved separately.','Next implementation should address the blocked families shown above, retaining explicit reasons until each gate is fulfilled.']
(out/'MODEL_v064.md').write_text('\n'.join(lines))
print('V064_STATIC_MODEL',len(ops),'operations',len(schemas),'schemas',report['generated_families'],'generated families',report['blocked_families'],'blocked')
