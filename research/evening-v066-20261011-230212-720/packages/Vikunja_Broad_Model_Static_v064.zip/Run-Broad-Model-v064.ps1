param([string]$StudyRoot='D:\Yeshayahu\Temp\vikunja_tse_study')
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_BROAD_MODEL_STATIC v064'
& python (Join-Path $PSScriptRoot 'Verify-v064.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
$output = Join-Path $StudyRoot ('generated\broad-v064-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
& python (Join-Path $PSScriptRoot 'Generate-Broad-Model-v064.py') --output $output
if ($LASTEXITCODE -ne 0) {throw 'Static generation failed.'}
Write-Host "Generated model and JS: $output"
Write-Host 'STATIC ONLY: no live requests or Docker changes.'
