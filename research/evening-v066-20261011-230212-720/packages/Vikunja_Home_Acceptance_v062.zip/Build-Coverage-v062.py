"""Inventory contract operations and schema references, never infer live coverage."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
spec=json.loads((root/'engine-v010/vikunja-live-swagger.json').read_text())
methods={'get','post','put','patch','delete','head','options'}
def refs(value,path=''):
 if isinstance(value,dict):
  for k,v in value.items():
   if k=='$ref':yield {'pointer':path+'/$ref','target':v}
   else:yield from refs(v,path+'/'+k.replace('~','~0').replace('/','~1'))
 elif isinstance(value,list):
  for i,v in enumerate(value):yield from refs(v,path+'/'+str(i))
ops=[]
for path,item in spec['paths'].items():
 for method,op in item.items():
  if method in methods:
   ops.append({'method':method.upper(),'path':path,'operation_id':op.get('operationId'),'tags':op.get('tags',[]),'schema_references':list(refs(op)),'coverage':'NOT_YET_MAPPED_TO_LIVE_EVIDENCE'})
schemas=[{'name':name,'references':list(refs(s)),'resource_identity':'UNVERIFIED_SCHEMA_IS_NOT_NECESSARILY_A_RESOURCE'} for name,s in spec.get('definitions',{}).items()]
report={'version':'v062','operations':ops,'schemas':schemas,'operation_count':len(ops),'schema_count':len(schemas),'validated_live_scope':['project-task membership','task-label membership','two authorized users, task field updates'],'limitations':['Schema references are structural dependencies, not proven resource ownership or creation dependencies','No full coverage claim','Historical evidence needs operation-by-operation mapping'],'next_steps':['Map accepted HTTP traces to operations and retain evidence provenance','Classify every operation as executable, blocked or out of scope with reason','Resolve creation prerequisites and independent readback routes per resource family','Generate Context stories and negative schema cases per supported family','Expand relationship histories and schedule pairs, then separately evaluate true concurrency']}
(root/'COVERAGE_INVENTORY_v062.json').write_text(json.dumps(report,indent=2))
print('V062_COVERAGE_INVENTORY',len(ops),'operations',len(schemas),'schemas; NOT LIVE COVERAGE')
