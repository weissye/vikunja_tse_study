"""Home acceptance subset of the frozen v057 search catalog."""
import copy,json
from pathlib import Path
from expand_search_v057 import catalog as search_catalog
from base_generator_v057 import generate as original_generate

def catalog():
 c=search_catalog();c=copy.deepcopy(c)
 c['items']=[x for x in c['items'] if x['search_metadata']['prefix_depth']==3 and x['search_metadata']['history']=='relation_history' and x['search_metadata']['family']=='same_task_disjoint_fields' and x['subjects']['task']=='ModelsTask_1']
 assert len(c['items'])==2
 c.update(version='v062',case_count=2,status='HOME_ACCEPTANCE_PLANNED',live_execution=False)
 return c
def generate(run,case,proxy,resources=None):
 project=original_generate(run,case,proxy,resources)
 (Path(run)/'search-provenance-v062.json').write_text(json.dumps({'search_version':'v057','acceptance_version':'v062','metadata':case['search_metadata'],'expected_checks':case['expected_checks']},indent=2))
 return project
