from relation_engine_v062 import check_counts
assert check_counts([{'pass':True}]*248+[{'pass':None,'kind':'project_membership'}]*112)==dict(checks_total=360,checks_passed=248,checks_failed=0,checks_undetermined=112,project_membership_undetermined_count=112,task_label_membership_undetermined_count=0)
assert check_counts([{'pass':False}])['checks_failed']==1
print('V062_VERDICT_COUNTS_PASS')
assert check_counts([{'pass':None,'kind':'task_label_membership'}])['task_label_membership_undetermined_count']==1
