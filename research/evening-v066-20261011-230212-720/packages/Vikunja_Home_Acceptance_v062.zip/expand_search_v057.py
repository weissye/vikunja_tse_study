"""Bounded STATIC consistency search; no server requests or live campaign."""
import argparse,copy,json,hashlib
from pathlib import Path
from base_generator_v057 import catalog as base_catalog,generate

ROOT=Path(__file__).resolve().parent
def catalog():
 base=base_catalog();spec=base['relation_spec'];items=[]
 for depth in (0,3,6,12):
  for history in (['none'] if depth==0 else ['field_history','relation_history']):
   for index in (1,2):
    task=spec['child_type']+'_'+str(index);other=spec['child_type']+'_'+str(3-index)
    label1=spec['target_type']+'_1';label2=spec['target_type']+'_2'
    def field(name,value,actor='A',resource=task):return dict(actor=actor,task=resource,field=name,value=value)
    def link(action,label,actor):return dict(actor=actor,task=task,action=action,label=label)
    prefix=[]
    for n in range(depth):
     if history=='field_history':step=field('title' if n%2==0 else 'description','sbt-v057-history-'+str(n),'A' if n%2==0 else 'B')
     else:step=[link('detach',label1,'B'),link('attach',label1,'A'),field(spec['parent_field'],'@{ID_'+spec['parent_type']+'_'+str(2 if (n//3)%2==0 else 1)+'}','B')][n%3]
     prefix.append(step)
    families={
     'same_task_disjoint_fields':[field('title','sbt-v057-final-title','A'),field('description','sbt-v057-final-description','B')],
     'different_tasks':[field('title','sbt-v057-first-task','A'),field('description','sbt-v057-other-task','B',other)],
     'move_and_field':[field(spec['parent_field'],'@{ID_'+spec['parent_type']+'_2}','B'),field('title','sbt-v057-moved-title','A')],
     'two_link_cycles':[link('detach',label1,'B'),link('attach',label1,'A'),link('detach',label2,'B'),link('attach',label2,'A')]
    }
    for family,steps in families.items():
     for order in ('forward','alternate'):
      probe=steps if order=='forward' else steps[2:]+steps[:2] if family=='two_link_cycles' else list(reversed(steps))
      group=f'{family}/d{depth}/{history}/task{index}';case_id=group.replace('/','-')+'-'+order
      metadata={'family':family,'prefix_depth':depth,'history':history,'prefix_mutations':depth,'probe_mutations':len(probe),'fixed_setup_link_mutations':4,'reads_count_as_prefix':False,'schedule':'explicit sequential order','true_concurrency':False,'automatic_scope':'API shapes/identifiers from contract; history and equivalence templates are explicit research inputs','comparison_group':group,'paired_prefix_identical':True}
      case=dict(case_id=case_id,subjects={'task':task,'other_task':other,'label':label1,'second_label':label2},steps=copy.deepcopy(prefix+probe),prefix_actor='A',comparison_group=group,order=order,negative_target=task,negative_cases=[dict(rule_id='STRING_TYPE_ARRAY',field='title',value=[]),dict(rule_id='INTEGER_TYPE_OBJECT',field=spec['parent_field'],value={})],expected_checks=70+17*(depth+len(probe)),search_metadata=metadata)
      items.append(case)
 return dict(version='v057',status='STATIC_SEARCH_PLANS',live_execution=False,depths=[0,3,6,12],families=4,items=items,case_count=len(items),relation_spec=spec,contract_sha256=base['contract_sha256'],deferred=['Live home checkpoint preparation and acceptance','True concurrency','Automatic semantic permission inference','More resource families','Generated bthread scheduling beyond enumerated orders'])

def validate_case(case):
 """Simulate link preconditions, ownership roles and paired state invariants."""
 links={case['subjects']['label'],case['subjects']['second_label']}
 state={};depth=case['search_metadata']['prefix_depth']
 assert len(case['steps'])==depth+case['search_metadata']['probe_mutations']
 for step in case['steps']:
  assert step['actor'] in ('A','B')
  if step.get('action')=='detach':
   assert step['label'] in links;links.remove(step['label'])
  elif step.get('action')=='attach':
   assert step['actor']=='A' and step['label'] not in links;links.add(step['label'])
  else:state[(step['task'],step['field'])]=step['value']
 assert links=={case['subjects']['label'],case['subjects']['second_label']}
 return state,links

def build(output):
 output=output.resolve()
 if output.exists():raise ValueError('Use a new output directory; previous artifacts are preserved')
 output.mkdir(parents=True)
 c=catalog();fixture=json.loads((ROOT/'fixture-checkpoint-model-v057.json').read_text())
 groups={}
 for i,case in enumerate(c['items'],1):
  state=validate_case(case);group=case['comparison_group']
  if group in groups:assert state==groups[group]
  groups[group]=state
  generate(output/f'case-{i:03}',case,'http://127.0.0.1:3456/api/v1',fixture['resources'])
  (output/f'case-{i:03}'/'search-metadata-v057.json').write_text(json.dumps(case['search_metadata'],indent=2))
 (output/'search-catalog-v057.json').write_text(json.dumps(c,indent=2))
 result={'version':'v057','status':'V057_STATIC_GENERATION_COMPLETE','cases':len(c['items']),'comparison_pairs':len(groups),'planned_checks':sum(x['expected_checks'] for x in c['items']),'live_execution':False,'fixture_bindings_are_not_home_server_ids':True}
 (output/'result_v057.json').write_text(json.dumps(result,indent=2))
 manifest={p.relative_to(output).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(output.rglob('*')) if p.is_file()}
 (output/'generated-manifest-v057.json').write_text(json.dumps(manifest,indent=2))
 print(json.dumps(result));print('Generated JS:',output)
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);build(p.parse_args().output)
