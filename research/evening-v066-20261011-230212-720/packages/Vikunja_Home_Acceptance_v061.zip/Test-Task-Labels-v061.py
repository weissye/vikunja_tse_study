from task_labels_observer_v061 import collect
def fetch(path):
 if 'page=1&' in path:return 200,[{'id':123}]
 if 'page=2&' in path:return 200,[{'id':124}]
 return 200,[]
assert collect('410',fetch)==dict(complete=True,ids=[123,124],pages=3)
assert not collect('410',lambda p:(200,[{'id':123}]))['complete']
assert not collect('410',lambda p:(403,{}))['complete']
assert not collect('410',lambda p:(200,[{'id':'123'}]))['complete']
print('V061_LABEL_PAGINATION_FIXTURE_PASS; NOT LIVE')
