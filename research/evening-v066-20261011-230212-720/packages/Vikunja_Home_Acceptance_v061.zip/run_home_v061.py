import argparse,getpass,hashlib,json,os,sys,uuid,subprocess
from pathlib import Path
from datetime import datetime,timezone
import relation_engine_v061 as engine
import relation_engine_v031 as bootstrap
from generate_v061 import catalog,generate
from home_backend_v061 import backend_for_home
from prepare_shared_v061 import prepare
from auth_v029 import Auth
import run_work_v023 as storage
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--study-root',type=Path,required=True);p.add_argument('--jar',type=Path,required=True);p.add_argument('--live',action='store_true');a=p.parse_args()
 run=a.study_root.resolve()/'runs'/('home-acceptance-v061-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True)
 result={'version':'v061','status':'NOT_ACCEPTED'}
 try:
  engine.disk_guard(run)
  if not a.live:
   capsule=json.loads((ROOT/'fixture-checkpoint-model-v061.json').read_text())
   for i,case in enumerate(catalog()['items'],1):generate(run/f'static-case-{i}',case,'http://127.0.0.1:3456/api/v1',capsule['resources'])
   result={'version':'v061','status':'V061_STATIC_READY','live_execution':False,'fixture_only':True,'cases':2,'planned_checks':sum(c['expected_checks'] for c in catalog()['items'])};engine.pack_review(run,result,[])
  else:
   if os.name!='nt':raise ValueError('Home live adapter requires Windows')
   if storage.sha(a.jar)!='dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b':raise ValueError('Provengo JAR mismatch')
   target='http://127.0.0.1:3456/api/v1'
   status,raw=engine.request(target+'/docs.json')
   if status!=200 or hashlib.sha256(raw).hexdigest()!=storage.sha(ROOT/'engine-v010/vikunja-live-swagger.json'):raise ValueError('Home contract differs from the frozen live contract')
   backend=backend_for_home(target,run,a.study_root)
   password_a=getpass.getpass('Password for SBT-tester: ')
   auth_a=Auth(target,'SBT-tester',password_a,run)
   backend.ensure_authenticated=auth_a.ensure;backend.refresh_token=auth_a.ensure;backend.token=auth_a.ensure()
   password_b=getpass.getpass('Password for SBT-peer-v051 (existing, or new research account): ')
   auth_b=Auth(target,'SBT-peer-v051',password_b,run)
   listing=subprocess.run(['docker','exec','vikunja-research-sut','/app/vikunja/vikunja','user','list'],capture_output=True,text=True,encoding='utf-8',errors='replace',check=True,timeout=30).stdout
   if 'SBT-peer-v051' not in listing:
    if len(password_b)<8 or len(password_b.encode('utf-8'))>72:raise ValueError('New research password requires at least 8 characters and at most 72 UTF-8 bytes')
    status,_=engine.request(target+'/register',method='POST',body={'username':'SBT-peer-v051','password':password_b,'email':'SBT-peer-v051@example.test'})
    engine.write(run/'account-setup-v061.json',{'username':'SBT-peer-v051','registration_http':status,'password_recorded':False})
    if status not in (200,201):raise ValueError('Research account registration unavailable; no password reset attempted')
   # Pace the second login across the shared local rate limiter.
   auth_b.pause(65);auth_b.ensure()
   backend.save('before-home-bootstrap')
   parent=run/'fresh-home-parent-v031'
   original=bootstrap.run_relations(parent,a.jar,target,uuid.uuid4().hex,backend)
   if original.get('status')!='V031_RELATION_ACCEPTANCE_COMPLETED' or original.get('semantic_candidate_count')!=0:raise ValueError('Fresh original-generator bootstrap did not pass; inspect fresh-home-parent-v031')
   journal=[json.loads(l) for l in (parent/'campaign-journal.jsonl').read_text().splitlines()]
   saved=next(e for e in journal if e['status']=='CHECKPOINT_SAVED')
   recovery={'capsule':json.loads((parent/'checkpoint-model-v031.json').read_text()),'baseline':json.loads((parent/'checkpoint-observations-v031.json').read_text()),'snapshot':{'folder':str(run/'.private-snapshots/relation-checkpoint'),'hashes':saved['data']['snapshot_hashes']},'provenance':{'fresh_home_bootstrap':True,'parent_directory':str(parent),'same_work_resource_ids':False,'bootstrap_generator':'original Context generator_v56','bootstrap_result':original['status']}}
   backend.client_auth={'A':auth_a,'B':auth_b};backend.client_tokens={'A':auth_a.ensure(),'B':auth_b.ensure()};backend.token=backend.client_tokens['A']
   recovery=prepare(target,backend,recovery,auth_a,auth_b,run)
   engine.write(run/'home-resource-bindings-v061.json',recovery['capsule']['bindings'])
   result=engine.run_relations(run,a.jar,target,uuid.uuid4().hex,backend,recovery=recovery)
 except Exception as error:
  result={'version':'v061','status':'NOT_ACCEPTED','error':str(error),'live_execution':a.live}
  engine.write(run/'launcher-error-v061.json',result)
  if not (run/'review_v061.zip').exists():engine.pack_review(run,result,[])
 print('Status:',result['status']);print('Review ZIP:',run/'review_v061.zip')
 if result.get('error'):print('Error:',result['error'])
 return 0 if result['status'] in ('V061_STATIC_READY','V061_RELATION_ACCEPTANCE_COMPLETED') else 1
if __name__=='__main__':raise SystemExit(main())
