from collections import Counter
from expand_search_v057 import catalog,validate_case
c=catalog();assert c['case_count']==112
assert Counter(x['search_metadata']['prefix_depth'] for x in c['items'])=={0:16,3:32,6:32,12:32}
groups={}
for case in c['items']:
 depth=case['search_metadata']['prefix_depth'];groups.setdefault(case['comparison_group'],[]).append(case)
 assert case['expected_checks']==70+17*len(case['steps'])
 validate_case(case)
for pair in groups.values():
 assert len(pair)==2
 depth=pair[0]['search_metadata']['prefix_depth']
 assert pair[0]['steps'][:depth]==pair[1]['steps'][:depth]
 assert pair[0]['steps'][depth:]!=pair[1]['steps'][depth:]
 assert validate_case(pair[0])==validate_case(pair[1])
print('V057_CATALOG_PASS: 112 valid plans; 56 paired prefixes and expected equivalent abstract final states')
