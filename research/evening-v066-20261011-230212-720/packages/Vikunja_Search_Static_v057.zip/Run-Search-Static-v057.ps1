param([string]$StudyRoot='D:\Yeshayahu\Temp\vikunja_tse_study',[switch]$CheckDocker)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_SEARCH_STATIC v057'
Get-Command python -ErrorAction Stop | Out-Null
& python (Join-Path $PSScriptRoot 'Verify-v057.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
if ($CheckDocker) {
    Get-Command docker -ErrorAction Stop | Out-Null
    & docker info *> $null
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'V057_DOCKER_NOT_READY; static generation can continue.'
    } else {
        & docker ps -a --filter 'name=^/vikunja-research-sut$' `
            --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
        if ($LASTEXITCODE -ne 0) {throw 'Docker status query failed.'}
        try {
            $info=Invoke-RestMethod 'http://127.0.0.1:3456/api/v1/info' -TimeoutSec 5
            Write-Host "V057_EXISTING_SERVER_VERSION: $($info.version)"
        } catch {Write-Host 'V057_SERVER_UNAVAILABLE; static generation can continue.'}
    }
}
$destination=Join-Path $StudyRoot ('generated\search-v057-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
& python (Join-Path $PSScriptRoot 'expand_search_v057.py') --output $destination
if ($LASTEXITCODE -ne 0) {throw 'Static generation failed.'}
Write-Host "Inspect every JS file under: $destination"
Write-Host 'STATIC ONLY: no credentials, Docker changes or live requests.'
