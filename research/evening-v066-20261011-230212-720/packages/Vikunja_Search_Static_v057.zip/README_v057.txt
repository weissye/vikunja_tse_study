VIKUNJA EXPANDED SEARCH v057 - STATIC DELIVERY

112 programs; 56 paired explicit action orders; four probe families;
prefix depths 0, 3, 6, 12 and two history patterns at positive depths.
Resources remain two projects, two tasks and two A-owned labels.
This broadens histories and orders, not entity coverage.

Each program retains original Context, Stories, Interfaces, DAL, independent
readback, pagination and negative type/state verifiers. All JS is emitted by
the included original generator_v56 with the versioned planning wrapper.
No generated JS is manually edited.

Depth counts state-changing HISTORY actions after a fixed four-link setup.
The setup and probe lengths are recorded separately. Reads and authentication
do not count as depth. Both order variants in a pair use the identical prefix.
Field history changes title/description. Relation history removes one label, reattaches it by its owner, then moves the task.
Three-action blocks alternate destination projects; all selected depths end
with both labels attached.

Probe families: disjoint fields on one task; different tasks; movement combined
with a field update; independent remove/reattach cycles for two labels.
These are research equivalence hypotheses, not semantic guarantees inferred
from OpenAPI alone. Route/schema/identifier information derives from the frozen
contract. Roles and history templates are explicit research inputs.

Sequential order enumeration is not true concurrency and is not evidence that
Provengo sampled distinct schedules. Models retain the original Context bthreads,
but their lifecycle coordinator requests the selected explicit order.
Each mutation has independent readback; title-array and project-id-object
negative checks remain at the end, with unchanged-state verification.

Run Run-Search-Static-v057.ps1 on Windows. Default output study root:
D:\Yeshayahu\Temp\vikunja_tse_study
Generated programs are in a new timestamped directory, preserving existing runs.
All pre-generated programs are included under generated/ for direct inspection.
Fixture identifiers describe historical evidence and MUST NOT be treated as home
server identifiers. Live execution is deliberately not exposed in this delivery.
Next step: review plans, then connect to a fresh verified home checkpoint and
the durable-evidence/restore campaign engine. Docker check belongs to that live
acceptance, not to this static generator. No home server was tested here.
