import json,re,zipfile,hashlib,collections
from pathlib import Path
from urllib.parse import urlsplit
root=Path(__file__).resolve().parent
spec=json.loads((root/'contract.json').read_text());methods={'get','post','put','patch','delete','options','head'}
ops=[]
for route,item in spec['paths'].items():
 for method,op in item.items():
  if method in methods:
   ops.append({'method':method.upper(),'path':route,'tags':op.get('tags',[]),'operation_id':op.get('operationId'),'summary':op.get('summary'),'request_evidence':[],'coverage':'NOT_OBSERVED_IN_SELECTED_REVIEWS'})
patterns=[re.compile('^'+re.sub(r'\\\{[^}]+\\\}',r'[^/]+',re.escape(o['path']))+'$') for o in ops]
unmatched=[];reviews=[]
for f in sorted(root.glob('review_v*.zip')):
 with zipfile.ZipFile(f) as z:
  version=f.stem.removeprefix('review_');manifest=json.loads(z.read('manifest_'+version+'.json'))
  for n,h in manifest.items():
   if hashlib.sha256(z.read(n.replace('\\','/'))).hexdigest()!=h:raise ValueError('Manifest mismatch '+n)
  result=json.loads(z.read('result_'+version+'.json'));reviews.append({'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'status':result['status'],'checks':result.get('checks_total')})
  for name in z.namelist():
   if name.endswith('http-evidence.json'):
    for record in json.loads(z.read(name)):
     path=urlsplit(record['path']).path
     if path.startswith('/api/v1'):path=path[len('/api/v1'):]
     matches=[i for i,o in enumerate(ops) if o['method']==record['method'] and patterns[i].fullmatch(path)]
     if len(matches)!=1:
      unmatched.append({'review':f.name,'evidence_file':name,'method':record['method'],'path':path,'matches':len(matches)});continue
     o=ops[matches[0]];o['coverage']='REQUEST_OBSERVED_ORACLE_COVERAGE_NOT_IMPLIED';o['request_evidence'].append({'review':f.name,'file':name,'index':record.get('index'),'status':record.get('status'),'actor':record.get('actor')})
def refs(v,pointer=''):
 if isinstance(v,dict):
  for k,x in v.items():
   if k=='$ref':yield {'pointer':pointer+'/$ref','target':x}
   else:yield from refs(x,pointer+'/'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):yield from refs(x,pointer+'/'+str(i))
deps=[{'schema':n,'references':list(refs(s)),'identity_status':'REQUIRES_RESOURCE_AND_ALIAS_MAPPING'} for n,s in spec.get('definitions',{}).items()]
report={'version':'v063','contract_sha256':hashlib.sha256((root/'contract.json').read_bytes()).hexdigest(),'reviews':reviews,'operation_count':len(ops),'request_observed_operations':sum(bool(o['request_evidence']) for o in ops),'schema_count':len(deps),'operations':ops,'schema_dependencies':deps,'unmatched_requests':unmatched,'limits':['Only reviews 060, 061, 062 mapped; older evidence not counted','Observed request does not imply semantic or negative coverage','Schema reference does not establish resource creation dependency','Current scheduling is sequential; concurrency not covered']}
(root/'COVERAGE_v063.json').write_text(json.dumps(report,indent=2))
lines=['# Coverage v063','',f"Contract operations: {len(ops)}. Operations observed in reviews 060–062: {report['request_observed_operations']}. Schemas: {len(deps)}.",'','Request observation is not full test coverage. Unmatched requests: '+str(len(unmatched)), '', '| Method | Route | Requests observed |','|---|---|---:|']
lines += [f"| {o['method']} | `{o['path']}` | {len(o['request_evidence'])} |" for o in ops]
lines += ['','## Expansion plan','','1. Resolve each schema to resource identities and aliases; retain unresolved classifications.','2. Map every operation to prerequisites, credentials, create/readback routes, and a justified oracle.','3. Generate Context, Stories, Interfaces, DAL and verifiers per executable resource family.','4. Add positive lifecycle and contract type/constraint tests per supported operation.','5. Expand links across projects, tasks, labels, assignees, comments, attachments, relations and views when their prerequisites are verified.','6. Cover depths 0, 3, 6, 12 and alternative histories, preserving failure evidence and verified recovery.','7. Evaluate two authorized users and separate sessions, then actual concurrent dispatch with overlap evidence.','8. Report each coverage dimension separately, including blocked and undetermined cases.','','Priority follows contract prerequisites and observable readback, not an assumption that all schemas are resources. Full live coverage remains unfinished.']
(root/'COVERAGE_v063.md').write_text('\n'.join(lines))
print('V063_COVERAGE_ANALYZED',report['request_observed_operations'],'/',len(ops),'operations;',len(unmatched),'unmatched; NOT FULL COVERAGE')
