$ErrorActionPreference = 'Stop'
Write-Host 'VIKUNJA_COVERAGE v063'
& python (Join-Path $PSScriptRoot 'Analyze-Coverage-v063.py')
if ($LASTEXITCODE -ne 0) { throw 'Coverage analysis failed.' }
