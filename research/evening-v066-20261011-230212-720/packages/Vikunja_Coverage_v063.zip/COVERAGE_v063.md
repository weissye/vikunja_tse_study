# Coverage v063

Contract operations: 170. Operations observed in reviews 060–062: 13. Schemas: 98.

Request observation is not full test coverage. Unmatched requests: 6

| Method | Route | Requests observed |
|---|---|---:|
| GET | `/admin/overview` | 0 |
| GET | `/admin/projects` | 0 |
| PATCH | `/admin/projects/{id}/owner` | 0 |
| GET | `/admin/users` | 0 |
| POST | `/admin/users` | 0 |
| DELETE | `/admin/users/{id}` | 0 |
| PATCH | `/admin/users/{id}/admin` | 0 |
| PATCH | `/admin/users/{id}/status` | 0 |
| POST | `/auth/openid/{provider}/callback` | 0 |
| GET | `/backgrounds/unsplash/image/{image}` | 0 |
| GET | `/backgrounds/unsplash/image/{image}/thumb` | 0 |
| GET | `/backgrounds/unsplash/search` | 0 |
| PUT | `/filters` | 0 |
| GET | `/filters/{id}` | 0 |
| POST | `/filters/{id}` | 0 |
| DELETE | `/filters/{id}` | 0 |
| GET | `/info` | 0 |
| GET | `/labels` | 0 |
| PUT | `/labels` | 6 |
| GET | `/labels/{id}` | 60 |
| PUT | `/labels/{id}` | 0 |
| DELETE | `/labels/{id}` | 0 |
| POST | `/login` | 0 |
| PUT | `/migration/csv/detect` | 0 |
| PUT | `/migration/csv/migrate` | 0 |
| PUT | `/migration/csv/preview` | 0 |
| GET | `/migration/csv/status` | 0 |
| GET | `/migration/microsoft-todo/auth` | 0 |
| POST | `/migration/microsoft-todo/migrate` | 0 |
| GET | `/migration/microsoft-todo/status` | 0 |
| PUT | `/migration/ticktick/migrate` | 0 |
| GET | `/migration/ticktick/status` | 0 |
| GET | `/migration/todoist/auth` | 0 |
| POST | `/migration/todoist/migrate` | 0 |
| GET | `/migration/todoist/status` | 0 |
| GET | `/migration/trello/auth` | 0 |
| POST | `/migration/trello/migrate` | 0 |
| GET | `/migration/trello/status` | 0 |
| POST | `/migration/vikunja-file/migrate` | 0 |
| GET | `/migration/vikunja-file/status` | 0 |
| PUT | `/migration/wekan/migrate` | 0 |
| GET | `/migration/wekan/status` | 0 |
| GET | `/notifications` | 0 |
| POST | `/notifications` | 0 |
| DELETE | `/notifications` | 0 |
| POST | `/notifications/{id}` | 0 |
| GET | `/projects` | 0 |
| PUT | `/projects` | 6 |
| GET | `/projects/{id}` | 228 |
| POST | `/projects/{id}` | 6 |
| DELETE | `/projects/{id}` | 0 |
| GET | `/projects/{id}/background` | 0 |
| DELETE | `/projects/{id}/background` | 0 |
| POST | `/projects/{id}/backgrounds/unsplash` | 0 |
| PUT | `/projects/{id}/backgrounds/upload` | 0 |
| GET | `/projects/{id}/projectusers` | 0 |
| PUT | `/projects/{id}/tasks` | 6 |
| GET | `/projects/{id}/teams` | 0 |
| PUT | `/projects/{id}/teams` | 0 |
| GET | `/projects/{id}/users` | 0 |
| PUT | `/projects/{id}/users` | 0 |
| GET | `/projects/{id}/views/{view}/buckets` | 0 |
| PUT | `/projects/{id}/views/{view}/buckets` | 0 |
| GET | `/projects/{id}/views/{view}/tasks` | 312 |
| GET | `/projects/{id}/webhooks` | 0 |
| PUT | `/projects/{id}/webhooks` | 0 |
| POST | `/projects/{id}/webhooks/{webhookID}` | 0 |
| DELETE | `/projects/{id}/webhooks/{webhookID}` | 0 |
| PUT | `/projects/{projectID}/duplicate` | 0 |
| POST | `/projects/{projectID}/teams/{teamID}` | 0 |
| DELETE | `/projects/{projectID}/teams/{teamID}` | 0 |
| POST | `/projects/{projectID}/users/{userID}` | 0 |
| DELETE | `/projects/{projectID}/users/{userID}` | 0 |
| POST | `/projects/{projectID}/views/{view}/buckets/{bucketID}` | 0 |
| DELETE | `/projects/{projectID}/views/{view}/buckets/{bucketID}` | 0 |
| GET | `/projects/{project}/shares` | 0 |
| PUT | `/projects/{project}/shares` | 0 |
| GET | `/projects/{project}/shares/{share}` | 0 |
| DELETE | `/projects/{project}/shares/{share}` | 0 |
| GET | `/projects/{project}/tasks/by-index/{index}` | 0 |
| GET | `/projects/{project}/views` | 192 |
| PUT | `/projects/{project}/views` | 0 |
| GET | `/projects/{project}/views/{id}` | 0 |
| POST | `/projects/{project}/views/{id}` | 0 |
| DELETE | `/projects/{project}/views/{id}` | 0 |
| POST | `/projects/{project}/views/{view}/buckets/{bucket}/tasks` | 0 |
| POST | `/register` | 0 |
| GET | `/routes` | 0 |
| POST | `/shares/{share}/auth` | 0 |
| PUT | `/subscriptions/{entity}/{entityID}` | 0 |
| DELETE | `/subscriptions/{entity}/{entityID}` | 0 |
| GET | `/tasks` | 0 |
| POST | `/tasks/bulk` | 0 |
| GET | `/tasks/{id}` | 252 |
| POST | `/tasks/{id}` | 38 |
| DELETE | `/tasks/{id}` | 0 |
| GET | `/tasks/{id}/attachments` | 0 |
| PUT | `/tasks/{id}/attachments` | 0 |
| GET | `/tasks/{id}/attachments/{attachmentID}` | 0 |
| DELETE | `/tasks/{id}/attachments/{attachmentID}` | 0 |
| POST | `/tasks/{id}/position` | 0 |
| POST | `/tasks/{projecttask}/read` | 0 |
| GET | `/tasks/{taskID}/assignees` | 0 |
| PUT | `/tasks/{taskID}/assignees` | 0 |
| POST | `/tasks/{taskID}/assignees/bulk` | 0 |
| DELETE | `/tasks/{taskID}/assignees/{userID}` | 0 |
| GET | `/tasks/{taskID}/comments` | 0 |
| PUT | `/tasks/{taskID}/comments` | 0 |
| GET | `/tasks/{taskID}/comments/{commentID}` | 0 |
| POST | `/tasks/{taskID}/comments/{commentID}` | 0 |
| DELETE | `/tasks/{taskID}/comments/{commentID}` | 0 |
| PUT | `/tasks/{taskID}/duplicate` | 0 |
| POST | `/tasks/{taskID}/labels/bulk` | 0 |
| PUT | `/tasks/{taskID}/relations` | 0 |
| DELETE | `/tasks/{taskID}/relations/{relationKind}/{otherTaskID}` | 0 |
| GET | `/tasks/{task}/labels` | 432 |
| PUT | `/tasks/{task}/labels` | 38 |
| DELETE | `/tasks/{task}/labels/{label}` | 14 |
| GET | `/teams` | 0 |
| PUT | `/teams` | 0 |
| GET | `/teams/{id}` | 0 |
| POST | `/teams/{id}` | 0 |
| DELETE | `/teams/{id}` | 0 |
| PUT | `/teams/{id}/members` | 0 |
| POST | `/teams/{id}/members/{userID}/admin` | 0 |
| DELETE | `/teams/{id}/members/{username}` | 0 |
| DELETE | `/test/all` | 0 |
| PATCH | `/test/{table}` | 0 |
| GET | `/tokens` | 0 |
| PUT | `/tokens` | 0 |
| DELETE | `/tokens/{tokenID}` | 0 |
| GET | `/user` | 0 |
| POST | `/user/confirm` | 0 |
| POST | `/user/deletion/cancel` | 0 |
| POST | `/user/deletion/confirm` | 0 |
| POST | `/user/deletion/request` | 0 |
| GET | `/user/export` | 0 |
| POST | `/user/export/download` | 0 |
| POST | `/user/export/request` | 0 |
| POST | `/user/logout` | 0 |
| POST | `/user/password` | 0 |
| POST | `/user/password/reset` | 0 |
| POST | `/user/password/token` | 0 |
| GET | `/user/settings/avatar` | 0 |
| POST | `/user/settings/avatar` | 0 |
| PUT | `/user/settings/avatar/upload` | 0 |
| POST | `/user/settings/email` | 0 |
| POST | `/user/settings/general` | 0 |
| GET | `/user/settings/token/caldav` | 0 |
| PUT | `/user/settings/token/caldav` | 0 |
| DELETE | `/user/settings/token/caldav/{id}` | 0 |
| GET | `/user/settings/totp` | 0 |
| POST | `/user/settings/totp/disable` | 0 |
| POST | `/user/settings/totp/enable` | 0 |
| POST | `/user/settings/totp/enroll` | 0 |
| GET | `/user/settings/totp/qrcode` | 0 |
| GET | `/user/settings/webhooks` | 0 |
| PUT | `/user/settings/webhooks` | 0 |
| GET | `/user/settings/webhooks/events` | 0 |
| POST | `/user/settings/webhooks/{id}` | 0 |
| DELETE | `/user/settings/webhooks/{id}` | 0 |
| GET | `/user/timezones` | 0 |
| POST | `/user/token` | 0 |
| POST | `/user/token/refresh` | 0 |
| GET | `/users` | 0 |
| GET | `/webhooks/events` | 0 |
| GET | `/{kind}/{id}/reactions` | 0 |
| PUT | `/{kind}/{id}/reactions` | 0 |
| POST | `/{kind}/{id}/reactions/delete` | 0 |
| GET | `/{username}/avatar` | 0 |

## Expansion plan

1. Resolve each schema to resource identities and aliases; retain unresolved classifications.
2. Map every operation to prerequisites, credentials, create/readback routes, and a justified oracle.
3. Generate Context, Stories, Interfaces, DAL and verifiers per executable resource family.
4. Add positive lifecycle and contract type/constraint tests per supported operation.
5. Expand links across projects, tasks, labels, assignees, comments, attachments, relations and views when their prerequisites are verified.
6. Cover depths 0, 3, 6, 12 and alternative histories, preserving failure evidence and verified recovery.
7. Evaluate two authorized users and separate sessions, then actual concurrent dispatch with overlap evidence.
8. Report each coverage dimension separately, including blocked and undetermined cases.

Priority follows contract prerequisites and observable readback, not an assumption that all schemas are resources. Full live coverage remains unfinished.

Six unmatched requests are POST /labels/{id}. The live method adapter used by the generator is included; these requests are retained separately from exact contract matches. Authentication and sharing setup traces need additional mapping. No operation is declared fully verified by request counts alone.
