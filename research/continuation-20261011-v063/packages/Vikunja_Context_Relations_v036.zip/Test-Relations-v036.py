import sys,tempfile,copy,json,re
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));import relation_engine_v036 as e
from generate_v036 import catalog

def test(resume=False, infrastructure=False, uncertain=False):
 with tempfile.TemporaryDirectory() as directory:
  run=Path(directory);resources=[];bindings={};state={'objects':{},'links':{'31':[],'32':[]}};restores=[]
  for typ,ids in [('ModelsProject',[1,2]),('ModelsTask',[31,32]),('ModelsLabel',[10,11])]:
   for i,id in enumerate(ids,1):
    logical=typ+'_'+str(i);expected={'title':'baseline'}
    if typ=='ModelsTask':expected['project_id']=1
    path='/'+{'ModelsProject':'projects','ModelsTask':'tasks','ModelsLabel':'labels'}[typ]+'/{id}'
    resources.append({'logicalId':logical,'resourceType':typ,'expected':expected,'revision':2,'verifiedRevision':2,'detail_template':path,'route_parameter':'id'})
    bindings['ROUTE_'+logical]=id;bindings['ID_'+logical]=id;bindings['SNAPSHOT_'+logical]='{}';state['objects'][path.replace('{id}',str(id))]=dict(id=id,**expected)
  capsule={'resources':sorted(resources,key=lambda r:r['logicalId']),'bindings':bindings,'relations':[]}
  class Backend:
   fixture_only=True;token='fixture'
   def ensure_authenticated(self):return 'fixture'
   def save(self,label):return {'folder':label,'hashes':{},'data':copy.deepcopy(state)}
   def restore(self,snapshot):state.clear();state.update(copy.deepcopy(snapshot['data']));restores.append(snapshot['folder'])
  original_request=e.request;original_run=e.subprocess.run
  def request(url,method='GET',body=None,token=None):
   if not url.startswith('http://fixture'):return original_request(url,method,body,token)
   path=url[len('http://fixture'):];match=re.fullmatch(r'/tasks/(\d+)/labels(?:/(\d+))?',path)
   if match:
    task,label=match.groups()
    if method=='PUT':state['links'][task].append(int(body['label_id']));return 201,b'{}'
    if method=='DELETE':
     state['links'][task]=[x for x in state['links'][task] if x!=int(label)]
     # First label fixture simulates a cross-resource semantic bug.
     if label=='10' and calls[0]==1:state['links'][task]=[]
     return 200,b'{}'
    return 200,json.dumps([state['objects']['/labels/'+str(id)] for id in state['links'][task]]).encode()
   if method=='DELETE':
    label=int(path.rsplit('/',1)[-1]);state['objects'].pop(path,None)
    for task in state['links']:state['links'][task]=[x for x in state['links'][task] if x!=label]
    if calls[0]==1 and not uncertain:state['links']['31']=[]
    return 200,b'{}'
   if path not in state['objects']:return (403 if uncertain else 404),b'{}'
   return 200,json.dumps(state['objects'][path]).encode()
  calls=[0]
  def native(cmd,**kw):
   if cmd[0]!='java':return original_run(cmd,**kw)
   index=calls[0];calls[0]+=1;project=Path(cmd[-1]);plan=json.loads((project.parent/'checkpoint-plan-v036.json').read_text());proxy=json.loads((project/'spec/js/generation_report.json').read_text())['checkpoint_acceptance']['proxy'] if False else None
   text=(project/'spec/js/interfaces.vikunja.js').read_text();proxy=re.search(r'new RESTSession\("([^"]+)"',text).group(1)
   if plan['mode']=='bootstrap':e.json_request(proxy+'/__checkpoint/save',method='POST',body=capsule,token='credential')
   else:e.json_request(proxy+'/__checkpoint/resume',token='credential');e.json_request(proxy+'/__checkpoint/verify',token='credential')
   checks=[];stopped=False
   for step in plan['steps']:
    task=str(bindings['ID_'+step['task']]);other=str(bindings['ID_'+step['other_task']]);label=bindings['ID_'+step['label']];present=step['present'];update=step.get('action')=='update_target';delete=step.get('action')=='delete_target'
    mutation='/labels/'+str(label) if update or delete else '/tasks/'+task+'/labels'+('' if present else '/'+str(label))
    status,_=e.request(proxy+mutation,method='DELETE' if delete else 'POST' if update else 'PUT' if present else 'DELETE',body=step['update'] if update else {'label_id':label} if present else None,token='credential');checks.append({'name':'write','pass':True,'status':status})
    expectations=[('/tasks/'+task+'/labels',[bindings['ID_'+x] for x in step['expected_labels']],'membership'),('/tasks/'+task,None,'projection'),('/tasks/'+other+'/labels',[bindings['ID_'+x] for x in step['other_labels']],'membership'),('/labels/'+str(label),None,'projection')]
    if delete:expectations[-1]=('/labels/'+str(label),404,'absence');expectations += [('/tasks/'+other,None,'projection'),('/labels/'+str(bindings['ID_'+step['survivor']]),None,'projection'),('/tasks/'+task,None,'projection'),('/tasks/'+other,None,'projection')]
    if update:expectations += [('/tasks/'+task+'/labels',None,'projection'),('/tasks/'+other+'/labels',None,'projection')]
    for path,wanted,kind in expectations:
     status,body=e.request(proxy+path,token='credential');actual=json.loads(body);passed=(None if status==403 else status==404) if kind=='absence' else True if kind=='projection' else [x['id'] for x in actual]==wanted
     checks.append({'name':path,'pass':passed,'status':status})
     if passed is False:stopped=True;break
    if stopped:break
   log='RELATION_CONTEXT '+json.dumps(capsule['resources'])+'\n'+'\n'.join('RELATION_CHECK '+json.dumps(c) for c in checks)
   if not stopped:log+='\nRELATION_CASE_COMPLETED '+plan['case_id']+'\nTest Result: SUCCESS'
   if infrastructure:return SimpleNamespace(returncode=1,stdout='Native infrastructure error',stderr='')
   return SimpleNamespace(returncode=1 if stopped else 0,stdout=log,stderr='')
  e.request=request;e.subprocess.run=native
  recovery=dict(capsule=capsule,snapshot=Backend().save('original-checkpoint'),baseline={'resources':{r['logicalId']:state['objects'][r['detail_template'].replace('{id}',str(bindings['ROUTE_'+r['logicalId']]))] for r in resources},'memberships':{'ModelsTask_1':[],'ModelsTask_2':[]}},provenance={'fixture':True}) if resume else None
  try:result=e.run_relations(run,run/'fixture.jar','http://fixture','credential',Backend(),recovery=recovery)
  finally:e.request=original_request;e.subprocess.run=original_run
  if infrastructure:
   assert result['status']=='NOT_ACCEPTED' and result['baseline_restored_after_error'],result
   assert not any(state['links'].values()) and restores
   print('V036_INFRASTRUCTURE_FIXTURE_PASS: interrupted mutation preserved then baseline restored');return
  assert result['status']=='V036_RELATION_ACCEPTANCE_COMPLETED',result
  if uncertain:
   assert result['absence_undetermined_count']==2 and result['semantic_candidate_count']==0 and result['semantic_checks']==58,result
   outcomes=json.loads((run/'outcomes_v036.json').read_text());assert all(o['classification']=='COMPLETED_WITH_ABSENCE_UNDETERMINED' for o in outcomes)
   print('V036_UNCERTAINTY_FIXTURE_PASS: 403 retained, all 58 checks completed, not counted as semantic bugs');return
  outcomes=json.loads((run/'outcomes_v036.json').read_text());assert [o['classification'] for o in outcomes]==['SEMANTIC_CANDIDATE','PASS'];assert len(restores)==(3 if resume else 2);assert not any(state['links'].values())
  assert result['completed_cases']==2
  print('V036_SUPERVISOR_FIXTURE_PASS: shared relation failure retained, checkpoint/relations restored, both cases continued')
if __name__=='__main__':test();test(True);test(True,True);test(True,False,True)
