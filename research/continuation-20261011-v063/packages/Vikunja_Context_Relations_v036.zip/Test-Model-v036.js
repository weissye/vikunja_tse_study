const fs=require('fs'),vm=require('vm');
const catalog=JSON.parse(fs.readFileSync(process.argv[2]));
function test(caseItem,bug){
 const evidence=[], values={ID_ModelsTask_1:410,ID_ModelsTask_2:411,ID_ModelsLabel_1:124,ID_ModelsLabel_2:123,ROUTE_ModelsTask_1:410,ROUTE_ModelsTask_2:411,ROUTE_ModelsLabel_1:124,ROUTE_ModelsLabel_2:123};
 const models={};for(const logical of Object.keys(values).filter(k=>k.startsWith('ID_')).map(k=>k.slice(3)))models[logical]={expected:{title:'baseline',description:'old',...(logical.includes('Task')?{project_id:76}:{})}};
 const labels={124:{id:124,title:'baseline',description:'old'},123:{id:123,title:'baseline',description:'old'}};const links={410:[],411:[]};
 const c={RESTSession:function(url,name,options){this.baseURL=url;this.defaultHeaders=options.headers;},svc:{baseURL:'http://fixture',defaultHeaders:{}},bp:{EventSet:function(){},log:{info:x=>evidence.push(x)}},pvg:{rtv:{get:k=>values[k]},fail:m=>{throw Error(m)}},getModelEntity:id=>models[id]};
 vm.createContext(c);vm.runInContext(fs.readFileSync(process.argv[3],'utf8'),c);
 c.requestRest=function(method,path,body,codes,meta,callback){
  path=path.replace(/@\{([^}]+)\}/g,(_,k)=>values[k]);body=body===undefined?undefined:JSON.parse(JSON.stringify(body).replace(/@\{([^}]+)\}/g,(_,k)=>values[k]));
  const match=path.match(/^\/tasks\/(\d+)\/labels(?:\/(\d+))?$/);let actual,status=200;
  if(match){const t=match[1],l=match[2];if(method==='PUT'){links[t].push(Number(body.label_id));status=201;actual={};}else if(method==='DELETE'){links[t]=links[t].filter(x=>x!==Number(l));if(bug==='remove-all')links[t]=[];actual={};}else actual=links[t].map(id=>({...labels[id],...(bug==='stale-embedded'&&labels[id].description!=='old'?{description:'old'}:{})}));}
  else if(path.startsWith('/labels/')){const id=path.split('/').pop();if(method==='DELETE'){if(bug!=='deleted-still-readable')delete labels[id];for(const task of Object.keys(links))links[task]=links[task].filter(x=>x!==Number(id));if(bug==='remove-all')for(const task of Object.keys(links))links[task]=[];actual={};}else{if(method!=='GET')Object.assign(labels[id],body);actual=labels[id];if(!actual){actual={message:'not found'};status=bug==='absence-403'?403:404;}}}
  else{const id=path.split('/').pop();actual={id:Number(id),title:'baseline',description:'old',project_id:76,labels:links[id].map(x=>labels[x])};}
  if(callback)callback({code:status,body:JSON.stringify(actual)});return null;
 };
 let failed=false;
 try{for(const step of caseItem.steps){const data={...step,id:caseItem.case_id};c.relationMutation(data);if(step.action==='update_target')Object.assign(models[step.label].expected,step.update);c.verifyRelation(data);}}catch(e){failed=true;if(!bug)throw e;}
 if(bug==='absence-403'){if(failed)throw Error('403 blocked remaining checks');const checks=evidence.filter(x=>x.startsWith('RELATION_CHECK ')).map(x=>JSON.parse(x.slice(15)));if(checks.length!==caseItem.expected_checks||checks.filter(x=>x.pass===null&&x.classification==='ABSENCE_UNDETERMINED').length!==1)throw Error('403 evidence lost');}else if(bug&&!failed)throw Error('Verifier missed '+bug);
 if(!bug&&evidence.filter(x=>x.startsWith('RELATION_CHECK ')).length!==caseItem.expected_checks)throw Error('Check count differs');
 return evidence;
}
for(const item of catalog.items){test(item);test(item,'absence-403');}
test(catalog.items[0],'remove-all');test(catalog.items[1],'deleted-still-readable');
console.log('V036_GENERATED_INTERFACE_FIXTURE_PASS: 58 checks; collateral relation loss and still-readable deleted label detected. Not native Provengo.');
