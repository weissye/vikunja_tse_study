const fs=require('fs'),vm=require('vm');
const catalog=JSON.parse(fs.readFileSync(process.argv[2]));
function test(item,bug){
 const logs=[],values={},models={},labels={10:{id:10,title:'baseline',description:'old'},11:{id:11,title:'baseline',description:'old'}},links={31:[],32:[]};
 for(const [type,ids] of [['ModelsTask',[31,32]],['ModelsLabel',[10,11]]])for(let i=0;i<2;i++){
  const id=ids[i],logical=type+'_'+(i+1);values['ID_'+logical]=values['ROUTE_'+logical]=id;models[logical]={expected:{title:'baseline',description:'old',...(type==='ModelsTask'?{project_id:1}:{})}};
 }
 const c={RESTSession:function(){},bp:{EventSet:function(){},log:{info:s=>logs.push(s)}},pvg:{rtv:{get:k=>values[k]},fail:m=>{throw Error(m);}},getModelEntity:id=>models[id]};
 vm.createContext(c);vm.runInContext(fs.readFileSync(process.argv[3],'utf8'),c);
 c.requestRest=function(method,path,body,codes,meta,callback){
  path=path.replace(/@\{([^}]+)\}/g,(_,k)=>values[k]);if(body!==undefined)body=JSON.parse(JSON.stringify(body).replace(/@\{([^}]+)\}/g,(_,k)=>values[k]));
  let status=200,actual;const match=path.match(/^\/tasks\/(\d+)\/labels(?:\/(\d+))?$/);
  if(match){const task=match[1],label=match[2];if(method==='PUT'){links[task].push(Number(body.label_id));status=201;actual={};}
   else if(method==='DELETE'){links[task]=links[task].filter(x=>x!==Number(label));if(bug==='collateral')links[task]=[];actual={};}
   else actual=links[task].map(id=>({...labels[id],...(bug==='stale-view'&&labels[id].description!=='old'?{description:'old'}:{})}));
  }else if(path.startsWith('/labels/')){
   const id=path.split('/').pop();if(method==='POST'){if(body.title!=='baseline')throw Error('Missing required valid title');if(bug!=='lost-update')Object.assign(labels[id],body);if(bug==='reattach-on-update')for(const t of Object.keys(links))if(!links[t].includes(Number(id)))links[t].push(Number(id));}actual=labels[id];
  }else actual={id:Number(path.split('/').pop()),title:'baseline',description:'old',project_id:1};
  callback({code:status,body:JSON.stringify(actual)});
 };
 let failed=false;
 try{for(const step of item.steps){const pending={...step,id:item.case_id};c.relationMutation(pending);if(step.action==='update_target')Object.assign(models[step.label].expected,step.update);c.verifyRelation(pending);}}catch(e){failed=true;if(!bug)throw e;}
 if(bug&&!failed)throw Error('Verifier missed '+bug);
 if(!bug){const checks=logs.filter(s=>s.startsWith('RELATION_CHECK ')).map(s=>JSON.parse(s.slice(15)));if(checks.length!==54||checks.some(x=>x.pass!==true))throw Error('Check mismatch');if(!checks.some(x=>x.kind==='embedded_projection'&&x.expected.present===false))throw Error('Missing detached observation');}
}
for(const item of catalog.items)for(const bug of [null,'collateral','stale-view','lost-update','reattach-on-update'])test(item,bug);
console.log('V039_GENERATED_INTERFACE_FIXTURE_PASS: 108 checks; detached/shared update, stale view, lost update and collateral link loss verified. Not native/live.');
