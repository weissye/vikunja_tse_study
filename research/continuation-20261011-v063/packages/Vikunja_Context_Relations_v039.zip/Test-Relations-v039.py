import json
from relation_engine_v039 import collect_visible_labels

def page(items,status=200):return status,json.dumps(items).encode()
calls=[]
def fetch(path):
 calls.append(path)
 return page([{'id':1}]) if len(calls)==1 else page([{'id':2}]) if len(calls)==2 else page([])
x=collect_visible_labels(fetch)
assert x['complete'] and x['ids']==['1','2'] and len(calls)==3
assert not collect_visible_labels(lambda _:page([{'id':1}]))['complete']
assert not collect_visible_labels(lambda _:page([],429))['complete']
assert not collect_visible_labels(lambda _: (200,b'null'))['complete']
assert not collect_visible_labels(lambda _:page([{'id':'1'}]))['complete']
assert not collect_visible_labels(lambda _:page([{'id':1}]),max_pages=1)['complete']
assert collect_visible_labels(lambda _:page([]))['complete']
print('V039_PAGINATION_FIXTURE_PASS: short page continues; duplicate, invalid schema, rate limit and cap remain undetermined. Not live.')
