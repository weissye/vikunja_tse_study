VIKUNJA CONTEXT RELATIONS v039
Original generator retained: Stories, Interfaces, DAL, Context and independent verifiers.
Two mirrored history cases (active label 1 or 2); 10 mutation steps / 54 checks each.
1 attach active label task1; 2 attach active label task2;
3 attach passive label task1; 4 attach passive label task2;
5 update shared active description; 6 detach active from task1;
7 update active again while task1 detached; 8 reattach active to task1;
9 detach active from task2; 10 reattach active to task2.
After every mutation: both memberships, subject task projected state, target label projected state.
After each update: two extra collection-view checks; linked task must see updated projection,
unlinked task must not acquire the label. Context expected state updated through DAL effect.
Every marker identifies case and mutation step; independent verifier gates next mutation.
54 checks/case, 108 total. Original six IDs and checkpoint; no resource recreation or prefix replay.
Run-to-run snapshot reset remains strict. Each next case proceeds only after restored baseline verified.
Contract status audit records every real HTTP request and operation JSON pointer separately from
semantic verdict. Explicit label POST-to-documented-PUT adapter retained from live OPTIONS evidence.
v038-retrospective-status-audit.json records two undocumented GET 404 observations from unchanged
accepted-review-v038.zip. Status documentation deviations are not automatically semantic bugs.
Scope and history template are explicit method inputs; paths/schemas/dependencies derive from contract.
Ordered histories, seed 1, two instances; no claim of true concurrency, schedule search, parameterized
prefix-depth comparison or full-system coverage. This is a longer controlled state history.
Pagination observer stays in Python HTTP adapter; all generated JS is reproduced by original generator.
Local fixture tests passed. Native/live v039 execution still requires the Windows workstation.
Use top Run-Relations-v039.ps1 (static), then -RunLive. Upload review_v039.zip.
All generated JS is in generated-resume/case-1 and case-2/project/spec/js plus bootstrap generated/.
Never edit generated JS by hand; change generator/template and regenerate.
