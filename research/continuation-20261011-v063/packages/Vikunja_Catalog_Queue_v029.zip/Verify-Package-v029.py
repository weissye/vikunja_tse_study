import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_v029.json').read_text())
for name,expected in manifest.items():
 actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
 if actual!=expected:raise SystemExit('Package mismatch: '+name)
print('V029_PACKAGE_INTEGRITY_PASS',len(manifest))
