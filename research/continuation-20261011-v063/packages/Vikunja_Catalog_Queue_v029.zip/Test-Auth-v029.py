import tempfile,json
from pathlib import Path
from auth_v029 import Auth
with tempfile.TemporaryDirectory() as directory:
 run=Path(directory);now=[0];calls=[];responses=[]
 def sleep(seconds):now[0]+=seconds
 auth=Auth('http://fixture','test','private',run,lambda:now[0],sleep)
 def call(path,body=None,token=None):
  calls.append(path)
  return responses.pop(0)
 auth.call=call
 responses.extend([(200,b'{"token":"private-token"}',{}),(200,b'{}',{}),(200,b'{}',{})])
 assert auth.ensure()=='private-token';auth.ensure();assert calls==['/login','/user','/user']
 calls.clear();responses.extend([(401,b'{}',{}),(429,b'{}',{'Retry-After':'70'}),(200,b'{"token":"new-token"}',{}),(200,b'{}',{})])
 assert auth.ensure()=='new-token';assert calls==['/user','/login','/login','/user'];assert now[0]>=135
 text=(run/'authentication-v029.jsonl').read_text();assert 'private' not in text and 'new-token' not in text
 print('V029_AUTH_FIXTURE_PASS: token reuse, expiry refresh, paced Retry-After, no mutation replay, no credentials logged')
