import argparse,json,sys,hashlib,getpass,uuid,os,shutil
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_work_v023 as storage
import queue_engine_v029 as engine
from run_queue_v028 import load_parent as load_original

def load_parent(parent):
 def read(name):return json.loads((parent/name).read_text(encoding='utf-8'))
 if storage.sha(parent/'manifest_v028.json')!='aa1eed54684cf39ecfa0530da78dc94f33d2d0d971fa68fec369fa4e8520b4a0':raise ValueError('Expected accepted v028 manifest differs')
 for name,expected in read('manifest_v028.json').items():
  rel=PurePosixPath(name.replace('\\','/'))
  if rel.is_absolute() or '..' in rel.parts or ':' in name:raise ValueError('Unsafe evidence path')
  if storage.sha(parent.joinpath(*rel.parts))!=expected:raise ValueError('Parent evidence mismatch: '+name)
 origin=Path(read('parent-provenance.json')['parent_directory'])
 queue,recovery=load_original(origin)
 if read('queue_v028.json')!=queue:raise ValueError('Queue changed')
 outcomes=read('outcomes_v028.json');progress=read('queue-progress-v028.json')
 if len(outcomes)!=147 or outcomes[:139]!=recovery['outcomes']:raise ValueError('Historical outcomes changed')
 ids=[x['queue_id'] for x in queue['items']]
 if [o['queue_id'] for o in outcomes]!=ids[:147] or progress!=dict(completed_queue_ids=ids[:147],remaining_queue_ids=ids[147:],next_index=147,same_baseline_verified=True):raise ValueError('Progress mismatch')
 journal=[json.loads(l) for l in (parent/'campaign-journal.jsonl').read_text().splitlines()];previous=None
 for i,e in enumerate(journal):
  if e['index']!=i or e['previous']!=previous or e['sha256']!=engine.digest({k:v for k,v in e.items() if k!='sha256'}):raise ValueError('Parent journal mismatch')
  previous=e['sha256']
 checks=[e for e in journal if e['status'] in ('RULE_PASSED','RULE_FAILED')]
 if len(checks)!=8:raise ValueError('Expected eight current checks')
 for o,e,item in zip(outcomes[139:],checks,queue['items'][139:]):
  if o['rule_id']!=item['rule_id'] or o['logical_id']!=item['logical_id'] or e['data']['queue_id']!=o['queue_id'] or e['data']['check_sha256']!=engine.digest(o['check']):raise ValueError('Current outcome mismatch')
 baseline=[e for e in journal if e['status']=='BASELINE_VERIFIED']
 if len(baseline)!=8 or baseline[-1]['data']['queue_id']!=ids[146] or baseline[-1]['data']['observations_sha256']!=engine.digest(recovery['observations']):raise ValueError('Baseline verification missing')
 if read('snapshot-adapter.json')!=recovery['adapter']:raise ValueError('Parent storage identity changed')
 recovery['outcomes']=outcomes
 recovery['provenance']={'parent_directory':str(parent),'parent_manifest_sha256':storage.sha(parent/'manifest_v028.json'),'parent_journal_tip':previous,'next_index':147,'next_queue_id':ids[147],'original_checkpoint':str(origin)}
 return queue,recovery

def main():
 p=argparse.ArgumentParser();p.add_argument('--study-root',required=True,type=Path);p.add_argument('--jar',required=True,type=Path);p.add_argument('--resume-from',required=True,type=Path);p.add_argument('--live',action='store_true');a=p.parse_args()
 run=a.study_root/'runs'/('catalog-queue-v029-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True)
 try:
  queue,recovery=load_parent(a.resume_from.resolve())
  engine.write(run/'queue_v029.json',queue);engine.write(run/'parent-provenance.json',recovery['provenance'])
  shutil.copy2(a.resume_from/'review_v028.zip',run/'parent-review-v028.zip')
  print('Verified completed checks:',len(recovery['outcomes']),flush=True);print('Next check:',len(recovery['outcomes'])+1,flush=True)
  if not a.live:
   result={'version':'v029','status':'V029_RESUME_INPUT_VERIFIED','live_execution':False};engine.pack_review(run,result,[])
  else:
   if os.name!='nt':raise ValueError('Work adapter requires Windows')
   if storage.sha(a.jar)!='dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b':raise ValueError('JAR mismatch')
   target='http://127.0.0.1:3456/api/v1';status,contract=engine.request(target+'/docs.json')
   if status!=200 or hashlib.sha256(contract).hexdigest()!=storage.sha(ROOT/'engine-v010'/'vikunja-live-swagger.json'):raise ValueError('Live contract mismatch')
   backend=storage.BindBackend('vikunja-research-sut',target,run)
   current=json.loads((run/'snapshot-adapter.json').read_text())
   if current!=recovery['adapter']:raise ValueError('Server image/storage identity differs from parent')
   password=getpass.getpass('Vikunja password for SBT-tester: ')
   from auth_v029 import Auth
   auth=Auth(target,'SBT-tester',password,run)
   backend.ensure_authenticated=auth.ensure;backend.refresh_token=auth.ensure;backend.token=auth.ensure()
   result=engine.run_campaign(run,a.jar,target,uuid.uuid4().hex,backend,seed=1,recovery=recovery)
 except Exception as e:
  result={'version':'v029','status':'NOT_ACCEPTED','error':str(e)};engine.pack_review(run,result,[])
 print('Status:',result['status']);print('Review ZIP:',run/'review_v029.zip')
 if result.get('error'):print('Error:',result['error'])
 return 0 if result['status'] in ('V029_RESUME_INPUT_VERIFIED','CATALOG_QUEUE_V029_COMPLETED') else 1
if __name__=='__main__':raise SystemExit(main())
