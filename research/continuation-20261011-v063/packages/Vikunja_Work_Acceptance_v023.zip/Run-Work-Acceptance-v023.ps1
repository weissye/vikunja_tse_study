param(
 [string]$StudyRoot='C:\work\temp\work-v011-20261011-062659\v',
 [string]$ProvengoJar='C:\work\temp\vikunja_tse_study\Provengo-2026-01-10.uber.jar'
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_WORK_BIND_ACCEPTANCE v023'
& python (Join-Path $PSScriptRoot 'run_work_v023.py') --study-root $StudyRoot --jar $ProvengoJar
if ($LASTEXITCODE -ne 0) { throw 'Acceptance incomplete. Preserve the printed review ZIP and private snapshots.' }
