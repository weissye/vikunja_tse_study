"""Exercise storage adapter scripts on temporary directories, without Docker."""
import pathlib,tempfile,subprocess,sqlite3,shlex,json,os,re
from run_checkpoint_v010 import DockerVolumeBackend

with tempfile.TemporaryDirectory(prefix='checkpoint-adapter-') as temp:
 root=pathlib.Path(temp);db=root/'db';files=root/'files';db.mkdir();files.mkdir()
 con=sqlite3.connect(db/'vikunja.db');con.execute('create table labels(id integer,title text)');con.execute("insert into labels values(1,'before')");con.commit();con.close()
 (files/'kept.txt').write_text('before');(files/'kept.txt').chmod(0o640)
 os.utime(db,(1700000000,1700000000));os.utime(files,(1700000100,1700000100))
 calls=[];root_metadata_repaired=[]
 adapter=object.__new__(DockerVolumeBackend);adapter.run=root/'run';adapter.container='fixture'
 adapter.command=lambda args:calls.append(args) or ''
 adapter.ready=lambda:None
 def helper(directory,script):
  script=re.sub(r'/app/vikunja/files(?=[ ;]|$)',shlex.quote(str(files)),script)
  script=re.sub(r'/db(?=[ ;]|$)',shlex.quote(str(db)),script).replace('/snapshot/',shlex.quote(str(directory))+'/')
  subprocess.run(['/bin/sh','-c',script],check=True,capture_output=True)
  if ' -xpf ' in script:
   # Reproduce helper tar root-directory timestamp behavior observed in Windows Docker.
   os.utime(db,(1800000000,1800000000));os.utime(files,(1800000100,1800000100))
  if 'touch -t' in script:root_metadata_repaired.append(True)
 adapter.helper_command=helper
 snapshot=adapter.save('checkpoint')
 con=sqlite3.connect(db/'vikunja.db');con.execute("update labels set title=''");con.commit();con.close()
 (files/'kept.txt').write_text('after');(files/'added.txt').write_text('after')
 adapter.restore(snapshot)
 con=sqlite3.connect(db/'vikunja.db');assert con.execute('select title from labels').fetchone()[0]=='before';con.close()
 assert (files/'kept.txt').read_text()=='before' and not (files/'added.txt').exists()
 assert (files/'kept.txt').stat().st_mode & 0o777==0o640
 assert int(db.stat().st_mtime)==1700000000 and int(files.stat().st_mtime)==1700000100
 assert root_metadata_repaired
 assert json.loads((adapter.run/'restore-verification-v010.json').read_text())['strict_equality']
 original_helper=adapter.helper_command
 def corrupt_restored_tree(directory,script):
  if directory.name.startswith('restored-check-v010-'):(files/'kept.txt').write_text('unexpected-content')
  return original_helper(directory,script)
 adapter.helper_command=corrupt_restored_tree
 before=len(calls)
 try:adapter.restore(snapshot);raise AssertionError('Restored content mismatch accepted')
 except RuntimeError as error:assert 'remains stopped' in str(error)
 assert not any(c[0]=='start' for c in calls[before:])
 assert not json.loads((adapter.run/'restore-verification-v010.json').read_text())['strict_equality']
 adapter.helper_command=original_helper
 before=len(calls);archive=pathlib.Path(snapshot['folder'])/'db.tar';archive.write_bytes(archive.read_bytes()+b'tamper')
 try:adapter.restore(snapshot);raise AssertionError('Corrupt snapshot accepted')
 except ValueError as error:assert 'integrity' in str(error)
 assert len(calls)==before
 print(json.dumps({'status':'STORAGE_ADAPTER_PROTOCOL_PASS','sqlite_rollback':True,'file_rollback':True,'new_file_removed':True,'mode_preserved':True,'root_directory_mtimes_restored':True,'observed_tar_behavior_simulated':True,'strict_archive_tree_equality':True,'content_mismatch_blocks_start':True,'corrupt_snapshot_blocks_before_stop':True,'docker_execution':False,'windows_execution':False}))
