"""Native original-generator integration; fully controlled owned-resource fixture."""
import argparse,copy,json,threading,hashlib
from pathlib import Path
from http.server import BaseHTTPRequestHandler,HTTPServer
from run_checkpoint_v010 import run_campaign,digest,write

p=argparse.ArgumentParser();p.add_argument('--jar',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--restore-drift',action='store_true');p.add_argument('--seed',type=int,default=1);a=p.parse_args()
state={'resources':{},'next_id':1};http=[]
class H(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def call(self):
  parts=self.path.strip('/').split('/');kind=parts[-1] if len(parts)==3 else parts[-2]
  body=json.loads(self.rfile.read(int(self.headers.get('Content-Length',0)))) if self.command!='GET' else None
  code=200
  if self.command=='PUT' and len(parts)==3:
   key=str(state['next_id']);state['next_id']+=1;state['resources'][key]={'kind':kind,'body':{'id':int(key),**body}};code=201
  else:
   key=parts[-1]
   if self.command!='GET':
    if 'title' in body and type(body['title']) is not str:code=400
    else:state['resources'][key]['body'].update(body)
  value=state['resources'][key]['body'] if code<400 else {'message':'invalid title type'}
  http.append({'method':self.command,'path':self.path,'status':code,'request':body})
  self.send_response(code);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps(value).encode())
 do_GET=call;do_POST=call;do_PUT=call
class Backend:
 fixture_only=True
 def save(self,label):return {'state':copy.deepcopy(state),'hashes':{'fixture':digest(state)}}
 def restore(self,snapshot):
  state.clear();state.update(copy.deepcopy(snapshot['state']))
  if a.restore_drift:state['resources'][next(iter(state['resources']))]['body']['title']='drift'
server=HTTPServer(('127.0.0.1',0),H);threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 result=run_campaign(a.output.resolve(),a.jar,'http://127.0.0.1:'+str(server.server_port)+'/api/v1','fixture-context-token',Backend(),seed=a.seed)
 if a.restore_drift:
  assert result['status']=='NOT_ACCEPTED'
  assert not any(r['request'] and type(r['request'].get('title')) is int for r in http)
 else:
  assert result['status']=='CHECKPOINT_V010_ACCEPTANCE_COMPLETED_WITH_FINDING',result
  assert sum(r['method']=='PUT' and len(r['path'].strip('/').split('/'))==3 for r in http)==6
  for phase in ('bootstrap','resume'):
   files=list((a.output/phase/'spec/js').glob('*.js'));assert len(files)==3
  assert json.loads((a.output/'bootstrap-checks.json').read_text())[0]['pass'] is False
  assert json.loads((a.output/'resume-checks.json').read_text())[0]['pass'] is True
 write(a.output/'integration-validation.json',{'status':'INTEGRATED_NATIVE_TEST_PASS','restore_drift':a.restore_drift,'original_generator_used':True,'fixture_only':True,'native_jar_sha256':hashlib.sha256(a.jar.read_bytes()).hexdigest(),'campaign_result':result})
 print(json.dumps(result))
finally:server.shutdown()
