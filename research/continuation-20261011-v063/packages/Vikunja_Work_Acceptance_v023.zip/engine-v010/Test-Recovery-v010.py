"""Native recovery-only acceptance using the original generator and an owned fixture."""
import argparse,copy,json,threading,hashlib,zipfile
from pathlib import Path
from http.server import BaseHTTPRequestHandler,HTTPServer
from run_checkpoint_v010 import run_campaign,digest,write,load_recovery
p=argparse.ArgumentParser();p.add_argument('--jar',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--drift',action='store_true');a=p.parse_args()
state={'resources':{},'next_id':1};http=[]
class H(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def call(self):
  parts=self.path.strip('/').split('/');kind=parts[-1] if len(parts)==3 else parts[-2]
  body=json.loads(self.rfile.read(int(self.headers.get('Content-Length',0)))) if self.command!='GET' else None;code=200
  if self.command=='PUT' and len(parts)==3:
   key=str(state['next_id']);state['next_id']+=1;state['resources'][key]={'kind':kind,'body':{'id':int(key),**body}};code=201
  else:
   key=parts[-1]
   if self.command!='GET':
    if 'title' in body and type(body['title']) is not str:code=400
    else:state['resources'][key]['body'].update(body)
  value=state['resources'][key]['body'] if code<400 else {'message':'invalid title type'}
  http.append({'method':self.command,'path':self.path,'status':code,'request':body})
  self.send_response(code);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps(value).encode())
 do_GET=call;do_POST=call;do_PUT=call
class Backend:
 fixture_only=True
 def save(self,label):
  if label=='checkpoint':self.saved=copy.deepcopy(state)
  folder=self.run/'.private-snapshots'/label;folder.mkdir(parents=True)
  for name in ('db.tar','files.tar'):(folder/name).write_bytes(json.dumps(state).encode())
  return {'folder':str(folder),'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir()}}
 def restore(self,snapshot):
  if self.fail:raise RuntimeError('Restored persistent volume tree differs from checkpoint; server remains stopped')
  state.clear();state.update(copy.deepcopy(self.saved))
  if a.drift:state['resources'][next(iter(state['resources']))]['body']['title']='drift'
server=HTTPServer(('127.0.0.1',0),H);threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 root=a.output.resolve();parent=root/'synthetic-parent-v008';backend=Backend();backend.run=parent;backend.fail=True
 target='http://127.0.0.1:'+str(server.server_port)+'/api/v1'
 first=run_campaign(parent,a.jar,target,'fixture-token',backend)
 assert first['status']=='NOT_ACCEPTED' and first['target_resource_id']
 # Construct the v008 file naming/manifest protocol; this is explicitly synthetic.
 for name in ('manifest','result'):(parent/(name+'_v010.json')).rename(parent/(name+'_v008.json'))
 (parent/'review_v010.zip').unlink()
 files=[p for p in parent.rglob('*') if p.is_file() and not any(part in ('.private-snapshots','products','__pycache__') for part in p.parts) and p.name!='manifest_v008.json']
 write(parent/'manifest_v008.json',{str(p.relative_to(parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
 with zipfile.ZipFile(parent/'review_v008.zip','w',zipfile.ZIP_DEFLATED) as z:
  for path in files+[parent/'manifest_v008.json']:z.write(path,str(path.relative_to(parent)))
 resume=root/'recovery-v010';resume.mkdir();recovery=load_recovery(parent,resume);backend.fail=False
 boundary=len(http);result=run_campaign(resume,a.jar,target,'fixture-token',backend,recovery=recovery)
 after=http[boundary:]
 assert not any(r['method']=='PUT' and len(r['path'].strip('/').split('/'))==3 for r in after)
 if a.drift:
  assert result['status']=='NOT_ACCEPTED' and not any(r['method']!='GET' for r in after),result
 else:
  assert result['status']=='CHECKPOINT_V010_ACCEPTANCE_COMPLETED_WITH_FINDING',result
  checks=json.loads((resume/'resume-checks.json').read_text());assert checks[0]['resource_id']==first['target_resource_id'] and checks[0]['pass']
  assert sum(r['method']!='GET' for r in after)==1
  assert not (resume/'bootstrap').exists()
 write(root/'recovery-validation-v010.json',{'status':'NATIVE_RECOVERY_PROTOCOL_PASS','fixture_only':True,'drift_control':a.drift,'new_create_requests':0,'new_mutation_requests':sum(r['method']!='GET' for r in after),'target_identity_preserved':not a.drift,'result':result})
 print(json.dumps(result))
finally:server.shutdown()
