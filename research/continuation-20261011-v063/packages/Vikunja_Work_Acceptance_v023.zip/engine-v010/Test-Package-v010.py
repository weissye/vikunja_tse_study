"""Verify the numbered source delivery before any live operation."""
import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_v010.json').read_text())
for name,h in manifest.items():
 p=root/name
 if p.resolve().is_relative_to(root.resolve()) is False:raise ValueError('Manifest path escapes package')
 if hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise ValueError('Package hash mismatch: '+name)
print('V010_PACKAGE_INTEGRITY_PASS '+str(len(manifest)))
