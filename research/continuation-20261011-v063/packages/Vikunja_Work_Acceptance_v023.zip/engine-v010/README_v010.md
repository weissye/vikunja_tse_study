# Original Context generator checkpoint recovery v010

This release continues the diagnosed v008 run; it does not create replacement resources or replay its prefix. The original Mealie generator, Context, Stories, Interfaces, DAL, runtime variable bindings and independent verifiers remain in the package. Generator source is byte-identical to v008. No generated JavaScript was hand edited.

## Finding and repair

The uploaded live v008 review independently recorded an empty label title accepted with HTTP 200 and persisted on label 143, contrary to the contract's minLength 1. The checkpoint was saved first. Restoration then stopped because its strict tar-tree comparison failed.

The user's read-only diagnostic found exactly one difference: db.tar entry `.` retained the current directory mtime after extraction. Content hashes, types, owners, permissions and all other captured entries matched. files.tar had zero differences.

The adapter now restores archived directory uid, gid, mode and mtime explicitly, deepest directories first, after tar extraction. It then archives the actual volumes while Vikunja remains stopped and compares every captured entry again. No comparison field was removed. A mismatch produces restore-verification-v010.json and leaves the server stopped. The exact helper Docker image from v008 is reused without pulling.

## Live recovery flow

Run Run-Context-Checkpoint-v010.ps1 with ResumeFrom pointing to the original local v008 run directory, not the uploaded review ZIP. Its private snapshots must still be present.

1. Verify all parent manifest entries, the hash-chained journal, the historical finding, saved Context and read observations, and private archive SHA-256 values.
2. Confirm the recorded home Docker volume names, images, local binding and exclusive SQLite/files configuration. Require the currently stopped container and the pinned user Provengo JAR.
3. Prompt for the password without recording it. Restore the same snapshot, including directory metadata, and retain strict storage equality.
4. Start Vikunja and obtain a fresh server token. Verify the pinned live contract and the complete saved API observations before any next-rule mutation.
5. Generate only the resume project through the original generator CLI. Restore runtime bindings and Context, then independently read all six resources.
6. Execute only ModelsLabel/title/TYPE_NUMBER on the same physical label. Require rejection, unchanged state, independent completed verifier, native success, no resource creation and exact Context/API equality.

The native proxy token is separate from the refreshed server login token. Neither is included in the review. Evidence links to the verified parent journal and includes the parent review files unchanged under historical-v008/.

## Expected result

CHECKPOINT_V010_ACCEPTANCE_COMPLETED_WITH_FINDING means this two-rule acceptance sequence completed: one historical confirmed finding plus one new completed negative rule. It does not mean the server finding was fixed. Look for recovery_from_v008=true, prefix_replayed=false, current_completed_rules=1, historical_completed_rules=1, resume_create_requests=0 and target_resource_id=143.

The PowerShell launcher copies only review_v010.zip into Downloads and prints its location on success or failure. Upload that review. Never upload .private-snapshots or zip the entire run folder: SQLite snapshots contain user information and password hashes.

## Scope and limits

This is recovery at an explicit quiescent semantic boundary for six independent own-created resources and two schema rules. It does not restore arbitrary bthread stacks, scheduler/RNG position, process memory, background queues, clocks or external services. Storage equality covers tar entry type, mode, uid, gid, mtime, link target and regular-file content SHA-256; ACLs and extended attributes are not captured. Keep other clients and jobs from changing this isolated study instance during rollback and verification. The two exclusive named volumes are rolled back in full.

The live Windows/Docker continuation is pending the user's run. Local validation uses real Provengo against an owned synthetic HTTP fixture and a local filesystem adapter test; it is not live Vikunja validation. The displayed runtime version is the same but the assistant's test JAR SHA differs from the pinned user's JAR; both hashes are documented in validation.

## Files

- run_checkpoint_v010.py: strict storage restoration, parent evidence validation and recovery supervisor.
- source/generator_v56/: original generator lineage with its existing Context checkpoint feature.
- generated-example/resume/: actual generated stories.vikunja.js, interfaces.vikunja.js and dal.js.
- Test-Snapshot-Adapter-v010.py: reproduces the observed directory-mtime behavior; checks exact repair and mismatch/tamper blocking.
- Test-Recovery-v010.py: native recovery-only fixture test and drift control.
- Test-Integrated-v010.py: native two-phase fixture acceptance.
- validation/: sanitized local test outputs, excluding private snapshots.
- evidence-input/: immutable uploaded v008 review and directory diagnostic ZIPs.
- MANIFEST_v010.json, ORIGIN_v010.json and CHANGES_from_v008.patch: integrity and provenance.

## v010 narrow correction

The actual uploaded v009 review verified 20/20 manifest entries and recorded zero HTTP requests. Its preflight compared Docker mount destination arrays by order, causing an incorrect rejection: both arrays contained exactly /db and /app/vikunja/files in opposite orders. Container and both image identities were identical. v010 compares sorted destination arrays, preserving multiplicity, while retaining all image, volume-name, isolation, checkpoint, metadata and API checks. The original generator source remains byte-identical to v009. Continue from the same stopped v008 run, not from v009.
