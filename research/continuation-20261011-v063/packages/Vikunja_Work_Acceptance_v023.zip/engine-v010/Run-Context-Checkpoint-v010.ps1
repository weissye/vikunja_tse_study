param(
    [string]$StudyRoot = 'D:\Yeshayahu\Temp\vikunja_tse_study',
    [string]$ProvengoJar = (Join-Path $StudyRoot 'Provengo-2026-01-10.uber.jar'),
    [string]$Username = 'SBT-tester',
    [Parameter(Mandatory = $true)][string]$ResumeFrom
)
$ErrorActionPreference = 'Stop'
Write-Host 'VIKUNJA_ORIGINAL_CONTEXT_CHECKPOINT v010'
Get-Command python -ErrorAction Stop | Out-Null
Get-Command java -ErrorAction Stop | Out-Null
Get-Command docker -ErrorAction Stop | Out-Null
if (-not (Test-Path -LiteralPath $ProvengoJar -PathType Leaf)) { throw 'Provengo JAR missing.' }
& python (Join-Path $PSScriptRoot 'Test-Package-v010.py')
if ($LASTEXITCODE -ne 0) { throw 'Package integrity verification failed.' }
& python (Join-Path $PSScriptRoot 'run_checkpoint_v010.py') `
    --study-root $StudyRoot --jar $ProvengoJar --username $Username --resume-from $ResumeFrom
$runExit = $LASTEXITCODE
$review = Get-ChildItem (Join-Path $StudyRoot 'runs\checkpoint-v010-*\review_v010.zip') |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($review) {
    $downloadReview = Join-Path "$env:USERPROFILE\Downloads" `
        ('Vikunja_Checkpoint_Review_v010-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.zip')
    Copy-Item -LiteralPath $review.FullName -Destination $downloadReview
    Write-Host "Upload this review ZIP: $downloadReview"
}
if ($runExit -ne 0) { throw 'Checkpoint acceptance not completed. Preserve the printed review ZIP and local snapshots.' }

