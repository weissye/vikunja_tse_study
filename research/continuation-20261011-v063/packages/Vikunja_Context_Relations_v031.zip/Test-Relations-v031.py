import sys,tempfile,copy,json,re
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));import relation_engine_v031 as e
from generate_v031 import catalog

def test():
 with tempfile.TemporaryDirectory() as directory:
  run=Path(directory);resources=[];bindings={};state={'objects':{},'links':{'31':[],'32':[]}};restores=[]
  for typ,ids in [('ModelsProject',[1,2]),('ModelsTask',[31,32]),('ModelsLabel',[10,11])]:
   for i,id in enumerate(ids,1):
    logical=typ+'_'+str(i);expected={'title':'baseline'}
    if typ=='ModelsTask':expected['project_id']=1
    path='/'+{'ModelsProject':'projects','ModelsTask':'tasks','ModelsLabel':'labels'}[typ]+'/{id}'
    resources.append({'logicalId':logical,'resourceType':typ,'expected':expected,'revision':2,'verifiedRevision':2,'detail_template':path,'route_parameter':'id'})
    bindings['ROUTE_'+logical]=id;bindings['ID_'+logical]=id;bindings['SNAPSHOT_'+logical]='{}';state['objects'][path.replace('{id}',str(id))]=dict(id=id,**expected)
  capsule={'resources':sorted(resources,key=lambda r:r['logicalId']),'bindings':bindings,'relations':[]}
  class Backend:
   fixture_only=True;token='fixture'
   def ensure_authenticated(self):return 'fixture'
   def save(self,label):return {'folder':label,'hashes':{},'data':copy.deepcopy(state)}
   def restore(self,snapshot):state.clear();state.update(copy.deepcopy(snapshot['data']));restores.append(snapshot['folder'])
  original_request=e.request;original_run=e.subprocess.run
  def request(url,method='GET',body=None,token=None):
   if not url.startswith('http://fixture'):return original_request(url,method,body,token)
   path=url[len('http://fixture'):];match=re.fullmatch(r'/tasks/(\d+)/labels(?:/(\d+))?',path)
   if match:
    task,label=match.groups()
    if method=='PUT':state['links'][task]=[body['label_id']];return 201,b'{}'
    if method=='DELETE':
     state['links'][task]=[]
     # First label fixture simulates a cross-resource semantic bug.
     if label=='10':state['links']['32' if task=='31' else '31']=[]
     return 200,b'{}'
    return 200,json.dumps([state['objects']['/labels/'+str(id)] for id in state['links'][task]]).encode()
   return 200,json.dumps(state['objects'][path]).encode()
  calls=[0]
  def native(cmd,**kw):
   if cmd[0]!='java':return original_run(cmd,**kw)
   index=calls[0];calls[0]+=1;project=Path(cmd[-1]);plan=json.loads((project.parent/'checkpoint-plan-v031.json').read_text());proxy=json.loads((project/'spec/js/generation_report.json').read_text())['checkpoint_acceptance']['proxy'] if False else None
   text=(project/'spec/js/interfaces.vikunja.js').read_text();proxy=re.search(r'new RESTSession\("([^"]+)"',text).group(1)
   if index==0:e.json_request(proxy+'/__checkpoint/save',method='POST',body=capsule,token='credential')
   else:e.json_request(proxy+'/__checkpoint/resume',token='credential');e.json_request(proxy+'/__checkpoint/verify',token='credential')
   label=10+index;checks=[];stopped=False
   for task,other,present,other_present in [('31','32',True,False),('32','31',True,True),('31','32',False,True),('32','31',False,False)]:
    status,_=e.request(proxy+'/tasks/'+task+'/labels'+('' if present else '/'+str(label)),method='PUT' if present else 'DELETE',body={'label_id':label} if present else None,token='credential');checks.append({'name':'write','pass':True,'status':status})
    for path,wanted,kind in [('/tasks/'+task+'/labels',[label] if present else [],'membership'),('/tasks/'+task,None,'projection'),('/tasks/'+other+'/labels',[label] if other_present else [],'membership'),('/labels/'+str(label),None,'projection')]:
     status,body=e.request(proxy+path,token='credential');actual=json.loads(body);passed=True if kind=='projection' else [x['id'] for x in actual]==wanted
     checks.append({'name':path,'pass':passed,'status':status})
     if not passed:stopped=True;break
    if stopped:break
   log='RELATION_CONTEXT '+json.dumps(capsule['resources'])+'\n'+'\n'.join('RELATION_CHECK '+json.dumps(c) for c in checks)
   if not stopped:log+='\nRELATION_CASE_COMPLETED '+plan['case_id']+'\nTest Result: SUCCESS'
   return SimpleNamespace(returncode=1 if stopped else 0,stdout=log,stderr='')
  e.request=request;e.subprocess.run=native
  try:result=e.run_relations(run,run/'fixture.jar','http://fixture','credential',Backend())
  finally:e.request=original_request;e.subprocess.run=original_run
  assert result['status']=='V031_RELATION_ACCEPTANCE_COMPLETED',result
  outcomes=json.loads((run/'outcomes_v031.json').read_text());assert [o['classification'] for o in outcomes]==['SEMANTIC_CANDIDATE','PASS'];assert len(restores)==2;assert not any(state['links'].values())
  assert result['completed_cases']==2
  print('V031_SUPERVISOR_FIXTURE_PASS: shared relation failure retained, checkpoint/relations restored, second case continued')
if __name__=='__main__':test()
