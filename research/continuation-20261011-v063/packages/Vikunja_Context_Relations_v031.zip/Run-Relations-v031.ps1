param(
 [switch]$RunLive,
 [string]$StudyRoot='C:\work\temp\work-v011-20261011-062659\v',
 [string]$ProvengoJar='C:\work\temp\vikunja_tse_study\Provengo-2026-01-10.uber.jar'
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_CONTEXT_RELATION_ACCEPTANCE v031'
& python (Join-Path $PSScriptRoot 'Verify-v031.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
$arguments=@((Join-Path $PSScriptRoot 'run_relations_v031.py'),'--study-root',$StudyRoot,'--jar',$ProvengoJar)
if ($RunLive) {$arguments+='--live'}
& python @arguments
if ($LASTEXITCODE -ne 0) {throw 'Acceptance incomplete. Preserve the printed review ZIP and private snapshots.'}
