"""Bounded authentication maintenance; never retries a resource mutation."""
import json,time,urllib.request,urllib.error
from datetime import datetime,timezone
from email.utils import parsedate_to_datetime

class Auth:
 def __init__(self,target,username,password,run,clock=time.monotonic,sleep=time.sleep):
  self.target=target;self.username=username;self.password=password;self.run=run;self.token=None;self.clock=clock;self.sleep=sleep;self.last_login=None
 def event(self,status,**values):
  with (self.run/'authentication-v029.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(status=status,**values))+'\n')
 def call(self,path,body=None,token=None):
  headers={'Content-Type':'application/json'}
  if token:headers['Authorization']='Bearer '+token
  req=urllib.request.Request(self.target+path,data=json.dumps(body).encode() if body is not None else None,headers=headers,method='POST' if body is not None else 'GET')
  try:
   with urllib.request.urlopen(req,timeout=30) as r:return r.status,r.read(),dict(r.headers)
  except urllib.error.HTTPError as r:return r.code,r.read(),dict(r.headers)
 def login(self):
  total=0
  for attempt in range(5):
   if self.last_login is not None:
    delay=max(0,65-(self.clock()-self.last_login))
    if delay:self.event('LOGIN_PACING',seconds=delay);self.pause(delay)
   self.last_login=self.clock()
   status,body,headers=self.call('/login',{'username':self.username,'password':self.password})
   self.event('LOGIN_RESULT',http_status=status,attempt=attempt+1)
   if 200<=status<300:
    self.token=json.loads(body).get('token')
    if not self.token:raise ValueError('Login did not return token')
    return self.token
   if status!=429:raise RuntimeError('Login failed: HTTP '+str(status))
   retry=next((v for k,v in headers.items() if k.lower()=='retry-after'),None)
   try:delay=max(1,float(retry)) if retry else 65*(attempt+1)
   except ValueError:delay=max(1,(parsedate_to_datetime(retry)-datetime.now(timezone.utc)).total_seconds())
   if total+delay>900:raise RuntimeError('Login rate-limit wait exceeds bounded budget; queue preserved')
   total+=delay;self.event('RATE_LIMIT_WAIT',seconds=delay);self.pause(delay)
  raise RuntimeError('Login remains rate limited; queue preserved')
 def pause(self,seconds):
  print('Authentication wait: '+str(round(seconds))+' seconds; queue unchanged',flush=True)
  while seconds>0:
   chunk=min(seconds,30);self.sleep(chunk);seconds-=chunk
 def ensure(self):
  if not self.token:self.login()
  status,_,_=self.call('/user',token=self.token)
  self.event('TOKEN_CHECK',http_status=status)
  if status==401:
   self.login();status,_,_=self.call('/user',token=self.token)
   self.event('TOKEN_RECHECK',http_status=status)
  if status!=200:raise RuntimeError('Authentication validation failed: HTTP '+str(status))
  return self.token
