"""Bounded complete pagination; no absence claim from incomplete collection."""
def collect(project,fetch,max_pages=100):
 status,views=fetch('/projects/'+project+'/views')
 if status!=200 or not isinstance(views,list):return {'complete':False,'reason':'VIEW_DISCOVERY_UNAVAILABLE'}
 candidates=[]
 for view in views:
  f=view.get('filter')
  if view.get('view_kind')!='list' or not isinstance(view.get('id'),int) or view.get('project_id')!=int(project):continue
  if f and (not isinstance(f,dict) or f.get('filter') or f.get('s') or any(v for k,v in f.items() if k not in ('sort_by','order_by','page','per_page','filter_timezone','filter_include_nulls','filter','s'))):continue
  candidates.append(view)
 if not candidates:return {'complete':False,'reason':'NO_UNFILTERED_LIST_VIEW'}
 view=min(candidates,key=lambda v:v['id']);ids=[];seen=set()
 for page in range(1,max_pages+1):
  path='/projects/'+project+'/views/'+str(view['id'])+'/tasks?page='+str(page)+'&per_page=50&sort_by=id&order_by=asc'
  status,items=fetch(path)
  if status!=200 or not isinstance(items,list):return {'complete':False,'reason':'PAGE_UNAVAILABLE','page':page}
  if not items:return {'complete':True,'ids':ids,'view_id':view['id'],'pages':page,'scope':'All visible tasks in selected unfiltered list view'}
  for item in items:
   if not isinstance(item,dict) or not isinstance(item.get('id'),int) or item.get('project_id')!=int(project) or item['id'] in seen:return {'complete':False,'reason':'INVALID_OR_DUPLICATE_PAGE','page':page}
   seen.add(item['id']);ids.append(item['id'])
 return {'complete':False,'reason':'PAGE_CAP'}
