const fs=require('fs'),vm=require('vm'),catalog=JSON.parse(fs.readFileSync(process.argv[2]));
function test(index,bug){
 const dir=process.argv[3]+'/case-'+(index+1),plan=JSON.parse(fs.readFileSync(dir+'/checkpoint-plan-v052.json')),values={},models={},actual={},logs=[],events={};
 for(let i=0;i<plan.resources.length;i++){const r=plan.resources[i];values['ID_'+r.logicalId]=values['ROUTE_'+r.logicalId]=JSON.parse(fs.readFileSync(process.argv[4])).bindings['ID_'+r.logicalId];models[r.logicalId]={id:r.logicalId,resourceType:r.resourceType,expected:JSON.parse(JSON.stringify(r.expected)),revision:2,verifiedRevision:2};}
 const resolve=o=>{if(typeof o==='string'&&/^@\{[^}]+\}$/.test(o))return values[o.slice(2,-1)];if(Array.isArray(o))return o.map(resolve);if(o&&typeof o==='object')return Object.fromEntries(Object.entries(o).map(([k,v])=>[k,resolve(v)]));return o;};
 for(const id in models)actual[id]=resolve(models[id].expected);
 const original=JSON.parse(JSON.stringify(actual));
 const c={RESTSession:function(){},RELATION_ACTOR:'A',bp:{EventSet:function(){},log:{info:x=>logs.push(x)}},pvg:{rtv:{get:k=>values[k],set:(k,v)=>values[k]=v},fail:m=>{throw Error(m);}},ctx:{registerEffect:(n,f)=>events[n]=f,registerQuery:()=>{},runQuery:()=>Object.values(models),Entity:(id,type,data)=>{if('id'in data||'type'in data)throw Error('Reserved fields');return {id,type,...data};},removeEntity:id=>delete models[id],insertEntity:e=>models[e.id]=e}};
 vm.createContext(c);vm.runInContext(fs.readFileSync(dir+'/project/spec/js/interfaces.vikunja.js','utf8'),c);vm.runInContext(fs.readFileSync(dir+'/project/spec/js/dal.js','utf8'),c);c.getModelEntity=id=>models[id];
 c.requestRest=(method,path,body,codes,meta,callback)=>{
  let status=200,response={};const logical=Object.keys(actual).find(id=>c.sharedRoute(id)===path);
  if(path.startsWith('/__checkpoint/project-tasks')){const project=Number(resolve(path.split('project=')[1]));const state=bug==='stale-membership'?original:actual;response={complete:true,ids:Object.keys(state).filter(id=>id.startsWith('ModelsTask')&&state[id].project_id===project).map(id=>values['ID_'+id])};}
  else if(logical){response=actual[logical];if(method==='POST'){if((typeof body.title!=='string'||(body.project_id!==undefined&&typeof resolve(body.project_id)!=='number'))&&bug!=='accepted-invalid'){status=400;response={};}else{Object.assign(actual[logical],resolve(body));if(bug==='lost-field'&&body.description==='sbt-v052-moved-description')actual[logical].title=original[logical].title;response=actual[logical];}}else if(bug==='stale-peer'&&c.RELATION_ACTOR==='B')response=original[logical];}
  callback({code:status,body:JSON.stringify(response)});
 };
 let failed=false;
 try{for(let i=0;i<plan.steps.length;i++){const step={...plan.steps[i],id:'step-'+i,check_id:'step-'+i};c.sharedMutation(step,step.id);events.SharedWriteCompleted(step);c.sharedObserve(step.id,false);events.SharedVerified({id:step.id});}c.sharedObserve('final',true);c.sharedNegatives();}catch(e){failed=true;if(!bug)throw e;}
 if(bug&&!failed)throw Error('Missed '+bug);
 if(!bug){const checks=logs.filter(x=>/^(RELATION_CHECK|NEGATIVE_CHECK) /.test(x)).map(x=>JSON.parse(x.slice(x.indexOf(' ')+1)));if(checks.length!==90||checks.some(x=>x.pass!==true))throw Error('Check count/verdict');if(!logs.some(x=>x.startsWith('RELATION_FINAL ')))throw Error('Missing final observation');}
}
for(let i=0;i<catalog.items.length;i++)for(const bug of [null,'lost-field','stale-peer','accepted-invalid','stale-membership'])test(i,bug);
console.log('V052_SHARED_GENERATOR_FIXTURE_PASS: 360 checks; lost field, stale peer and invalid acceptance detected; real DAL effects verified. Not native/live.');
