const fs=require('fs'),vm=require('vm');
const catalog=JSON.parse(fs.readFileSync(process.argv[2]));
function test(item,bug){
 const logs=[],values={};const models={},objects={},links={31:[ ],32:[ ]};
 for(const [type,ids] of [['ModelsTask',[31,32]],['ModelsLabel',[10,11]]])for(let i=0;i<2;i++){
  const logical=type+'_'+(i+1),id=ids[i];values['ID_'+logical]=values['ROUTE_'+logical]=id;
  const expected={title:'baseline',description:'old',...(type==='ModelsTask'?{project_id:1}:{})};models[logical]={expected};objects[(type==='ModelsTask'?'/tasks/':'/labels/')+id]={id,...expected};
 }
 const c={RESTSession:function(){},bp:{EventSet:function(){},log:{info:s=>logs.push(s)}},pvg:{rtv:{get:k=>values[k]},fail:m=>{throw Error(m);}},getModelEntity:id=>models[id]};
 vm.createContext(c);vm.runInContext(fs.readFileSync(process.argv[3],'utf8'),c);
 c.requestRest=function(method,path,body,codes,meta,callback){
  path=path.replace(/@\{([^}]+)\}/g,(_,k)=>values[k]);if(body!==undefined)body=JSON.parse(JSON.stringify(body).replace(/@\{([^}]+)\}/g,(_,k)=>values[k]));
  let status=200,actual;const match=path.match(/^\/tasks\/(\d+)\/labels$/);
  if(path==='/__checkpoint/visible-labels')actual={complete:bug!=='incomplete',ids:Object.keys(objects).filter(k=>k.startsWith('/labels/')).map(k=>k.split('/').pop())};
  else if(match){const task=match[1];if(method==='PUT'){links[task].push(Number(body.label_id));status=201;actual={};}else if(!objects['/tasks/'+task]&&bug==='links-404'){status=404;actual={};}else actual=links[task].map(id=>objects['/labels/'+id]);}
  else if(method==='DELETE'){
   const task=path.split('/').pop();if(bug!=='task-survives')delete objects[path];if(bug!=='links-survive')links[task]=[];
   if(bug==='collateral')links[task==='31'?'32':'31']=[];
   if(bug==='label-damage')objects['/labels/10'].title='wrong';actual={};
  }else{actual=objects[path];if(!actual){status=bug==='absence-403'?403:404;actual={};}}
  callback({code:status,body:JSON.stringify(actual)});
 };
 let failed=false;
 try{for(const step of item.steps){const pending={...step,id:item.case_id};c.relationMutation(pending);c.verifyRelation(pending);}}catch(e){failed=true;if(!bug)throw e;}
 const checks=logs.filter(s=>s.startsWith('RELATION_CHECK ')).map(s=>JSON.parse(s.slice(15)));
 if(['task-survives','links-survive','collateral','label-damage'].includes(bug)){if(!failed)throw Error('Missed '+bug);}
 else{if(failed||checks.length!==28)throw Error('Completion mismatch '+bug);if(['absence-403','incomplete'].includes(bug)&&!checks.some(x=>x.pass===null))throw Error('Uncertainty lost');}
}
for(const item of catalog.items)for(const bug of [null,'task-survives','links-survive','collateral','label-damage','links-404','absence-403','incomplete'])test(item,bug);
console.log('V038_GENERATED_INTERFACE_FIXTURE_PASS: both 28-check cases; task survival, stale links, collateral loss and label damage detected. Not native/live.');
