VIKUNJA CONTEXT RELATIONS v038
Original generator retained: Stories, Interfaces, DAL, Context and independent verifiers.
Two mirrored cases: attach both labels to both tasks, then delete task 1 or task 2.
28 checks each; 56 total. Reuse the six v031 resource IDs and cold checkpoint.
Contract-derived: task detail route, DELETE success 200, task GET 404, label collection
pagination parameters and exact array schema. Contract pointers recorded in relation_spec.
Research hypotheses (explicit method inputs): unrelated task and labels preserved;
other task retains both memberships; deleted task exposes no remaining memberships.
Deleted-task labels endpoint: GET 200 with [] supports absence of visible links;
404 supports inaccessible relation route (not documented by this collection operation).
403 is undetermined. A nonempty 200 array or server error fails this semantic oracle.
Direct missing task 404 confirms API absence; this is not physical database row inspection.
Both labels checked individually and through full user-visible collection pagination.
Per-page responses preserved, continue until explicit empty page; short pages never finish.
Malformed/repeated pages, non-200 page response, or cap => collection undetermined.
No claim of true concurrency or full-system coverage. Ordered steps, seed 1, two instances.
Every case restores/verifies original persistent checkpoint; no resource recreation or prefix replay.
Existing authentication, Windows bind adapter and evidence mechanisms unchanged.
Local fixture tests passed, but native/live v038 acceptance requires the user workstation.
Run top-level Run-Relations-v038.ps1 (static), then -RunLive. Upload review_v038.zip.
Historical engine-v010 launchers are provenance only. Never edit generated JS manually.
