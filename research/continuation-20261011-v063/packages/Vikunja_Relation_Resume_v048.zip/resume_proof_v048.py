import hashlib,json,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
SOURCE=Path(r'C:\work\temp\work-v011-20261011-062659\v\runs\relation-v039-20261011-120631-399248')
EXPECTED='3ea24dcb1ef0d5d50d2082ea46f68d9d47c2e50aff545f183a10fed4e9b74231'
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def verify_first(source=SOURCE):
 archive=ROOT/'V039_Recovery_v046.zip'
 if hashlib.sha256(archive.read_bytes()).hexdigest()!=EXPECTED:raise ValueError('Recovery archive differs')
 with zipfile.ZipFile(archive) as z:
  manifest=json.loads(z.read('RECOVERY_MANIFEST_v046.json'))
  for name,h in manifest.items():
   p=PurePosixPath(name)
   if p.is_absolute() or '..' in p.parts or ':' in name:raise ValueError('Unsafe recovery path')
   b=z.read(name)
   if hashlib.sha256(b).hexdigest()!=h:raise ValueError('Recovery hash differs')
   local=source.joinpath(*p.parts)
   if hashlib.sha256(local.read_bytes()).hexdigest()!=h:raise ValueError('Original surviving evidence changed: '+name)
  checks=json.loads(z.read('case-1/checks.json'))
  if len(checks)!=54 or any(c['pass'] is not True for c in checks):raise ValueError('First case checks incomplete')
  log=z.read('case-1/native.log').decode()
  if 'Test Result: SUCCESS' not in log or 'RELATION_CASE_COMPLETED relation-history-first-label' not in log:raise ValueError('First native run incomplete')
  journal=[json.loads(l) for l in z.read('campaign-journal.jsonl').decode().splitlines()]
  previous=None
  for i,e in enumerate(journal):
   if e['index']!=i or e['previous']!=previous or e['sha256']!=digest({k:v for k,v in e.items() if k!='sha256'}):raise ValueError('Historical journal invalid')
   previous=e['sha256']
  completed=[e for e in journal if e['status']=='CASE_PASSED']
  if len(completed)!=1 or completed[0]['data']['checks_sha256']!=digest(checks):raise ValueError('Historical check linkage differs')
  restored=[e for e in journal if e['status']=='BASELINE_RELATIONS_VERIFIED' and e['data'].get('case_id')=='relation-history-first-label']
  if len(restored)!=1 or restored[0]['index']<=completed[0]['index']:raise ValueError('Historical restoration missing')
  return dict(source_run=str(source),recovery_sha256=EXPECTED,completed_case_id='relation-history-first-label',verified_checks=54,native_success=True,baseline_restored=True,raw_http_available=False,first_case_repeated=False,remaining_case_id='relation-history-second-label')
