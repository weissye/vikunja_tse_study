VIKUNJA v048 - resume v039 second history case only
The first v039 case is not repeated. Its 54 passing markers, native SUCCESS, check digest,
journal chain and post-case baseline restoration are verified from immutable recovery ZIP
and compared byte-for-byte with all 32 surviving local evidence files.
Original v039 raw HTTP evidence was overwritten as [] during erroneous exception repack.
It is not reconstructed or claimed available. Its status audit was empty/incomplete.
Original renderer unchanged byte-for-byte. Second case mutation inputs unchanged.
Generator, Context, Stories, Interfaces, DAL and verifiers retained. Seed 1, same six IDs.
v048 first cold-saves current server state, restores original v031 checkpoint and verifies
API baseline, then runs ONLY relation-history-second-label (54 checks).
No recovery of unknown mid-case v039 Java runtime is claimed: second case restarts at its
known original baseline. Original first case is preserved and never replayed.
Only second case native HTTP is new; combined 108 semantic checks have different evidence completeness.
Disk space guard: 512 MB before restoration/case, 128 MB before each research request.
HTTP evidence additionally appended and fsynced per response. JSON metadata writes are atomic.
Launcher exception handling never repacks with an empty HTTP list and never overwrites old v039 files.
Private snapshots stay local. Unknown current state is saved before verified baseline restoration.
For live acceptance require workstation, v031 private checkpoint and original v039 surviving directory.
Static preflight validates both proof sources and generates only second case JS.
Delivery generated-resume/case-2 shows second case JS; new native supervisor folder may be case-1,
meaning first case in the remaining queue (logical case ID remains second-label).
No true concurrency/full-system coverage claim. Upload review_v048.zip after running.
