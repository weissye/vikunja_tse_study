"""Two-rule native acceptance campaign; original generator and quiescent checkpoints."""
import argparse, copy, getpass, hashlib, json, os, re, subprocess, threading, time, urllib.error, urllib.request, zipfile, tarfile, shlex, uuid, shutil
from datetime import datetime, timezone
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer

ROOT=Path(__file__).resolve().parent/'engine-v010'
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(path,value):
 temporary=path.with_name(path.name+'.pending-write')
 try:
  with temporary.open('w',encoding='utf-8') as f:
   json.dump(value,f,indent=2);f.flush();os.fsync(f.fileno())
  os.replace(temporary,path)
 finally:
  if temporary.exists():temporary.unlink()

def disk_guard(path,minimum_mb=512):
 if shutil.disk_usage(path).free < minimum_mb*1024*1024:
  raise RuntimeError('INSUFFICIENT_DISK_SPACE: requires '+str(minimum_mb)+' MB free; no next request dispatched')

def persist_http(run,item):
 with (run/'http-evidence-durable.jsonl').open('a',encoding='utf-8') as f:
  f.write(json.dumps(item)+'\n');f.flush();os.fsync(f.fileno())
def request(url,method='GET',body=None,token=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 r=urllib.request.Request(url,data=json.dumps(body).encode() if body is not None else None,headers=headers,method=method)
 try:
  with urllib.request.urlopen(r,timeout=30) as response:return response.status,response.read()
 except urllib.error.HTTPError as response:return response.code,response.read()
def json_request(url,**kwargs):
 status,body=request(url,**kwargs)
 if not 200<=status<300:raise RuntimeError('HTTP '+str(status)+' at '+url)
 return json.loads(body)
def native_markers(log,marker):return [json.loads(line.split(marker+' ',1)[1]) for line in log.splitlines() if marker+' ' in line]
def pack_review(run,result,records):
 write(run/'http-evidence.json',records);write(run/'result_v048.json',result)
 files=sorted(p for p in run.rglob('*') if p.is_file() and not any(part in ('.private-snapshots','products','__pycache__') for part in p.relative_to(run).parts) and p.name not in ('review_v048.zip','manifest_v048.json') and not p.name.endswith('.pending-write'))
 manifest={str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};write(run/'manifest_v048.json',manifest)
 with zipfile.ZipFile(run/'review_v048.zip','w',zipfile.ZIP_DEFLATED) as archive:
  for p in files+[run/'manifest_v048.json']:archive.write(p,str(p.relative_to(run)))

def collect_visible_labels(fetch, max_pages=1000):
 """Read every page until an explicit empty array; never infer completion from a short page."""
 ids=[];pages=[];seen=set()
 for page in range(1,max_pages+1):
  path='/labels?page='+str(page)+'&per_page=50'
  status,body=fetch(path)
  try:items=json.loads(body)
  except (ValueError,TypeError):return dict(complete=False,ids=ids,pages=pages,error='INVALID_JSON')
  pages.append(dict(page=page,status=status,item_count=len(items) if isinstance(items,list) else None))
  if status!=200 or not isinstance(items,list):return dict(complete=False,ids=ids,pages=pages,error='UNREADABLE_PAGE')
  if not items:return dict(complete=True,ids=ids,pages=pages,scope='USER_VISIBLE_COLLECTION_ONLY',termination='EMPTY_PAGE')
  current=[]
  for item in items:
   if not isinstance(item,dict) or type(item.get('id')) is not int or item['id']<=0:return dict(complete=False,ids=ids,pages=pages,error='INVALID_ID')
   key=str(item['id'])
   if key in seen:return dict(complete=False,ids=ids,pages=pages,error='DUPLICATE_ID_OR_REPEATED_PAGE')
   seen.add(key);current.append(key)
  ids.extend(current)
 return dict(complete=False,ids=ids,pages=pages,error='PAGE_LIMIT_REACHED')

def audit_statuses(records,raw):
 from urllib.parse import urlsplit
 audit=[]
 for record in records:
  path=urlsplit(record['path']).path.removeprefix('/api/v1');method=record['method'].lower()
  matches=[(template,ops) for template,ops in raw['paths'].items() if re.fullmatch(re.sub(r'\{[^}]+\}',r'[^/]+',template),path)]
  if len(matches)!=1:raise ValueError('Ambiguous or missing contract operation: '+path)
  template,ops=matches[0];adapter=None
  if method=='post' and template=='/labels/{id}' and method not in ops:
   method='put';adapter='EXPLICIT_OPTIONS_VERIFIED_LABEL_UPDATE_ADAPTER'
  op=ops.get(method)
  if op is None:raise ValueError('Missing contract method: '+method+' '+template)
  documented=str(record['status']) in op.get('responses',{}) or 'default' in op.get('responses',{})
  audit.append(dict(http_index=record['index'],method=record['method'],path=record['path'],status=record['status'],contract_pointer='#/paths/'+template.replace('~','~0').replace('/','~1')+'/'+method,documented=documented,adapter=adapter))
 return dict(checked_requests=len(audit),undocumented_status_count=sum(not x['documented'] for x in audit),observations=audit)

class DockerVolumeBackend:
 """Cold backup/rollback of exclusive SQLite/files volumes; snapshots stay private."""
 def __init__(self,container,helper_container,url,token,run):
  if not re.fullmatch(r'[A-Za-z0-9_.-]+',container):raise ValueError('Invalid container name')
  self.container=container;self.url=url;self.token=token;self.run=run
  self.helper=self.command(['inspect','--format','{{.Image}}',helper_container]).strip()
  c=json.loads(self.command(['inspect',container]))[0]
  env=dict(item.split('=',1) for item in c['Config'].get('Env',[]) if '=' in item)
  if env.get('VIKUNJA_DATABASE_TYPE','sqlite')!='sqlite':raise ValueError('Only SQLite checkpoint adapter is implemented')
  if not env.get('VIKUNJA_DATABASE_PATH','').startswith('/db/'):raise ValueError('Database path must be explicitly configured under /db')
  self.mounts=[m for m in c['Mounts'] if m['Destination'] in ('/db','/app/vikunja/files')]
  if len(self.mounts)!=2 or any(m['Type']!='volume' or not m.get('Name') or not m['RW'] for m in self.mounts):raise ValueError('Requires exactly two writable named volumes at /db and /app/vikunja/files')
  ids=self.command(['ps','-aq']).split()
  if ids:
   others=json.loads(self.command(['inspect',*ids]))
   names={m['Name'] for m in self.mounts}
   if any(o['Id']!=c['Id'] and any(m.get('Name') in names for m in o['Mounts']) for o in others):raise ValueError('Checkpoint volumes are shared with another container')
  ports=c['HostConfig'].get('PortBindings',{}).get('3456/tcp',[])
  if not any(p.get('HostIp')=='127.0.0.1' and p.get('HostPort')=='3456' for p in ports):raise ValueError('Expected isolated local Vikunja at port 3456')
  write(run/'snapshot-adapter.json',{'kind':'COLD_NAMED_VOLUME_SNAPSHOT','container':container,'image':c['Image'],'helper_image':self.helper,'destinations':[m['Destination'] for m in self.mounts],'scope':'SQLite and files persistent volumes only; process clocks, queues and external services excluded'})
 def command(self,args):
  try:return subprocess.run(['docker',*args],check=True,capture_output=True,text=True,timeout=120).stdout
  except subprocess.CalledProcessError as error:raise RuntimeError('Docker '+args[0]+' failed: '+error.stderr.strip()[:1500]) from error
 def helper_command(self,directory,script):
  self.command(['run','--rm','--pull=never','--network','none','--user','0:0','--volumes-from',self.container,'--mount','type=bind,src='+str(directory.resolve())+',dst=/snapshot','--entrypoint','/bin/sh',self.helper,'-c',script])
 def ready(self):
  for _ in range(30):
   try:
    if json_request(self.url+'/info').get('version')=='v2.6.0':
     if hasattr(self,'refresh_token'):self.token=self.refresh_token()
     return
   except Exception:pass
   time.sleep(1)
  raise RuntimeError('Vikunja did not recover after checkpoint operation')
 def save(self,label):
  folder=self.run/'.private-snapshots'/label;folder.mkdir(parents=True,exist_ok=False)
  self.command(['stop',self.container])
  try:self.helper_command(folder,'set -eu; tar -C /db -cpf /snapshot/db.tar .; tar -C /app/vikunja/files -cpf /snapshot/files.tar .')
  finally:self.command(['start',self.container])
  self.ready()
  return {'folder':str(folder),'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.tar')}}
 def restore(self,snapshot):
  folder=Path(snapshot['folder'])
  if set(snapshot['hashes'])!={'db.tar','files.tar'}:raise ValueError('Incomplete snapshot')
  for name,h in snapshot['hashes'].items():
   if hashlib.sha256((folder/name).read_bytes()).hexdigest()!=h:raise ValueError('Snapshot integrity mismatch')
  self.command(['stop',self.container])
  # Removal is confined to the two exclusive study volumes being rolled back.
  self.helper_command(folder,'set -eu; find /db -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +; tar -C /db -xpf /snapshot/db.tar; find /app/vikunja/files -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +; tar -C /app/vikunja/files -xpf /snapshot/files.tar')
  # tar implementations can leave the root directory mtime changed by extraction.
  # Restore every archived directory's metadata, children before parents.
  commands=['set -eu']
  for name,destination in (('db.tar','/db'),('files.tar','/app/vikunja/files')):
   with tarfile.open(folder/name) as archive:
    directories=sorted((e for e in archive if e.isdir()),key=lambda e:e.name.count('/'),reverse=True)
    for entry in directories:
     relative=Path(entry.name)
     if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe archive directory')
     if int(entry.mtime)!=entry.mtime:raise ValueError('Subsecond directory timestamps are unsupported')
     path=destination+'/'+relative.as_posix() if relative.as_posix()!='.' else destination
     timestamp=datetime.fromtimestamp(entry.mtime,timezone.utc).strftime('%Y%m%d%H%M.%S')
     quoted=shlex.quote(path)
     commands.extend(['chown '+str(entry.uid)+':'+str(entry.gid)+' '+quoted,
                      'chmod '+format(entry.mode,'o')+' '+quoted,
                      'TZ=UTC touch -t '+shlex.quote(timestamp)+' '+quoted])
  self.helper_command(folder,'; '.join(commands))
  # Keep strict equality, including directory mtime. Never start on mismatch.
  check=folder/('restored-check-v010-'+uuid.uuid4().hex);check.mkdir(exist_ok=False)
  self.helper_command(check,'set -eu; tar -C /db -cpf /snapshot/db.tar .; tar -C /app/vikunja/files -cpf /snapshot/files.tar .')
  differences=[]
  for name in snapshot['hashes']:
   before,after=archive_tree(folder/name),archive_tree(check/name)
   differences.extend({'archive':name,'entry':key,'before':before.get(key),'after':after.get(key)} for key in sorted(set(before)|set(after)) if before.get(key)!=after.get(key))
  write(self.run/'restore-verification-v010.json',{'strict_equality':not differences,'includes_directory_mtime':True,'differences':differences})
  if differences:raise RuntimeError('Restored persistent volume tree differs from checkpoint; server remains stopped')
  self.command(['start',self.container]);self.ready()

def archive_tree(path):
 entries={}
 with tarfile.open(path) as archive:
  for entry in archive:
   stream=archive.extractfile(entry) if entry.isfile() else None
   content=None
   if stream:
    h=hashlib.sha256()
    for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    content=h.hexdigest()
   if entry.name in entries:raise ValueError('Duplicate archive entry')
   entries[entry.name]={'type':entry.type.decode(),'mode':entry.mode,'uid':entry.uid,'gid':entry.gid,'mtime':entry.mtime,'link':entry.linkname,'sha256':content}
 return entries


def run_relations(run,jar,target,credential,backend,recovery=None,case_ids=None):
 from generate_v048 import catalog,generate
 run.mkdir(parents=True,exist_ok=True);records=[];capsule={};snapshot=None;baseline=None;journal=[];errors=[];outcomes=[]
 def record(status,data):
  e={'index':len(journal),'previous':journal[-1]['sha256'] if journal else None,'status':status,'data':data};e['sha256']=digest(e);journal.append(e)
  with (run/'campaign-journal.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(e)+'\n');f.flush();os.fsync(f.fileno())
 def observe():
  resources={};memberships={};spec=catalog()['relation_spec']
  for r in capsule['resources']:
   key=re.sub('[^A-Za-z0-9_]','_',r['logicalId']);route=capsule['bindings']['ROUTE_'+key]
   path=r['detail_template'].replace('{'+r['route_parameter']+'}',str(route))
   resources[r['logicalId']]=json_request(target+path,token=backend.token)
   if r['resourceType']==spec['child_type']:
    memberships[r['logicalId']]=json_request(target+spec['collection'].replace('{'+spec['child_parameter']+'}',str(route)),token=backend.token)
  return {'resources':resources,'memberships':memberships}
 class Proxy(BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def handle_request(self):
   nonlocal capsule,snapshot,baseline
   try:
    if self.headers.get('Authorization')!='Bearer '+credential:raise ValueError('Proxy authentication mismatch')
    body=self.rfile.read(int(self.headers.get('Content-Length',0))) if self.command!='GET' else None
    if '/__checkpoint/' in self.path:
     action=self.path.rsplit('/',1)[-1]
     if action=='ping':value={'ready':True}
     elif action=='save':
      if snapshot:raise ValueError('Duplicate checkpoint')
      capsule=json.loads(body);baseline=observe()
      if len(capsule['resources'])!=6 or any(baseline['memberships'].values()):raise ValueError('Expected six verified resources and empty initial memberships')
      snapshot=backend.save('relation-checkpoint')
      if observe()!=baseline:raise ValueError('Checkpoint restart changed baseline')
      write(run/'checkpoint-model-v048.json',capsule);write(run/'checkpoint-observations-v048.json',baseline)
      record('CHECKPOINT_SAVED',{'model_sha256':digest(capsule),'observations_sha256':digest(baseline),'snapshot_hashes':snapshot['hashes']});value={'saved':True}
     elif action=='visible-labels':
      def fetch_page(path):
       status,payload=request(target+path,token=backend.token)
       try:decoded=json.loads(payload)
       except ValueError:decoded={'raw_body':payload.decode(errors='replace')}
       records.append(dict(index=len(records),method='GET',path='/api/v1'+path,status=status,request=None,response=decoded,observation='PAGINATED_VISIBLE_LABELS'));persist_http(run,records[-1])
       return status,payload
      value=collect_visible_labels(fetch_page)
     elif action=='resume':value=capsule
     elif action=='verify':
      if observe()!=baseline:raise ValueError('Restored resources/memberships differ')
      record('API_RELATIONS_RESTORED',{'observations_sha256':digest(baseline)});value={'verified':True}
     else:raise ValueError('Unknown control')
     code=200;response=json.dumps(value).encode()
    else:
     disk_guard(run,128)
     code,response=request(target+self.path.removeprefix('/api/v1'),method=self.command,body=json.loads(body) if body else None,token=backend.token)
     try:decoded=json.loads(response)
     except ValueError:decoded={'raw_body':response.decode(errors='replace')}
     records.append(dict(index=len(records),method=self.command,path=self.path,status=code,request=json.loads(body) if body else None,response=decoded));persist_http(run,records[-1])
   except Exception as e:errors.append(str(e));code=500;response=json.dumps({'error':str(e)}).encode()
   self.send_response(code);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(response)
  do_GET=handle_request;do_POST=handle_request;do_PUT=handle_request;do_DELETE=handle_request
 server=HTTPServer(('127.0.0.1',0),Proxy);threading.Thread(target=server.serve_forever,daemon=True).start()
 proxy='http://127.0.0.1:'+str(server.server_port)+'/api/v1'
 result={'version':'v048','status':'NOT_ACCEPTED','scope':'RELATION_HISTORY_REMOVE_REATTACH_SHARED_UPDATE; SIX_OWN_RESOURCES','fixture_only':getattr(backend,'fixture_only',False),'true_concurrency':False,'full_coverage':False}
 try:
  disk_guard(run)
  queue=catalog()
  if case_ids is not None:
   queue['items']=[c for c in queue['items'] if c['case_id'] in case_ids]
   if len(queue['items'])!=len(case_ids):raise ValueError('Unknown/duplicate case selection')
  write(run/'relation-catalog-v048.json',queue)
  if recovery:
   capsule=recovery['capsule'];snapshot=recovery['snapshot'];baseline=recovery['baseline']
   record('PARENT_V031_VERIFIED',recovery['provenance'])
   backend.save('before-resume');backend.restore(snapshot)
   if observe()!=baseline:raise ValueError('Original resource/relation baseline differs; continuation blocked')
   write(run/'checkpoint-model-v048.json',capsule);write(run/'checkpoint-observations-v048.json',baseline)
   record('API_RELATIONS_RESTORED',{'observations_sha256':digest(baseline)})
   result.update(resources_recreated=False,prefix_replayed=False,resumed_from_v031=True)
  for index,case in enumerate(queue['items']):
   disk_guard(run)
   backend.token=backend.ensure_authenticated();record('AUTH_VALIDATED',{'case_id':case['case_id']})
   phase=run/('case-'+str(index+1));project=generate(phase,case,proxy,capsule['resources'] if index or recovery else None);boundary=len(records)
   native=subprocess.run(['java','-jar',str(jar.resolve()),'run','--random-seed','1',str(project)],env=dict(os.environ,SBT_AUTH_TOKEN=credential),capture_output=True,text=True,timeout=180)
   log=(native.stdout+native.stderr).replace(credential,'<redacted>');(phase/'native.log').write_text(log,encoding='utf-8')
   checks=native_markers(log,'RELATION_CHECK');write(phase/'checks.json',checks)
   if errors:raise RuntimeError('Proxy error: '+errors[0])
   if not snapshot:raise RuntimeError('No relation checkpoint; preserve bootstrap log')
   failures=[c for c in checks if c['pass'] is False];uncertain=[c for c in checks if c['pass'] is None]
   passed=native.returncode==0 and 'Test Result: SUCCESS' in log and 'RELATION_CASE_COMPLETED '+case['case_id'] in log and len(checks)==case['expected_checks'] and not failures
   if not passed and not failures:raise RuntimeError('Native relation case incomplete without a semantic failure marker')
   if index or recovery:
    ctx=native_markers(log,'RELATION_CONTEXT')
    if ctx!=[capsule['resources']]:raise ValueError('Resumed Context differs')
    current=records[boundary:]
    if any(r['method']=='PUT' and r['path'] in ('/api/v1/projects','/api/v1/labels') or r['method']=='PUT' and re.fullmatch(r'/api/v1/projects/\d+/tasks',r['path']) for r in current):raise ValueError('Resume recreated resources')
   outcome={'case_id':case['case_id'],'pass':passed,'native_exit':native.returncode,'checks':checks,'classification':('COMPLETED_WITH_ABSENCE_UNDETERMINED' if uncertain else 'PASS') if passed else 'SEMANTIC_CANDIDATE','semantic_verdict':'UNDETERMINED' if uncertain and passed else 'PASS' if passed else 'FAIL','absence_undetermined_count':sum(c.get('kind') in ('absence','deleted_child_membership') for c in uncertain),'collection_undetermined_count':sum(c.get('kind')=='visible_collection' for c in uncertain),'status_expectation_mismatches':[dict(name=c['name'],expected=404,observed=c['status']) for c in uncertain if c.get('kind')=='absence']};outcomes.append(outcome);write(run/'outcomes_v048.json',outcomes)
   record('CASE_PASSED' if passed else 'CASE_FAILED',{'case_id':case['case_id'],'checks_sha256':digest(checks)})
   if not passed:backend.save('finding-'+str(index+1))
   backend.restore(snapshot)
   if observe()!=baseline:raise ValueError('Post-case restoration differs; continuation blocked')
   record('BASELINE_RELATIONS_VERIFIED',{'case_id':case['case_id'],'observations_sha256':digest(baseline)})
   write(run/'progress_v048.json',{'completed_case_ids':[o['case_id'] for o in outcomes],'next_index':index+1,'same_resource_and_membership_baseline':True})
   print('Relation case '+case['case_id']+': '+outcome['classification'],flush=True)
  result.update(status='V048_RELATION_ACCEPTANCE_COMPLETED',completed_cases=len(outcomes),semantic_candidate_count=sum(not o['pass'] for o in outcomes),absence_undetermined_count=sum(o['absence_undetermined_count'] for o in outcomes),collection_undetermined_count=sum(o['collection_undetermined_count'] for o in outcomes),status_expectation_mismatch_count=sum(len(o['status_expectation_mismatches']) for o in outcomes),semantic_checks=sum(len(o['checks']) for o in outcomes),resources=6,relation_baseline_restored=True,current_http_requests=len(records),live_execution=not result['fixture_only'])
 except Exception as e:
  result['error']=str(e)
  if snapshot and baseline:
   try:
    backend.save('infrastructure-stop')
    backend.restore(snapshot)
    if observe()!=baseline:raise ValueError('Error cleanup baseline differs')
    record('INFRASTRUCTURE_STOP_BASELINE_RESTORED',{'observations_sha256':digest(baseline)})
    result['baseline_restored_after_error']=True
   except Exception as cleanup:
    result['baseline_restored_after_error']=False;result['cleanup_error']=str(cleanup)
 finally:
  server.shutdown()
  if recovery and recovery.get('historical_first_case'):
   result.update(historical_first_case_verified=True,historical_first_case_checks=54,historical_first_case_raw_http_available=False,combined_completed_cases=1+result.get('completed_cases',0),combined_semantic_checks=54+result.get('semantic_checks',0))
  try:
   audit=audit_statuses(records,json.loads((ROOT/'vikunja-live-swagger.json').read_text()))
   write(run/'contract-status-audit-v048.json',audit)
   result['undocumented_status_count']=audit['undocumented_status_count']
  except Exception as audit_error:
   result['status']='NOT_ACCEPTED';result['status_audit_error']=str(audit_error)
  pack_review(run,result,records)
 return result
