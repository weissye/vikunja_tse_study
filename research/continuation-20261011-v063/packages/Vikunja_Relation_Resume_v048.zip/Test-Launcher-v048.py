import sys,tempfile,json
from pathlib import Path
from unittest.mock import patch
import run_relations_v048 as launcher
import resume_proof_v048 as proof
import parent_v048 as parent
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp);study=root/'study';study.mkdir();old=root/'parent';old.mkdir();(old/'review_v031.zip').write_bytes(b'fixture')
 (root/'V039_Recovery_v046.zip').write_bytes(b'fixture')
 generated=[]
 def generate(path,case,proxy,resources):generated.append(case['case_id']);path.mkdir(parents=True)
 with patch.object(launcher,'ROOT',root),patch.object(proof,'verify_first',return_value={'fixture':True}),patch.object(parent,'load_parent',return_value={'capsule':{'resources':[]},'provenance':{}}),patch.object(launcher,'generate',side_effect=generate),patch.object(launcher.engine,'disk_guard'),patch.object(sys,'argv',['run','--study-root',str(study),'--jar',str(root/'fixture.jar'),'--resume-from',str(old)]):
  assert launcher.main()==0
 assert generated==['relation-history-second-label']
 assert len(list(study.glob('runs/*/review_v048.zip')))==1
print('V048_STATIC_LAUNCHER_FIXTURE_PASS: complete entrypoint; only second case generated. Not native/live.')
