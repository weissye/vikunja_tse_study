"""Contract-derived schema queue; original Context generator, bounded local scope."""
import argparse,json,sys,subprocess,hashlib,getpass,uuid,os
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_work_v023 as storage
import queue_engine_v027 as engine

def create_queue(catalog,instances=2):
 items=[]
 for case in sorted(catalog['cases'],key=lambda c:c['id']):
  for instance in range(1,instances+1):
   logical=case['resource']+'_'+str(instance)
   items.append({'queue_id':case['id']+'@'+logical,'rule_id':case['id'],'logical_id':logical,'source_pointer':case['source_pointer'],'rule':case})
 if not items or len({x['queue_id'] for x in items})!=len(items):raise ValueError('Empty or ambiguous queue')
 return {'version':'v027','selection':'All emitted schema rules for selected independent Context resources, two instances per resource; sorted rule IDs','resources':['/labels','/projects','/teams'],'items':items,'blocked':catalog['blocked'],'deferred_families':catalog['deferred_families'],'full_system_coverage':False,'state_preservation':'Research oracle hypothesis, not an OpenAPI postcondition'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--study-root',required=True,type=Path);p.add_argument('--jar',required=True,type=Path);p.add_argument('--live',action='store_true');a=p.parse_args()
 run=a.study_root/'runs'/('catalog-queue-v027-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True)
 try:
  subprocess.run([sys.executable,str(ROOT/'engine-v010'/'Test-Package-v010.py')],check=True)
  cmd=[sys.executable,'-m','generator_v56','context-generate','--openapi',str(ROOT/'engine-v010'/'vikunja-live-swagger.json'),'--output',str(run/'catalog'/'spec'/'js'),'--name','vikunja','--base-url','http://127.0.0.1:3456/api/v1','--instances-per-entity','2','--seed','1','--negative-schema','--method-adapter',str(ROOT/'engine-v010'/'method_adapter_v010.json')]
  for r in ['/labels','/projects','/teams']:cmd+=['--resource',r]
  generated=subprocess.run(cmd,cwd=ROOT/'engine-v010'/'source',capture_output=True,text=True,timeout=60)
  (run/'catalog-generation.log').write_text(generated.stdout+generated.stderr)
  if generated.returncode:raise RuntimeError('Static generator failed; see catalog-generation.log')
  catalog=json.loads((run/'catalog'/'spec'/'js'/'negative_catalog.json').read_text())
  queue=create_queue(catalog);engine.write(run/'queue_v027.json',queue)
  print('Planned checks:',len(queue['items']),flush=True)
  if not a.live:
   result={'version':'v027','status':'CATALOG_QUEUE_V027_STATIC_READY','planned_rules':len(queue['items']),'live_execution':False};engine.pack_review(run,result,[])
  else:
   if os.name!='nt':raise ValueError('Live work adapter requires Windows')
   if storage.sha(a.jar)!='dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b':raise ValueError('Native JAR mismatch')
   target='http://127.0.0.1:3456/api/v1';status,contract=engine.request(target+'/docs.json')
   if status!=200 or hashlib.sha256(contract).hexdigest()!=storage.sha(ROOT/'engine-v010'/'vikunja-live-swagger.json'):raise ValueError('Live contract mismatch')
   backend=storage.BindBackend('vikunja-research-sut',target,run)
   password=getpass.getpass('Vikunja password for SBT-tester: ')
   def login():return engine.json_request(target+'/login',method='POST',body={'username':'SBT-tester','password':password})['token']
   backend.token=login();backend.refresh_token=login
   result=engine.run_campaign(run,a.jar,target,uuid.uuid4().hex,backend,seed=1)
 except Exception as e:
  result={'version':'v027','status':'NOT_ACCEPTED','error':str(e)};engine.pack_review(run,result,[])
 print('Status:',result['status']);print('Review ZIP:',run/'review_v027.zip')
 if result.get('error'):print('Error:',result['error'])
 return 0 if result['status'] in ('CATALOG_QUEUE_V027_STATIC_READY','CATALOG_QUEUE_V027_COMPLETED') else 1
if __name__=='__main__':raise SystemExit(main())
