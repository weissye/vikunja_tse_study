param([switch]$RunLive,[string]$StudyRoot='C:\work\temp\work-v011-20261011-062659\v',[string]$ProvengoJar='C:\work\temp\vikunja_tse_study\Provengo-2026-01-10.uber.jar')
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_CATALOG_QUEUE v027'
& python (Join-Path $PSScriptRoot 'Verify-Package-v027.py')
if ($LASTEXITCODE -ne 0) { throw 'v027 package integrity failed.' }
$arguments=@((Join-Path $PSScriptRoot 'run_queue_v027.py'),'--study-root',$StudyRoot,'--jar',$ProvengoJar)
if ($RunLive) { $arguments += '--live' }
& python @arguments
if ($LASTEXITCODE -ne 0) { throw 'Queue incomplete. Preserve the review and snapshots.' }
