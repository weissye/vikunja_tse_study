"""Supervisor fixture: failure/pass/failure, preserved outcomes and restored baseline."""
import sys,tempfile,json,copy
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parent))
import queue_engine_v027 as q
import run_queue_v027 as launcher

def test_supervisor():
 with tempfile.TemporaryDirectory() as directory:
  run=Path(directory);state={'title':'baseline'};restores=[]
  class Backend:
   fixture_only=True
   token='fixture'
   def save(self,label):return {'folder':label,'hashes':{'fixture':q.digest(state)},'data':copy.deepcopy(state)}
   def restore(self,snapshot):state.clear();state.update(copy.deepcopy(snapshot['data']));restores.append(snapshot['folder'])
  resource={'logicalId':'ModelsLabel_1','resourceType':'ModelsLabel','expected':{'title':'baseline'},'revision':2,'verifiedRevision':2,'detail_template':'/labels/{id}','route_parameter':'id'}
  capsule={'resources':[resource],'bindings':{'ROUTE_ModelsLabel_1':120},'cursor':{'seed':1}}
  cases=[{'queue_id':str(i),'rule_id':'rule'+str(i),'logical_id':'ModelsLabel_1'} for i in range(3)]
  q.write(run/'queue_v027.json',{'items':cases})
  actual_request=q.request
  def request(url,method='GET',body=None,token=None):
   if url.startswith('http://fixture'):
    if method!='GET' and body.get('invalid'):
     state['title']='changed';return 200,json.dumps(state).encode()
    return (400 if method!='GET' else 200),json.dumps(state).encode()
   return actual_request(url,method,body,token)
  original_run=q.subprocess.run;original_request=q.request
  calls=[0]
  def native(cmd,**kwargs):
   if cmd[0]!= 'java':return SimpleNamespace(returncode=0,stdout='',stderr='')
   i=calls[0];calls[0]+=1;project=Path(cmd[-1]);phase=project.name
   plan=json.loads((run/(phase+'-plan.json')).read_text())
   # Recover the dynamically assigned localhost proxy address from generation call.
   proxy=native.proxy
   if i==0:q.json_request(proxy+'/__checkpoint/save',method='POST',body=capsule,token='fixture')
   else:
    q.json_request(proxy+'/__checkpoint/resume',token='fixture')
    q.json_request(proxy+'/__checkpoint/verify',token='fixture')
   status,_=q.request(proxy+'/labels/120',method='POST',body={'invalid':i!=1},token='fixture')
   passed=i==1
   check={'rule_id':plan['rule_id'],'logicalId':'ModelsLabel_1','resource_id':120,'pass':passed,'status':status,'rejected':passed}
   log='CHECKPOINT_CONTEXT '+json.dumps(capsule['resources'])+'\nNEGATIVE_CHECK '+json.dumps(check)+'\nTest Result: '+('SUCCESS' if passed else 'FAIL')
   return SimpleNamespace(returncode=0 if passed else 1,stdout=log,stderr='')
  def dispatch(cmd,**kwargs):
   if cmd[0]!='java':native.proxy=cmd[cmd.index('--base-url')+1]
   return native(cmd,**kwargs)
  q.request=request;q.subprocess.run=dispatch
  try:result=q.run_campaign(run,run/'fixture.jar','http://fixture','fixture',Backend())
  finally:q.request=original_request;q.subprocess.run=original_run
  assert result['status']=='CATALOG_QUEUE_V027_COMPLETED',result
  assert result['completed_rules']==3 and result['finding_count']==2
  assert len(restores)==2 and state=={'title':'baseline'}
  outcomes=json.loads((run/'outcomes_v027.json').read_text());assert [o['classification'] for o in outcomes]==['INVALID_INPUT_ACCEPTED','PASS','INVALID_INPUT_ACCEPTED']
  progress=json.loads((run/'queue-progress-v027.json').read_text());assert progress['remaining_queue_ids']==[]
  assert len(outcomes)==3
  print('V027_SUPERVISOR_FIXTURE_PASS: FAIL/PASS/FAIL, two findings retained, baseline restored, queue completed')
if __name__=='__main__':test_supervisor()
