"""Two-rule native acceptance campaign; original generator and quiescent checkpoints."""
import argparse, copy, getpass, hashlib, json, os, re, subprocess, threading, time, urllib.error, urllib.request, zipfile, tarfile, shlex, uuid, shutil
from datetime import datetime, timezone
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer

ROOT=Path(__file__).resolve().parent/'engine-v010'
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2),encoding='utf-8')
def request(url,method='GET',body=None,token=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 r=urllib.request.Request(url,data=json.dumps(body).encode() if body is not None else None,headers=headers,method=method)
 try:
  with urllib.request.urlopen(r,timeout=30) as response:return response.status,response.read()
 except urllib.error.HTTPError as response:return response.code,response.read()
def json_request(url,**kwargs):
 status,body=request(url,**kwargs)
 if not 200<=status<300:raise RuntimeError('HTTP '+str(status)+' at '+url)
 return json.loads(body)
def native_markers(log,marker):return [json.loads(line.split(marker+' ',1)[1]) for line in log.splitlines() if marker+' ' in line]
def pack_review(run,result,records):
 write(run/'http-evidence.json',records);write(run/'result_v027.json',result)
 files=sorted(p for p in run.rglob('*') if p.is_file() and not any(part in ('.private-snapshots','products','__pycache__') for part in p.relative_to(run).parts) and p.name not in ('review_v027.zip','manifest_v027.json'))
 manifest={str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};write(run/'manifest_v027.json',manifest)
 with zipfile.ZipFile(run/'review_v027.zip','w',zipfile.ZIP_DEFLATED) as archive:
  for p in files+[run/'manifest_v027.json']:archive.write(p,str(p.relative_to(run)))

class DockerVolumeBackend:
 """Cold backup/rollback of exclusive SQLite/files volumes; snapshots stay private."""
 def __init__(self,container,helper_container,url,token,run):
  if not re.fullmatch(r'[A-Za-z0-9_.-]+',container):raise ValueError('Invalid container name')
  self.container=container;self.url=url;self.token=token;self.run=run
  self.helper=self.command(['inspect','--format','{{.Image}}',helper_container]).strip()
  c=json.loads(self.command(['inspect',container]))[0]
  env=dict(item.split('=',1) for item in c['Config'].get('Env',[]) if '=' in item)
  if env.get('VIKUNJA_DATABASE_TYPE','sqlite')!='sqlite':raise ValueError('Only SQLite checkpoint adapter is implemented')
  if not env.get('VIKUNJA_DATABASE_PATH','').startswith('/db/'):raise ValueError('Database path must be explicitly configured under /db')
  self.mounts=[m for m in c['Mounts'] if m['Destination'] in ('/db','/app/vikunja/files')]
  if len(self.mounts)!=2 or any(m['Type']!='volume' or not m.get('Name') or not m['RW'] for m in self.mounts):raise ValueError('Requires exactly two writable named volumes at /db and /app/vikunja/files')
  ids=self.command(['ps','-aq']).split()
  if ids:
   others=json.loads(self.command(['inspect',*ids]))
   names={m['Name'] for m in self.mounts}
   if any(o['Id']!=c['Id'] and any(m.get('Name') in names for m in o['Mounts']) for o in others):raise ValueError('Checkpoint volumes are shared with another container')
  ports=c['HostConfig'].get('PortBindings',{}).get('3456/tcp',[])
  if not any(p.get('HostIp')=='127.0.0.1' and p.get('HostPort')=='3456' for p in ports):raise ValueError('Expected isolated local Vikunja at port 3456')
  write(run/'snapshot-adapter.json',{'kind':'COLD_NAMED_VOLUME_SNAPSHOT','container':container,'image':c['Image'],'helper_image':self.helper,'destinations':[m['Destination'] for m in self.mounts],'scope':'SQLite and files persistent volumes only; process clocks, queues and external services excluded'})
 def command(self,args):
  try:return subprocess.run(['docker',*args],check=True,capture_output=True,text=True,timeout=120).stdout
  except subprocess.CalledProcessError as error:raise RuntimeError('Docker '+args[0]+' failed: '+error.stderr.strip()[:1500]) from error
 def helper_command(self,directory,script):
  self.command(['run','--rm','--pull=never','--network','none','--user','0:0','--volumes-from',self.container,'--mount','type=bind,src='+str(directory.resolve())+',dst=/snapshot','--entrypoint','/bin/sh',self.helper,'-c',script])
 def ready(self):
  for _ in range(30):
   try:
    if json_request(self.url+'/info').get('version')=='v2.6.0':
     if hasattr(self,'refresh_token'):self.token=self.refresh_token()
     return
   except Exception:pass
   time.sleep(1)
  raise RuntimeError('Vikunja did not recover after checkpoint operation')
 def save(self,label):
  folder=self.run/'.private-snapshots'/label;folder.mkdir(parents=True,exist_ok=False)
  self.command(['stop',self.container])
  try:self.helper_command(folder,'set -eu; tar -C /db -cpf /snapshot/db.tar .; tar -C /app/vikunja/files -cpf /snapshot/files.tar .')
  finally:self.command(['start',self.container])
  self.ready()
  return {'folder':str(folder),'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.tar')}}
 def restore(self,snapshot):
  folder=Path(snapshot['folder'])
  if set(snapshot['hashes'])!={'db.tar','files.tar'}:raise ValueError('Incomplete snapshot')
  for name,h in snapshot['hashes'].items():
   if hashlib.sha256((folder/name).read_bytes()).hexdigest()!=h:raise ValueError('Snapshot integrity mismatch')
  self.command(['stop',self.container])
  # Removal is confined to the two exclusive study volumes being rolled back.
  self.helper_command(folder,'set -eu; find /db -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +; tar -C /db -xpf /snapshot/db.tar; find /app/vikunja/files -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +; tar -C /app/vikunja/files -xpf /snapshot/files.tar')
  # tar implementations can leave the root directory mtime changed by extraction.
  # Restore every archived directory's metadata, children before parents.
  commands=['set -eu']
  for name,destination in (('db.tar','/db'),('files.tar','/app/vikunja/files')):
   with tarfile.open(folder/name) as archive:
    directories=sorted((e for e in archive if e.isdir()),key=lambda e:e.name.count('/'),reverse=True)
    for entry in directories:
     relative=Path(entry.name)
     if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe archive directory')
     if int(entry.mtime)!=entry.mtime:raise ValueError('Subsecond directory timestamps are unsupported')
     path=destination+'/'+relative.as_posix() if relative.as_posix()!='.' else destination
     timestamp=datetime.fromtimestamp(entry.mtime,timezone.utc).strftime('%Y%m%d%H%M.%S')
     quoted=shlex.quote(path)
     commands.extend(['chown '+str(entry.uid)+':'+str(entry.gid)+' '+quoted,
                      'chmod '+format(entry.mode,'o')+' '+quoted,
                      'TZ=UTC touch -t '+shlex.quote(timestamp)+' '+quoted])
  self.helper_command(folder,'; '.join(commands))
  # Keep strict equality, including directory mtime. Never start on mismatch.
  check=folder/('restored-check-v010-'+uuid.uuid4().hex);check.mkdir(exist_ok=False)
  self.helper_command(check,'set -eu; tar -C /db -cpf /snapshot/db.tar .; tar -C /app/vikunja/files -cpf /snapshot/files.tar .')
  differences=[]
  for name in snapshot['hashes']:
   before,after=archive_tree(folder/name),archive_tree(check/name)
   differences.extend({'archive':name,'entry':key,'before':before.get(key),'after':after.get(key)} for key in sorted(set(before)|set(after)) if before.get(key)!=after.get(key))
  write(self.run/'restore-verification-v010.json',{'strict_equality':not differences,'includes_directory_mtime':True,'differences':differences})
  if differences:raise RuntimeError('Restored persistent volume tree differs from checkpoint; server remains stopped')
  self.command(['start',self.container]);self.ready()

def archive_tree(path):
 entries={}
 with tarfile.open(path) as archive:
  for entry in archive:
   stream=archive.extractfile(entry) if entry.isfile() else None
   content=None
   if stream:
    h=hashlib.sha256()
    for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    content=h.hexdigest()
   if entry.name in entries:raise ValueError('Duplicate archive entry')
   entries[entry.name]={'type':entry.type.decode(),'mode':entry.mode,'uid':entry.uid,'gid':entry.gid,'mtime':entry.mtime,'link':entry.linkname,'sha256':content}
 return entries


def run_campaign(run,jar,target,token,backend,seed=1,recovery=None):
 run.mkdir(parents=True,exist_ok=True);records=[];journal=[];capsule={};snapshot=None;observations={};proxy_errors=[]
 def record(status,data):
  e={'index':len(journal),'previous':journal[-1]['sha256'] if journal else None,'status':status,'data':data};e['sha256']=digest(e);journal.append(e)
  with (run/'campaign-journal.jsonl').open('a',encoding='utf-8') as stream:stream.write(json.dumps(e)+'\n');stream.flush();os.fsync(stream.fileno())
 def observe():
  result={}
  for r in capsule['resources']:
   key=re.sub(r'[^A-Za-z0-9_]','_',r['logicalId']);route=capsule['bindings']['ROUTE_'+key]
   path=r['detail_template'].replace('{'+r['route_parameter']+'}',str(route))
   result[r['logicalId']]=json_request(target+path,token=getattr(backend,'token',token))
  return result
 class Proxy(BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def handle_request(self):
   nonlocal capsule,snapshot,observations
   try:
    if self.headers.get('Authorization')!='Bearer '+token:raise RuntimeError('Checkpoint proxy credential mismatch')
    body=self.rfile.read(int(self.headers.get('Content-Length',0))) if self.command!='GET' else None
    if '/__checkpoint/' in self.path:
     action=self.path.rsplit('/',1)[-1]
     if action=='ping':value={'ready':True}
     elif action=='save':
      if snapshot is not None:raise RuntimeError('Duplicate checkpoint')
      capsule=json.loads(body);observations=observe();snapshot=backend.save('checkpoint')
      if observe()!=observations:raise RuntimeError('Saving/restarting changed the checkpoint API state')
      write(run/'checkpoint-model.json',capsule);write(run/'checkpoint-observations.json',observations)
      record('CHECKPOINT_SAVED',{'model_sha256':digest(capsule),'observations_sha256':digest(observations),'snapshot_hashes':snapshot.get('hashes',{})})
      value={'saved':True,'resources':len(capsule['resources'])}
     elif action=='resume':value=capsule
     elif action=='verify':
      if observe()!=observations:raise RuntimeError('Post-restore API observations differ; continuation blocked')
      value={'verified':True};record('API_STATE_RESTORED',{'observations_sha256':digest(observations)})
     else:raise ValueError('Unknown checkpoint control')
     code=200;response=json.dumps(value).encode()
    else:
     code,response=request(target+self.path.removeprefix('/api/v1') if hasattr(str,'removeprefix') else target+self.path[len('/api/v1'):],method=self.command,body=json.loads(body) if body else None,token=getattr(backend,'token',token))
     try:decoded=json.loads(response)
     except (ValueError,UnicodeError):decoded={'raw_body':response.decode('utf-8',errors='replace')}
     records.append({'index':len(records),'method':self.command,'path':self.path,'status':code,'request':json.loads(body) if body else None,'response':decoded})
   except Exception as error:
    proxy_errors.append(str(error));code=500;response=json.dumps({'error':str(error)}).encode()
   self.send_response(code);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(response)
  do_GET=handle_request;do_POST=handle_request;do_PUT=handle_request;do_PATCH=handle_request
 server=HTTPServer(('127.0.0.1',0),Proxy);threading.Thread(target=server.serve_forever,daemon=True).start()
 proxy='http://127.0.0.1:'+str(server.server_port)+'/api/v1'
 result={'version':'v027','status':'NOT_ACCEPTED','scope':'CONTRACT_SCHEMA_QUEUE; SIX OWN_CREATED_INDEPENDENT_RESOURCES','full_catalog_campaign':False,'engine_stacks_restored':False,'fixture_only':getattr(backend,'fixture_only',False),'live_vikunja':not getattr(backend,'fixture_only',False)}
 try:
  queue=json.loads((run/'queue_v027.json').read_text())['items'];selected=[item['rule_id'] for item in queue]; outcomes=[]
  if recovery:
   capsule=recovery['capsule'];observations=recovery['observations'];snapshot=recovery['snapshot']
   seed=recovery['seed'];result['target_resource_id']=recovery['target_resource_id']
   result['recovery_from_v008']=True;result['prefix_replayed']=False
   result['historical_completed_rules']=1;result['current_completed_rules']=0
   record('PARENT_V008_VERIFIED',recovery['provenance'])
   backend.restore(snapshot)
   record('PERSISTENT_STATE_RESTORED',{'snapshot_hashes':snapshot['hashes']})
   if not getattr(backend,'fixture_only',False):
    if hashlib.sha256(request(target+'/docs.json')[1]).hexdigest()!=hashlib.sha256((ROOT/'vikunja-live-swagger.json').read_bytes()).hexdigest():raise RuntimeError('Live contract differs; continuation blocked')
   if observe()!=observations:raise RuntimeError('Restored API state differs; continuation blocked')
  for index,rule in enumerate(selected):
   if recovery and index==0:continue
   phase='bootstrap' if index==0 else 'resume-'+str(index).zfill(4)
   plan={'version':'v010','mode':'bootstrap' if index==0 else 'resume','rule_id':rule,'logical_id':queue[index]['logical_id'],'seed':seed,'completed_rule_ids':selected[:index]}
   if index:plan['resources']=capsule['resources']
   write(run/(phase+'-plan.json'),plan)
   project=run/phase
   cmd=[os.sys.executable,'-m','generator_v56','context-generate','--openapi',str(ROOT/'vikunja-live-swagger.json'),'--output',str(project/'spec/js'),'--name','vikunja','--base-url',proxy,'--instances-per-entity','2','--seed',str(seed),'--negative-schema','--method-adapter',str(ROOT/'method_adapter_v010.json'),'--checkpoint-plan',str(run/(phase+'-plan.json'))]
   for path in ('/labels','/projects','/teams'):cmd+=['--resource',path]
   generated=subprocess.run(cmd,cwd=ROOT/'source',capture_output=True,text=True,timeout=60)
   if generated.returncode:raise RuntimeError('Generator failed: '+generated.stderr)
   env=dict(os.environ,SBT_AUTH_TOKEN=token);boundary=len(records)
   result['live_execution_started']=not getattr(backend,'fixture_only',False)
   native=subprocess.run(['java','-jar',str(jar.resolve()),'run','--random-seed',str(seed),str(project)],env=env,capture_output=True,text=True,timeout=180)
   result[phase+'_native_exit']=native.returncode
   log=(native.stdout+native.stderr).replace(token,'<redacted>') if token else native.stdout+native.stderr
   (run/(phase+'.log')).write_text(log,encoding='utf-8')
   checks=native_markers(log,'NEGATIVE_CHECK');write(run/(phase+'-checks.json'),checks)
   result[phase+'_failure_messages']=[line.split('FAIL:',1)[1].strip() for line in log.splitlines() if 'FAIL:' in line]
   if index and not checks and not any(r['method']!='GET' for r in records[boundary:]):
    record('RESUME_BLOCKED_BEFORE_MUTATION',{'native_exit':native.returncode,'failure_messages':result[phase+'_failure_messages']})
    raise RuntimeError('Resume did not pass state/model verification; next mutation was blocked')
   if len(checks)!=1 or checks[0]['rule_id']!=rule:raise RuntimeError('Expected exactly one completed independent rule check')
   if proxy_errors:raise RuntimeError('Checkpoint proxy error: '+proxy_errors[0])
   if snapshot is None:raise RuntimeError('No checkpoint saved')
   check=checks[0]
   item=queue[index]
   if check['logicalId']!=item['logical_id']:raise RuntimeError('Rule subject mismatch')
   if index:
    ctx=native_markers(log,'CHECKPOINT_CONTEXT')
    if ctx!=[capsule['resources']]:raise RuntimeError('Resumed Context differs from saved model')
    resumed=records[boundary:]
    if any(r['method']=='PUT' and r['path'].count('/')==3 for r in resumed):raise RuntimeError('Resume unexpectedly created a resource')
    if sum(r['method']!='GET' for r in resumed)!=1:raise RuntimeError('Resume must execute only the next negative mutation')
   passed=bool(check['pass'])
   if passed and (native.returncode!=0 or 'Test Result: SUCCESS' not in log):raise RuntimeError('Check/native verdict disagreement')
   if not passed and native.returncode==0:raise RuntimeError('Failed check had successful native exit')
   outcome={'queue_id':item['queue_id'],'rule_id':rule,'logical_id':item['logical_id'],'check':check,'native_exit':native.returncode,'classification':'PASS' if passed else ('SERVER_ERROR' if check['status']>=500 else 'INVALID_INPUT_ACCEPTED' if not check['rejected'] else 'REJECTED_WITH_STATE_CHANGE')}
   print('Queue '+str(index+1)+'/'+str(len(queue))+': '+item['queue_id']+' -> '+outcome['classification'],flush=True)
   outcomes.append(outcome);write(run/'outcomes_v027.json',outcomes)
   record('RULE_PASSED' if passed else 'RULE_FAILED',{'queue_id':item['queue_id'],'rule_id':rule,'check_sha256':digest(check),'native_exit':native.returncode})
   if not passed:
    backend.save('failed-state-'+str(index).zfill(4))
    backend.restore(snapshot)
    record('PERSISTENT_STATE_RESTORED',{'snapshot_hashes':snapshot.get('hashes',{})})
   if observe()!=observations:raise RuntimeError('Baseline observations differ; next rule blocked')
   record('BASELINE_VERIFIED',{'queue_id':item['queue_id'],'observations_sha256':digest(observations)})
   write(run/'queue-progress-v027.json',{'completed_queue_ids':[o['queue_id'] for o in outcomes],'remaining_queue_ids':[q['queue_id'] for q in queue[index+1:]],'next_index':index+1,'same_baseline_verified':True})
  result['current_native_http_requests']=len(records)
  result.update(status='CATALOG_QUEUE_V027_COMPLETED',finding_count=sum(not o['check']['pass'] for o in outcomes),completed_rules=len(outcomes),planned_rules=len(queue),resources_restored=len(capsule['resources']),context_equal=True,api_observations_equal=True,resume_create_requests=0,prefix_updates_per_resource=1,recovery_from_v008=False,live_snapshot_adapter_validated=not getattr(backend,'fixture_only',False))
 except Exception as error:result['error']=str(error)
 finally:
  server.shutdown();pack_review(run,result,records)
 return result

