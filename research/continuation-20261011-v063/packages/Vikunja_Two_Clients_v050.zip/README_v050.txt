VIKUNJA TWO AUTHENTICATED CLIENTS v050
Original generator, Context, Stories, Interfaces, DAL, verifiers preserved.
Two separate logins for SBT-tester; distinct credentials and identical /user identity verified before research execution. Password/token never logged. A and B are authenticated logical clients, each forwarded with its own token. This does not emulate browser cookies or persistent browser connections.
Sequential interleaving, not true concurrency: writes alternate A/B; each positive operation and final state is independently read via both clients. Six original v049 order cases, same six original v031 resources.
Per complete case: 7 writes + 60 per-operation reads + 16 final-state reads + 2 invalid-type requests + 32 unchanged-state reads = 117 checks. Six cases = 702 checks.
Prefix four relation mutations, tested tail three mutations. No general depth parameter, no additional users, no forbidden-resource tests. Negative []/123 title types are contract-derived on owned labels.
Raw HTTP records identify actor A/B and retain normalized application route. Final order comparison records expected-field projections and memberships, not entire database equality.
Original v031 private snapshot mandatory. Preserve every original run. Baseline restored and verified after each case; semantic candidate retained and next case attempted; infrastructure failures stop. Durable HTTP journal, atomic summaries, existing disk guards maintained.
Static and mocked tests passed locally; native/live v050 has not been executed here.
Run launcher without -RunLive first, then -RunLive. Live prompts once for password and may wait 65 seconds between logins to respect rate limiting. Original accepted v049 evidence included separately.
