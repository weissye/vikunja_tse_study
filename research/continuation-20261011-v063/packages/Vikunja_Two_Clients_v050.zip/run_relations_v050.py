import argparse,sys,json,hashlib,os,getpass,uuid,shutil
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import relation_engine_v050 as engine
import run_work_v023 as storage
from auth_v029 import Auth
from generate_v050 import catalog,generate

def main():
 p=argparse.ArgumentParser();p.add_argument('--study-root',type=Path,required=True);p.add_argument('--jar',type=Path,required=True);p.add_argument('--resume-from',type=Path,required=True);p.add_argument('--live',action='store_true');a=p.parse_args()
 run=a.study_root/'runs'/('relation-v050-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True)
 try:
  from parent_v050 import load_parent
  engine.disk_guard(run)
  recovery=load_parent(a.resume_from.resolve())
  engine.write(run/'parent-provenance-v050.json',recovery['provenance'])
  shutil.copy2(a.resume_from/'review_v031.zip',run/'parent-review-v031.zip')
  if not a.live:
   for i,case in enumerate(catalog()['items'],1):generate(run/('static-case-'+str(i)),case,'http://127.0.0.1:3456/api/v1',recovery['capsule']['resources'])
   engine.write(run/'relation-catalog-v050.json',catalog());result={'version':'v050','status':'V050_STATIC_READY','live_execution':False};engine.pack_review(run,result,[])
  else:
   if os.name!='nt':raise ValueError('Live adapter requires Windows')
   if storage.sha(a.jar)!='dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b':raise ValueError('JAR mismatch')
   target='http://127.0.0.1:3456/api/v1';status,body=engine.request(target+'/docs.json')
   if status!=200 or hashlib.sha256(body).hexdigest()!=storage.sha(ROOT/'engine-v010/vikunja-live-swagger.json'):raise ValueError('Live contract mismatch')
   # Probe documented label item update compatibility without authentication or mutation.
   import urllib.request,urllib.error
   probe=urllib.request.Request(target+'/labels/1',method='OPTIONS')
   with urllib.request.urlopen(probe,timeout=10) as response:allowed=response.headers.get('Allow','')
   if 'POST' not in {x.strip() for x in allowed.split(',')} or 'PUT' in {x.strip() for x in allowed.split(',')}:raise ValueError('Label method adapter live evidence differs')
   backend=storage.BindBackend('vikunja-research-sut',target,run)
   if json.loads((run/'snapshot-adapter.json').read_text())!=recovery['adapter']:raise ValueError('Server image/storage identity changed')
   password=getpass.getpass('Vikunja password for SBT-tester: ');auth=Auth(target,'SBT-tester',password,run)
   second=Auth(target,'SBT-tester',password,run)
   first_token=auth.ensure();second.pause(65);second_token=second.ensure()
   first_user=json.loads(auth.call('/user',token=first_token)[1]);second_user=json.loads(second.call('/user',token=second_token)[1])
   if not first_user.get('id') or first_token==second_token or first_user.get('id')!=second_user.get('id') or first_user.get('username')!=second_user.get('username'):raise ValueError('Client identities differ')
   engine.write(run/'client-identities-v050.json',{'clients':['A','B'],'same_user':True,'user_id':first_user.get('id'),'username':first_user.get('username'),'separate_logins':True,'distinct_tokens_verified':True,'true_concurrency':False})
   backend.ensure_authenticated=auth.ensure;backend.refresh_token=auth.ensure;backend.token=first_token
   backend.client_tokens={'A':first_token,'B':second_token};backend.client_auth={'A':auth,'B':second}
   result=engine.run_relations(run,a.jar,target,uuid.uuid4().hex,backend,recovery=recovery)
 except Exception as e:
  result={'version':'v050','status':'NOT_ACCEPTED','error':str(e)}
  try:
   engine.write(run/'launcher-error-v050.json',result)
  except OSError:pass
  print('Error preserved in original run where possible; no empty-evidence repack attempted.')
 print('Status:',result['status'])
 if (run/'review_v050.zip').is_file():print('Review ZIP:',run/'review_v050.zip')
 else:print('Diagnostic directory:',run)
 if result.get('error'):print('Error:',result['error'])
 return 0 if result['status'] in ('V050_STATIC_READY','V050_RELATION_ACCEPTANCE_COMPLETED') else 1
if __name__=='__main__':raise SystemExit(main())
