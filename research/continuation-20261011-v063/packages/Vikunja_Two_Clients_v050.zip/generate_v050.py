import json,subprocess,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine-v010/source'))
from generator_v56.render.context_model import build_model
from generator_v56.parsing.swagger_context import normalize_context_contract
from generator_v56.render.context_relations import infer_relations

def catalog():
 source=ROOT/'engine-v010/vikunja-live-swagger.json';raw,_=normalize_context_contract(json.loads(source.read_text()))
 c,entities=build_model(raw,['/projects','/projects/{id}/tasks','/labels'],2,1)
 spec=infer_relations(c,entities)
 target=next(e for e in entities if e['name']==spec['target_type'])
 if c.resolve(target['update_schema']['properties']['title']).get('type')!='string':raise ValueError('Negative type rules require contract string field')
 spec['negative_field_pointer']='#/definitions/models.Label/properties/title'
 spec['negative_field_type']='string'
 cases=[]
 subjects={'task':spec['child_type']+'_1','other_task':spec['child_type']+'_2','label':spec['target_type']+'_1','second_label':spec['target_type']+'_2'}
 def step(task,other,label,present,own,other_ids,**kw):return dict(task=task,other_task=other,label=label,present=present,expected_labels=own,other_labels=other_ids,**kw)
 t,o,l,m=[subjects[k] for k in ('task','other_task','label','second_label')]
 for active,passive in ((l,m),(m,l)):
  prefix=[step(t,o,active,True,[active],[]),step(o,t,active,True,[active],[active]),step(t,o,passive,True,[active,passive],[active]),step(o,t,passive,True,[active,passive],[active,passive])]
  detach=step(t,o,active,False,[passive],[active,passive])
  attach=step(t,o,active,True,[active,passive],[active,passive])
  def update(detached):return step(t,o,active,not detached,[passive] if detached else [active,passive],[active,passive],action='update_target',update={'description':'sbt-v050-order-comparison'})
  for order,tail in [('before',[update(False),detach,attach]),('during',[detach,update(True),attach]),('after',[detach,attach,update(False)])]:
   cases.append(dict(case_id='order-'+('first-label' if active==l else 'second-label')+'-'+order,subjects=subjects,steps=prefix+tail,comparison_group=active,order=order,negative_target=active,negative_cases=[dict(rule_id='STRING_TYPE_ARRAY',field='title',value=[]),dict(rule_id='STRING_TYPE_NUMBER',field='title',value=123)],expected_checks=117))

 return {'version':'v050','contract_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'family':'relation','relation_spec':spec,'items':cases,'ordered_history':True,'authenticated_clients':2,'same_user':True,'true_concurrency':False,'mutation_steps_per_case':7,'prefix_depth_parameter':False,'oracle_policy':'Membership effects and unrelated-resource preservation are research hypotheses supported by operation descriptions; inference conventions are recorded','deferred':['Task movement between projects','Project task-list view requires a view identifier and pagination handling','Authorization, concurrency and varied prefix depths'],'full_system_coverage':False}

def generate(run,case,proxy,resources=None):
 run=run.resolve()
 plan=dict(version='v050',family='relation',mode='resume' if resources is not None else 'bootstrap',relation_spec=catalog()['relation_spec'],case_id=case['case_id'],subjects=case['subjects'],resources=resources or [],relations=[],seed=1,steps=case['steps'],expected_checks=case['expected_checks'],comparison_group=case['comparison_group'],order=case['order'],negative_target=case['negative_target'],negative_cases=case['negative_cases'],final_memberships={case['subjects']['task']:[case['subjects']['label'],case['subjects']['second_label']],case['subjects']['other_task']:[case['subjects']['label'],case['subjects']['second_label']]})
 run.mkdir(parents=True,exist_ok=True);(run/'checkpoint-plan-v050.json').write_text(json.dumps(plan,indent=2))
 cmd=[sys.executable,'-m','generator_v56','context-generate','--openapi',str(ROOT/'engine-v010/vikunja-live-swagger.json'),'--output',str(run/'project/spec/js'),'--name','vikunja','--base-url',proxy,'--instances-per-entity','2','--seed','1','--negative-schema','--method-adapter',str(ROOT/'engine-v010/method_adapter_v010.json'),'--checkpoint-plan',str(run/'checkpoint-plan-v050.json')]
 for path in ('/projects','/projects/{id}/tasks','/labels'):cmd+=['--resource',path]
 proc=subprocess.run(cmd,cwd=ROOT/'engine-v010/source',capture_output=True,text=True,timeout=60);(run/'generation.log').write_text(proc.stdout+proc.stderr)
 if proc.returncode:raise RuntimeError('Generator failed; inspect generation.log')
 return run/'project'
if __name__=='__main__':
 out=Path(sys.argv[1]).resolve();generate(out,catalog()['items'][0],'http://127.0.0.1:3456/api/v1');(out/'relation-catalog-v050.json').write_text(json.dumps(catalog(),indent=2));print('V050_GENERATED_NOT_NATIVE_EXECUTED',out)
