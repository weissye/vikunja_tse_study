const fs=require('fs'),vm=require('vm'),events=[];
const c={RESTSession:function(url,name,options){this.baseURL=url;this.defaultHeaders=options.headers;},bp:{Event:(name,data)=>({name,data}),EventSet:function(){}},sync:x=>events.push(x.request)};
vm.createContext(c);vm.runInContext(fs.readFileSync(process.argv[2],'utf8'),c);
for(const actor of ['A','B']){c.RELATION_ACTOR=actor;c.requestRest('GET','/labels/124',undefined,[200],{action:'independent_read'},function(){});}
for(let i=0;i<2;i++){const actor=i?'B':'A';if(!events[i].data.url.endsWith('/__actor/'+actor+'/labels/124')||events[i].data.model.actor!==actor)throw Error('Client route/metadata mismatch');}
const story=fs.readFileSync(process.argv[3],'utf8');if(!story.includes("stepIndex%2===0?'A':'B'"))throw Error('Alternating writers missing');
console.log('V050_CLIENT_ROUTING_FIXTURE_PASS: two explicit actor routes, alternating generated writers. Not native/live.');
