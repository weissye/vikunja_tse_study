import sys,json,tempfile
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile
import run_relations_v051 as launcher
import parent_v051
root=Path(__file__).resolve().parent
with ZipFile(root/'accepted-review-v050.zip') as z:capsule=json.loads(z.read('checkpoint-model-v050.json'))
with tempfile.TemporaryDirectory() as d:
 work=Path(d);parent=work/'parent';parent.mkdir();(parent/'review_v031.zip').write_bytes(b'fixture')
 with patch.object(parent_v051,'load_parent',return_value={'provenance':{'fixture_only':True},'capsule':capsule}),patch.object(sys,'argv',['test','--study-root',str(work),'--jar',str(work/'unused.jar'),'--resume-from',str(parent)]):assert launcher.main()==0
 run=next((work/'runs').iterdir());assert len(list(run.glob('static-case-*')))==4
 assert json.loads((run/'result_v051.json').read_text())['live_execution'] is False
print('V051_STATIC_LAUNCHER_FIXTURE_PASS: four original-generator shared-task programs, no live execution')
