param(
 [switch]$RunLive,
 [switch]$CreateSecondUser,
 [string]$SecondUsername='SBT-peer-v051',
 [string]$StudyRoot='C:\work\temp\work-v011-20261011-062659\v',
 [string]$ProvengoJar='C:\work\temp\vikunja_tse_study\Provengo-2026-01-10.uber.jar',
 [string]$ResumeFrom='C:\work\temp\work-v011-20261011-062659\v\runs\relation-v031-20261011-084313-187193'
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_RELATION_CONTINUATION v053'
& python (Join-Path $PSScriptRoot 'Verify-v053.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
$arguments=@((Join-Path $PSScriptRoot 'run_relations_v053.py'),'--study-root',$StudyRoot,'--jar',$ProvengoJar,'--resume-from',$ResumeFrom)
if ($RunLive) {$arguments+='--live';$arguments+=@('--second-username',$SecondUsername);if ($CreateSecondUser) {$arguments+='--create-second-user'}}
& python @arguments
if ($LASTEXITCODE -ne 0) {throw 'Acceptance incomplete. Preserve the printed review ZIP and private snapshots.'}
