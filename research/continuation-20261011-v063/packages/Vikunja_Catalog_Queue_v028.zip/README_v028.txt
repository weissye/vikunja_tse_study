V028: resume the existing local schema-validation queue at check 140.
Pinned parent manifest: ad016221f38d90e7c9133b76a48654f136bce31e4bc868f52506b343e5bc17fa.
139 historical outcomes remain unchanged; 51 checks remain. Original 122-file generator/verifier package and v023 storage adapter unchanged.
Run without -RunLive first to verify evidence and private snapshot. Run with -RunLive to continue.
Before restoration: validate parent hashes, chained journal, completed queue prefix, private content and exact metadata, live contract, JAR, image and exclusive storage identity.
Save current server storage to before-resume; restore original checkpoint; verify API baseline. No bootstrap, creation or prefix replay. Reconstruct Context and bindings at each explicit quiescent checkpoint; does not restore Java stacks.
Refresh login before every remaining test. Authentication failure stops safely; mutations are never retried. Preserve all checks and findings; restore and verify baseline after failure.
Passwords and actual auth tokens stay in memory. Private storage backups stay local, excluded from review ZIP. Parent review ZIP is included as historical evidence.
Scope: selected schema rules for six own-created labels/projects/teams. Does not add permission tests or expand coverage.
Validation: supervisor fixtures for fresh FAIL/PASS/FAIL and continuation from saved first outcome; no bootstrap on resume, preserved finding, refreshed auth and queue completed. Original package byte integrity verified. Live acceptance remains to be run on user's Windows host.
