"""Resume the bounded v027 schema-validation queue; unchanged generator/verifiers."""
import argparse,json,sys,hashlib,getpass,uuid,os,shutil
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_work_v023 as storage
import queue_engine_v028 as engine

def load_parent(parent):
 def read(name):return json.loads((parent/name).read_text(encoding='utf-8'))
 if storage.sha(parent/'manifest_v027.json')!='ad016221f38d90e7c9133b76a48654f136bce31e4bc868f52506b343e5bc17fa':raise ValueError('Expected accepted v027 manifest differs')
 manifest=read('manifest_v027.json')
 for name,expected in manifest.items():
  relative=PurePosixPath(name.replace('\\','/'))
  if relative.is_absolute() or '..' in relative.parts or ':' in name:raise ValueError('Unsafe manifest path')
  path=parent.joinpath(*relative.parts)
  if path.is_symlink() or storage.sha(path)!=expected:raise ValueError('Parent evidence mismatch: '+name)
 queue=read('queue_v027.json');outcomes=read('outcomes_v027.json');progress=read('queue-progress-v027.json')
 ids=[x['queue_id'] for x in queue['items']];done=[x['queue_id'] for x in outcomes];n=len(done)
 if n!=139 or len(ids)!=190:raise ValueError('Expected 139 completed out of 190')
 if len(set(ids))!=len(ids) or not 0<n<len(ids) or done!=ids[:n]:raise ValueError('Queue prefix mismatch')
 if progress!=dict(completed_queue_ids=done,remaining_queue_ids=ids[n:],next_index=n,same_baseline_verified=True):raise ValueError('Progress mismatch')
 journal=[json.loads(line) for line in (parent/'campaign-journal.jsonl').read_text().splitlines()]
 previous=None
 for index,event in enumerate(journal):
  unsigned={k:v for k,v in event.items() if k!='sha256'}
  if event['index']!=index or event['previous']!=previous or engine.digest(unsigned)!=event['sha256']:raise ValueError('Journal chain mismatch')
  previous=event['sha256']
 checks=[e for e in journal if e['status'] in ('RULE_PASSED','RULE_FAILED')]
 if len(checks)!=n:raise ValueError('Outcome/journal count mismatch')
 for outcome,event,item in zip(outcomes,checks,queue['items']):
  if outcome['queue_id']!=item['queue_id'] or outcome['rule_id']!=item['rule_id'] or outcome['logical_id']!=item['logical_id'] or event['data']['queue_id']!=outcome['queue_id'] or event['data']['check_sha256']!=engine.digest(outcome['check']):raise ValueError('Outcome evidence mismatch')
 baselines=[e for e in journal if e['status']=='BASELINE_VERIFIED']
 if len(baselines)!=n or baselines[-1]['data']['queue_id']!=done[-1]:raise ValueError('Last completed baseline not verified')
 capsule=read('checkpoint-model.json');observations=read('checkpoint-observations.json')
 saves=[e for e in journal if e['status']=='CHECKPOINT_SAVED']
 if len(saves)!=1:raise ValueError('Ambiguous checkpoint')
 data=saves[0]['data']
 if engine.digest(capsule)!=data['model_sha256'] or engine.digest(observations)!=data['observations_sha256']:raise ValueError('Checkpoint evidence mismatch')
 folder=parent/'.private-snapshots'/'checkpoint';hashes=data['snapshot_hashes']
 actual={p.relative_to(folder).as_posix():storage.sha(p) for p in folder.rglob('*') if p.is_file()}
 if actual!=hashes:raise ValueError('Private checkpoint missing or altered; do not resume from review ZIP')
 trees=read('.private-snapshots/checkpoint/trees.json')
 for key in ('db','files'):
  if storage.tree(folder/key)!=trees[key]:raise ValueError('Private checkpoint metadata mismatch')
 return queue,dict(capsule=capsule,observations=observations,snapshot={'folder':str(folder),'hashes':hashes},outcomes=outcomes,provenance={'parent_directory':str(parent),'parent_manifest_sha256':storage.sha(parent/'manifest_v027.json'),'parent_journal_tip':previous,'next_index':n,'next_queue_id':ids[n]},adapter=read('snapshot-adapter.json'))

def main():
 p=argparse.ArgumentParser();p.add_argument('--study-root',required=True,type=Path);p.add_argument('--jar',required=True,type=Path);p.add_argument('--resume-from',required=True,type=Path);p.add_argument('--live',action='store_true');a=p.parse_args()
 run=a.study_root/'runs'/('catalog-queue-v028-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True)
 try:
  queue,recovery=load_parent(a.resume_from.resolve())
  engine.write(run/'queue_v028.json',queue);engine.write(run/'parent-provenance.json',recovery['provenance'])
  shutil.copy2(a.resume_from/'review_v027.zip',run/'parent-review-v027.zip')
  print('Verified completed checks:',len(recovery['outcomes']),flush=True);print('Next check:',len(recovery['outcomes'])+1,flush=True)
  if not a.live:
   result={'version':'v028','status':'V028_RESUME_INPUT_VERIFIED','live_execution':False};engine.pack_review(run,result,[])
  else:
   if os.name!='nt':raise ValueError('Work adapter requires Windows')
   if storage.sha(a.jar)!='dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b':raise ValueError('JAR mismatch')
   target='http://127.0.0.1:3456/api/v1';status,contract=engine.request(target+'/docs.json')
   if status!=200 or hashlib.sha256(contract).hexdigest()!=storage.sha(ROOT/'engine-v010'/'vikunja-live-swagger.json'):raise ValueError('Live contract mismatch')
   backend=storage.BindBackend('vikunja-research-sut',target,run)
   current=json.loads((run/'snapshot-adapter.json').read_text())
   if current!=recovery['adapter']:raise ValueError('Server image/storage identity differs from parent')
   password=getpass.getpass('Vikunja password for SBT-tester: ')
   def login():return engine.json_request(target+'/login',method='POST',body={'username':'SBT-tester','password':password})['token']
   backend.refresh_token=login;backend.token=login()
   result=engine.run_campaign(run,a.jar,target,uuid.uuid4().hex,backend,seed=1,recovery=recovery)
 except Exception as e:
  result={'version':'v028','status':'NOT_ACCEPTED','error':str(e)};engine.pack_review(run,result,[])
 print('Status:',result['status']);print('Review ZIP:',run/'review_v028.zip')
 if result.get('error'):print('Error:',result['error'])
 return 0 if result['status'] in ('V028_RESUME_INPUT_VERIFIED','CATALOG_QUEUE_V028_COMPLETED') else 1
if __name__=='__main__':raise SystemExit(main())
