VIKUNJA CONTEXT RELATIONS v037
Original generator retained: Stories, Interfaces, DAL, Context and independent verifiers.
Scope: two shared-label deletion cases on the same six original v031 resources.
31 checks per case, 62 total. Direct GET 403 remains ABSENCE_UNDETERMINED.
NEW: generated JS requests independent collection observations before and after deletion.
The Python HTTP adapter reads /labels?page=N&per_page=50 through explicit empty page.
Every underlying page request/response is recorded in http-evidence.json. No search filter.
Short pages never imply completion. Duplicate IDs, malformed pages, non-200 responses,
or 1000-page cap produce COLLECTION_UNDETERMINED. No automatic mutation retries.
Before deletion both target and survivor must be visible. After deletion target must
be absent and survivor visible. This is USER-VISIBLE absence only, not physical/global deletion.
Collection completeness assumes stable local state while paging; concurrent writers are excluded.
Scope selection, deletion lifecycle and preservation hypotheses are explicit method inputs;
not a claim of automatic inference of business rules solely from OpenAPI.
Each case restores/verifies original cold checkpoint, preserving IDs and prefix.
Live acceptance is NOT performed by package development tests. Upload review_v037.zip after running.
Historical engine-v010 launchers/manifests are retained as provenance; use only top v037 launcher.
