import json,tempfile,zipfile
from pathlib import Path
from resume_proof_v047 import verify_first,ROOT
import relation_engine_v047 as engine
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp)
 with zipfile.ZipFile(ROOT/'V039_Recovery_v046.zip') as z:
  for name in json.loads(z.read('RECOVERY_MANIFEST_v046.json')):
   p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 assert verify_first(root)['verified_checks']==54
 (root/'case-1/checks.json').write_text('[]')
 try:verify_first(root);raise AssertionError('Corrupt proof accepted')
 except ValueError:pass
 p=root/'atomic.json';engine.write(p,{'old':True})
 try:engine.write(p,{'bad':object()})
 except TypeError:pass
 assert json.loads(p.read_text())=={'old':True}
 engine.persist_http(root,{'index':0,'status':200})
 assert json.loads((root/'http-evidence-durable.jsonl').read_text())['status']==200
 print('V047_RECOVERY_AND_ATOMIC_EVIDENCE_FIXTURE_PASS; not native/live')
