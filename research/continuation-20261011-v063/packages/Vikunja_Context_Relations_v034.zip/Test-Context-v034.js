const fs=require('fs'),vm=require('vm');
const entities={},effects={},queries={};
const ctx={Entity:(id,type,data)=>{if('id' in data||'type' in data)throw Error('Reserved Context fields');return {...data,id,type};},insertEntity:e=>entities[e.id]=e,removeEntity:id=>delete entities[id],registerEffect:(n,f)=>effects[n]=f,registerQuery:(n,f)=>queries[n]=f,runQuery:n=>Object.values(entities).filter(queries[n]),populateContext:()=>{}};
const sandbox={ctx,bp:{EventSet:function(){}},bthread:()=>{},waitFor:()=>{},request:()=>{}};vm.createContext(sandbox);vm.runInContext(fs.readFileSync(process.argv[2],'utf8'),sandbox);
entities.ModelsLabel_1=ctx.Entity('ModelsLabel_1','resource',{resourceType:'ModelsLabel',expected:{title:'baseline',description:'old'},revision:2,verifiedRevision:2});
const data={id:'case',task:'ModelsTask_1',other_task:'ModelsTask_2',label:'ModelsLabel_1',expected_labels:['ModelsLabel_1'],other_labels:[],present:true};
effects.RelationWriteCompleted(data);if(ctx.runQuery('Relation.Pending').length!==1)throw Error('No pending verifier');effects.RelationVerified({id:'case'});if(ctx.runQuery('Relation.Pending').length)throw Error('Verifier did not finish');
effects.RelationWriteCompleted({...data,action:'update_target',update:{description:'new'}});if(entities.ModelsLabel_1.expected.description!=='new')throw Error('Expected state update lost');effects.RelationVerified({id:'case'});
console.log('V034_GENERATED_DAL_FIXTURE_PASS: reserved fields excluded at both effects; relation data preserved; update expected state retained. Not native Provengo.');
