"""Contract-derived relation inference and Context Stories/Interfaces/DAL renderer."""
import json,re

def infer_relations(c,entities):
 children=[e for e in entities if len(e.get('path_dependencies',[]))==1]
 candidates=[]
 for child in children:
  foreign=child['path_dependencies'][0].get('foreign_field')
  if not foreign:continue
  for path,ops in c.raw['paths'].items():
   if 'get' not in ops or 'put' not in ops:continue
   prefix=child['detail'].rsplit('/',1)[0]
   if not path.startswith(prefix+'/{') or len(re.findall(r'\{[^}]+\}',path))!=1:continue
   _,response=c.response(ops['get'])
   if response.get('type')!='array':continue
   item=c.resolve(response.get('items',{}))
   targets=[e for e in entities if e['read_schema']==item and e is not child]
   if len(targets)!=1:continue
   target=targets[0];fields=c.body(ops['put']).get('properties',{})
   token=target['path'].rsplit('/',1)[-1].rstrip('s')
   ids=[f for f in fields if f==token+'_id' and c.resolve(fields[f]).get('type')=='integer']
   if len(ids)!=1:continue
   deletions=[p for p,op in c.raw['paths'].items() if p.startswith(path+'/{') and p.endswith('}') and 'delete' in op]
   if len(deletions)!=1:continue
   remove=deletions[0];param=re.findall(r'\{([^}]+)\}',path)[0];labelparam=re.findall(r'\{([^}]+)\}',remove)[-1]
   candidates.append(dict(child_type=child['name'],target_type=target['name'],parent_type=child['path_dependencies'][0]['target'],parent_field=foreign,collection=path,remove=remove,child_parameter=param,target_parameter=labelparam,body_field=ids[0],attach_method='PUT',detach_method='DELETE',attach_codes=c.response(ops['put'])[0],detach_codes=c.response(c.raw['paths'][remove]['delete'])[0],read_codes=c.response(ops['get'])[0],source_pointers=['#/paths/'+p.replace('~','~0').replace('/','~1')+'/'+m for p,m in [(path,'get'),(path,'put'),(remove,'delete')]],authority='Exact response schema + path structure + conventional foreign key; membership/preservation are explicit research hypotheses',description={'attach':ops['put'].get('description',''),'detach':c.raw['paths'][remove]['delete'].get('description','')}))
 if len(candidates)!=1:raise ValueError('Relation inference must resolve one unambiguous selected relation')
 return candidates[0]

def render_relations(entities,instances,plan):
 j=lambda x:json.dumps(x,separators=(',',':'))
 spec=plan['relation_spec'];child=next(e for e in entities if e['name']==spec['child_type']);target=next(e for e in entities if e['name']==spec['target_type'])
 count=len(entities)*instances
 if target['update_schema'].get('properties',{}).get('description',{}).get('type')!='string':raise ValueError('Target description update must be contract-supported string')
 spec=dict(spec,target_update_method=target['update_method'].upper(),target_update_codes=[int(k) for k in target['update'].get('responses',{}) if k.isdigit() and 200<=int(k)<300])
 subjects=plan['subjects']
 valid={e['name']+'_'+str(i) for e in entities for i in range(1,instances+1)}
 if any(s not in valid for s in subjects.values()):raise ValueError('Unknown relation subject')
 if plan['mode'] not in ('bootstrap','resume'):raise ValueError('Unknown relation phase')
 iface=r'''
function relationKey(id){return id.replace(/[^A-Za-z0-9_]/g,'_');}
function relationRoute(template,param,logical){return template.replace('{'+param+'}','@{ROUTE_'+relationKey(logical)+'}');}
function relationCheck(name,path,expected,kind,successCodes){
 var source="var wanted="+JSON.stringify(expected)+";function resolve(v){if(typeof v==='string'&&/^@\\{[A-Za-z0-9_]+\\}$/.test(v))return pvg.rtv.get(v.slice(2,-1));if(Array.isArray(v))return v.map(resolve);if(v&&typeof v==='object'){var o={};Object.keys(v).forEach(function(k){o[k]=resolve(v[k]);});return o;}return v;}wanted=resolve(wanted);var actual;try{actual=JSON.parse(response.body);}catch(e){actual=null;}var passed=Number(response.code)===200;";
 if(kind==='membership')source+="var ids=Array.isArray(actual)?actual.map(function(x){return String(x.id);}).sort():null;passed=passed&&JSON.stringify(ids)===JSON.stringify(wanted.map(String).sort());";
 else if(kind==='write')source+="passed="+JSON.stringify(successCodes)+".indexOf(Number(response.code))>=0;";
 else source+="passed=passed&&actual&&Object.keys(wanted).every(function(k){return actual[k]===wanted[k];});";
 source+="bp.log.info('RELATION_CHECK '+JSON.stringify({name:"+JSON.stringify(name)+",kind:"+JSON.stringify(kind)+",status:Number(response.code),expected:wanted,observed:actual,pass:!!passed}));if(!passed)pvg.fail('Relation semantic check failed: '+"+JSON.stringify(name)+");";
 return callbackFromSource(source);
}
function relationMutation(pending){
 var s=RELATION_SPEC,task=pending.task,label=pending.label;
 if(pending.action==='update_target'){var targetPath=relationRoute(TARGET_DETAIL,TARGET_PARAMETER,label);var updateBody=JSON.parse(JSON.stringify(getModelEntity(label).expected));Object.keys(pending.update).forEach(function(k){updateBody[k]=pending.update[k];});return requestRest(s.target_update_method,targetPath,updateBody,ALL_CODES,{action:'relation_target_update',logicalId:label},relationCheck(pending.id+'/write',targetPath,{},'write',s.target_update_codes));}
 var path=relationRoute(pending.present?s.collection:s.remove,s.child_parameter,task);
 if(!pending.present)path=relationRoute(path,s.target_parameter,label);
 var body;if(pending.present){body={};body[s.body_field]='@{ID_'+relationKey(label)+'}';}
 var codes=pending.present?s.attach_codes:s.detach_codes;
 return requestRest(pending.present?s.attach_method:s.detach_method,path,body,ALL_CODES,{action:'relation_write',logicalId:task},relationCheck(pending.id+'/write',path,{},'write',codes));
}
function verifyRelation(pending){
 var s=RELATION_SPEC;
 var task=getModelEntity(pending.task),label=getModelEntity(pending.label);
 var ids=pending.expected_labels.map(function(id){return '@{ID_'+relationKey(id)+'}';});
 var path=relationRoute(s.collection,s.child_parameter,pending.task);
 requestRest('GET',path,undefined,ALL_CODES,{action:'relation_read',logicalId:pending.task},relationCheck(pending.id+'/membership',path,ids,'membership'));
 requestRest('GET',relationRoute(TASK_DETAIL,TASK_PARAMETER,pending.task),undefined,ALL_CODES,{action:'relation_read',logicalId:pending.task},relationCheck(pending.id+'/task-preservation','',task.expected,'projection'));
 var otherIds=pending.other_labels.map(function(id){return '@{ID_'+relationKey(id)+'}';});
 var otherPath=relationRoute(s.collection,s.child_parameter,pending.other_task);
 requestRest('GET',otherPath,undefined,ALL_CODES,{action:'relation_read',logicalId:pending.other_task},relationCheck(pending.id+'/other-membership',otherPath,otherIds,'membership'));
 requestRest('GET',relationRoute(TARGET_DETAIL,TARGET_PARAMETER,pending.label),undefined,ALL_CODES,{action:'relation_read',logicalId:pending.label},relationCheck(pending.id+'/target-exists','',label.expected,'projection'));
 if(pending.action==='update_target'){
 var expectedLabel=label.expected;
 var callback=callbackFromSource("var actual=JSON.parse(response.body),expected="+JSON.stringify(expectedLabel)+";var hit=Array.isArray(actual)?actual.filter(function(x){return x.id===Number(pvg.rtv.get("+JSON.stringify('ID_'+relationKey(pending.label))+"));})[0]:null;var passed=Number(response.code)===200&&!!hit&&Object.keys(expected).every(function(k){return hit[k]===expected[k];});bp.log.info('RELATION_CHECK '+JSON.stringify({name:"+JSON.stringify(pending.id+'/embedded-label')+",kind:'embedded_projection',status:Number(response.code),expected:expected,observed:hit,pass:!!passed}));if(!passed)pvg.fail('Shared label update not visible through task');");
 requestRest('GET',path,undefined,ALL_CODES,{action:'relation_read',logicalId:pending.task},callback);
 requestRest('GET',otherPath,undefined,ALL_CODES,{action:'relation_read',logicalId:pending.other_task},callback);
 }
}
function relationCheckpointExport(resources){
 var body={resources:resources,cursor:RELATION_PLAN,relations:[]};
 var source="var body="+JSON.stringify(body)+";body.bindings={};body.resources.forEach(function(r){var key=r.logicalId.replace(/[^A-Za-z0-9_]/g,'_');['ID_','ROUTE_','SNAPSHOT_'].forEach(function(prefix){var name=prefix+key;var v=pvg.rtv.get(name);if(v===undefined||v===null)pvg.fail('Missing checkpoint binding');body.bindings[name]=v;});});pvg.rtv.set('RELATION_EXPORT',JSON.stringify(body));";
 requestRest('GET','/__checkpoint/ping',undefined,[200],{action:'checkpoint_prepare'},callbackFromSource(source));
 requestRest('POST','/__checkpoint/save','@{RELATION_EXPORT}',[200],{action:'checkpoint_save'},callbackFromSource("bp.log.info('RELATION_CHECKPOINT_SAVED');"));
}
function relationRestoreBindings(){requestRest('GET','/__checkpoint/resume',undefined,[200],{action:'checkpoint_restore'},callbackFromSource("var c=JSON.parse(response.body);Object.keys(c.bindings).forEach(function(k){pvg.rtv.set(k,c.bindings[k]);});"));}
'''.replace('RELATION_SPEC',j(spec)).replace('RELATION_PLAN',j(plan)).replace('TASK_DETAIL',j(child['detail'])).replace('TASK_PARAMETER',j(child['parameter'])).replace('TARGET_DETAIL',j(target['detail'])).replace('TARGET_PARAMETER',j(target['parameter'])).replace('ALL_CODES',j(list(range(200,600))))
 dal=r'''
ctx.registerEffect('RelationWriteCompleted',function(data){
 if(ctx.runQuery('Relation.All').some(function(x){return x.id===data.id;}))ctx.removeEntity(data.id);
 if(data.action==='update_target'){var r=getModelEntity(data.label);var expected=JSON.parse(JSON.stringify(r.expected));Object.keys(data.update).forEach(function(k){expected[k]=data.update[k];});ctx.removeEntity(r.id);ctx.insertEntity(ctx.Entity(r.id,'resource',{resourceType:r.resourceType,expected:expected,revision:r.revision,verifiedRevision:r.verifiedRevision}));}
 var state=JSON.parse(JSON.stringify(data));delete state.id;delete state.type;state.pending=true;ctx.insertEntity(ctx.Entity(data.id,'relation',state));
});
ctx.registerQuery('Relation.All',function(e){return e.type==='relation';});
ctx.registerQuery('Relation.Pending',function(e){return e.type==='relation'&&e.pending;});
ctx.registerEffect('RelationVerified',function(data){var x=ctx.runQuery('Relation.All').filter(function(r){return r.id===data.id;})[0];ctx.removeEntity(x.id);var state=JSON.parse(JSON.stringify(x));delete state.id;delete state.type;state.pending=false;ctx.insertEntity(ctx.Entity(x.id,'relation',state));});
ctx.registerEffect('RelationRestoreContext',function(data){data.resources.forEach(function(r){ctx.insertEntity(ctx.Entity(r.logicalId,'resource',{resourceType:r.resourceType,expected:r.expected,revision:r.revision,verifiedRevision:0}));});data.relations.forEach(function(r){ctx.insertEntity(ctx.Entity(r.id,'relation',r));});});
'''
 stories=r'''
ctx.bthread('independent relation verifier','Relation.Pending',function(pending){verifyRelation(pending);request(bp.Event('RelationVerified',{id:pending.id}));});
'''
 if plan['mode']=='resume':
  if len(plan.get('resources',[]))!=count:raise ValueError('Incomplete relation checkpoint model')
  stories+='bthread("restore relation Context",function(){relationRestoreBindings();request(bp.Event("RelationRestoreContext",'+j({'resources':plan['resources'],'relations':plan.get('relations',[])})+'));});\n'
 stories+=r'''
bthread('relation lifecycle coordinator',function(){
 var all;
 while(true){all=ctx.runQuery('Resource.All');if(all.length===COUNT&&all.every(function(r){return r.revision===2&&r.verifiedRevision===2;})&&ctx.runQuery('WriteLock.All').length===0&&ctx.runQuery('Negative.Pending').length===0)break;waitFor(bp.all);}
 var routes=ROUTES;
 var resources=all.map(function(r){return {logicalId:r.id,resourceType:r.resourceType,expected:r.expected,revision:r.revision,verifiedRevision:r.verifiedRevision,detail_template:routes[r.resourceType].path,route_parameter:routes[r.resourceType].parameter};}).sort(function(a,b){return a.logicalId<b.logicalId?-1:1;});
 bp.log.info('RELATION_CONTEXT '+JSON.stringify(resources));
 CHECKPOINT
 var steps=PLAN_STEPS;
 for(var stepIndex=0;stepIndex<steps.length;stepIndex++){var step=steps[stepIndex];var data=JSON.parse(JSON.stringify(step));data.id=CASE_ID;relationMutation(data);request(bp.Event('RelationWriteCompleted',data));waitFor(bp.EventSet('relation step verified',function(e){return e.name==='RelationVerified'&&e.data.id===CASE_ID;}));}

 bp.log.info('RELATION_CASE_COMPLETED '+CASE_ID);
});
'''.replace('PLAN_STEPS',j(plan['steps'])).replace('COUNT',str(count)).replace('ROUTES',j({e['name']:{'path':e['detail'],'parameter':e['parameter']} for e in entities})).replace('CHECKPOINT',"relationCheckpointExport(resources);" if plan['mode']=='bootstrap' else "requestRest('GET','/__checkpoint/verify',undefined,[200],{action:'checkpoint_gate'},callbackFromSource(\"bp.log.info('RELATION_GATE_VERIFIED');\"));").replace('CASE_ID',j(plan['case_id'])).replace('SUBJECTS',j(subjects))
 return iface,dal,stories
