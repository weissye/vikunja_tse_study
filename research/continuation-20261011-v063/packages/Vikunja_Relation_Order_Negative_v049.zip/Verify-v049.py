import json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent;m=json.loads((r/'MANIFEST_v049.json').read_text())
for name,h in m.items():
 if hashlib.sha256((r/name).read_bytes()).hexdigest()!=h:raise SystemExit('Mismatch: '+name)
print('V049_INTEGRITY_PASS',len(m))
