VIKUNJA RELATION ORDER AND NEGATIVE ACCEPTANCE v049
Static generation and local mocked-interface tests completed. Native/live execution has NOT been performed here.
Original generator: engine-v010/source/generator_v56. Edit renderer, never generated JS.
Six cases: two selected labels, each with update before/during/after detach and reattach.
Prefix: four owned-resource relation attachments. Tail: three mutations. Readbacks do not count as prefix mutations. No parameterized depth, no concurrency, no multi-user coverage.
Each complete case: 37 positive per-operation checks, 8 final-state reads, 2 negative input checks plus 16 independent unchanged-state reads = 63 checks. Total 378 if all complete.
Negative values [] and 123 are derived for the selected contract string field title. This is not full schema-negative coverage. Field source pointer recorded in each negative marker.
Compare canonical observed projections and sorted membership identifiers before invalid inputs. Volatile timestamps outside expected projections excluded; do not claim whole database equivalence.
Only original v031 checkpoint is restored, using the existing six resources. No new resource creation. Parent private checkpoint must remain locally available. Each case independently restores and verifies baseline. A semantic failure is retained, restored and the next case attempted. Infrastructure failure stops with evidence retained.
401/403/429 during a negative request are unresolved, not proof of valid schema rejection. Response-code documentation deviations are reported independently.
HTTP evidence is appended and flushed before returning each response. Atomic summary writes avoid overwriting a valid file with a partial write. Private snapshots excluded from review ZIP. 512 MB disk guard before cases/restores, 128 MB before proxied requests.
Method adapter: live label update POST vs documented PUT, checked by OPTIONS before authentication.
Use Run-Relations-v049.ps1 first without -RunLive, then with -RunLive. Defaults match the work environment. Do not modify or delete the v031 run.
Generated-resume/case-1..6/project/spec/js includes every generated Stories, Interfaces, DAL and verifier code. Engine preserves original Context architecture.
Previous accepted v048 review is included as evidence, not as this version live acceptance.
