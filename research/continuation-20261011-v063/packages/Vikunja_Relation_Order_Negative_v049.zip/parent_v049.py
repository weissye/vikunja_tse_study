import json,re
from pathlib import Path,PurePosixPath
import run_work_v023 as storage
import relation_engine_v049 as engine

def load_parent(parent):
 def read(name):return json.loads((parent/name).read_text(encoding='utf-8'))
 if storage.sha(parent/'manifest_v031.json')!='3a0911f68c6420b1547a339e8ee2229a0875e56349df91f23c8183a04612390f':raise ValueError('Expected v031 parent manifest differs')
 for name,h in read('manifest_v031.json').items():
  path=PurePosixPath(name.replace('\\','/'))
  if path.is_absolute() or '..' in path.parts or ':' in name:raise ValueError('Unsafe manifest path')
  if storage.sha(parent.joinpath(*path.parts))!=h:raise ValueError('Parent evidence mismatch: '+name)
 journal=[json.loads(l) for l in (parent/'campaign-journal.jsonl').read_text().splitlines()];previous=None
 for i,e in enumerate(journal):
  if e['index']!=i or e['previous']!=previous or e['sha256']!=engine.digest({k:v for k,v in e.items() if k!='sha256'}):raise ValueError('Journal mismatch')
  previous=e['sha256']
 saves=[e for e in journal if e['status']=='CHECKPOINT_SAVED']
 if len(saves)!=1:raise ValueError('Expected one original checkpoint')
 data=saves[0]['data'];capsule=read('checkpoint-model-v031.json');baseline=read('checkpoint-observations-v031.json')
 if engine.digest(capsule)!=data['model_sha256'] or engine.digest(baseline)!=data['observations_sha256']:raise ValueError('Checkpoint model/baseline mismatch')
 if len(capsule['resources'])!=6 or any(baseline['memberships'].values()):raise ValueError('Expected original six resources with empty relations')
 http=read('http-evidence.json')
 if any('/labels' in r['path'] and '/tasks/' in r['path'] and r['method']!='GET' for r in http):raise ValueError('Parent contains relation mutations; cannot assume zero completed cases')
 folder=parent/'.private-snapshots/relation-checkpoint'
 if {p.relative_to(folder).as_posix():storage.sha(p) for p in folder.rglob('*') if p.is_file()}!=data['snapshot_hashes']:raise ValueError('Private checkpoint missing or altered; use original run directory')
 metadata=json.loads((folder/'trees.json').read_text())
 for key in ('db','files'):
  if storage.tree(folder/key)!=metadata[key]:raise ValueError('Private checkpoint metadata mismatch')
 return dict(capsule=capsule,baseline=baseline,snapshot={'folder':str(folder),'hashes':data['snapshot_hashes']},adapter=read('snapshot-adapter.json'),provenance={'parent_directory':str(parent),'manifest_sha256':storage.sha(parent/'manifest_v031.json'),'journal_tip':previous,'completed_relation_cases':0,'same_resource_ids':True})
