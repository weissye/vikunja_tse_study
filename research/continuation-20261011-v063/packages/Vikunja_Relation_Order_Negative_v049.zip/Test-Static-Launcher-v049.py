"""Offline launch fixture: verifies six generated cases, not native or live."""
import json,sys,tempfile,zipfile
from pathlib import Path
from unittest.mock import patch
import run_relations_v049 as launcher
import parent_v049
ROOT=Path(__file__).resolve().parent
with zipfile.ZipFile(ROOT/'accepted-review-v048.zip') as z:
 capsule=json.loads(z.read('checkpoint-model-v048.json'))
with tempfile.TemporaryDirectory() as d:
 root=Path(d);parent=root/'parent';parent.mkdir();(parent/'review_v031.zip').write_bytes(b'fixture-only')
 recovery={'provenance':{'fixture_only':True},'capsule':capsule}
 with patch.object(parent_v049,'load_parent',return_value=recovery),patch.object(sys,'argv',['test','--study-root',str(root),'--jar',str(root/'unused.jar'),'--resume-from',str(parent)]):
  assert launcher.main()==0
 run=next((root/'runs').iterdir())
 assert len(list(run.glob('static-case-*')))==6
 assert json.loads((run/'result_v049.json').read_text())['live_execution'] is False
 for case in run.glob('static-case-*'):
  plan=json.loads((case/'checkpoint-plan-v049.json').read_text())
  assert len(plan['steps'])==7 and len(plan['negative_cases'])==2 and plan['expected_checks']==63
print('V049_STATIC_LAUNCHER_FIXTURE_PASS: six original-generator Context cases, no server requests')
