// Generated stories: explicit entity instances; Context-driven verification.
// HTTP paths and request bodies are confined to interfaces.
ctx.bthread("protectWriteAndReadback", "WriteLock.All", function(lock) {
    sync({block:matchesConflictingWrites(lock.logicalId,lock.owner),waitFor:matchesVerified(lock.logicalId,lock.revision)});
});
ctx.bthread("protectPendingVerification", "Verification.Pending", function(resource) {
    sync({block:matchesMutations(resource.id),waitFor:matchesVerified(resource.id,resource.revision)});
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyModelsProjectAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="ModelsProject") return;
    verifyModelsProject(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance ModelsProject_1: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsProject_1", function() {
    var parents=waitForDependencies([]);
    createModelsProject("ModelsProject_1",{"title":"sbt-1-ModelsProject-1-title"},parents);
    waitFor(matchesVerified("ModelsProject_1",1));
    updateModelsProject(getModelEntity("ModelsProject_1"),{"description":"sbt-1-ModelsProject_1-updated"});
    waitFor(matchesVerified("ModelsProject_1",2));
});

// Instance ModelsProject_2: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsProject_2", function() {
    var parents=waitForDependencies([]);
    createModelsProject("ModelsProject_2",{"title":"sbt-1-ModelsProject-2-title"},parents);
    waitFor(matchesVerified("ModelsProject_2",1));
    updateModelsProject(getModelEntity("ModelsProject_2"),{"description":"sbt-1-ModelsProject_2-updated"});
    waitFor(matchesVerified("ModelsProject_2",2));
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyModelsTaskAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="ModelsTask") return;
    verifyModelsTask(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance ModelsTask_1: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsTask_1", function() {
    var parents=waitForDependencies(["ModelsProject"]);
    createModelsTask("ModelsTask_1",{"title":"sbt-1-ModelsTask-1-title"},parents);
    waitFor(matchesVerified("ModelsTask_1",1));
    updateModelsTask(getModelEntity("ModelsTask_1"),{"description":"sbt-1-ModelsTask_1-updated"});
    waitFor(matchesVerified("ModelsTask_1",2));
});

// Instance ModelsTask_2: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsTask_2", function() {
    var parents=waitForDependencies(["ModelsProject"]);
    createModelsTask("ModelsTask_2",{"title":"sbt-1-ModelsTask-2-title"},parents);
    waitFor(matchesVerified("ModelsTask_2",1));
    updateModelsTask(getModelEntity("ModelsTask_2"),{"description":"sbt-1-ModelsTask_2-updated"});
    waitFor(matchesVerified("ModelsTask_2",2));
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyModelsLabelAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="ModelsLabel") return;
    verifyModelsLabel(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance ModelsLabel_1: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsLabel_1", function() {
    var parents=waitForDependencies([]);
    createModelsLabel("ModelsLabel_1",{"title":"sbt-1-ModelsLabel-1-title"},parents);
    waitFor(matchesVerified("ModelsLabel_1",1));
    updateModelsLabel(getModelEntity("ModelsLabel_1"),{"description":"sbt-1-ModelsLabel_1-updated"});
    waitFor(matchesVerified("ModelsLabel_1",2));
});

// Instance ModelsLabel_2: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsLabel_2", function() {
    var parents=waitForDependencies([]);
    createModelsLabel("ModelsLabel_2",{"title":"sbt-1-ModelsLabel-2-title"},parents);
    waitFor(matchesVerified("ModelsLabel_2",1));
    updateModelsLabel(getModelEntity("ModelsLabel_2"),{"description":"sbt-1-ModelsLabel_2-updated"});
    waitFor(matchesVerified("ModelsLabel_2",2));
});
