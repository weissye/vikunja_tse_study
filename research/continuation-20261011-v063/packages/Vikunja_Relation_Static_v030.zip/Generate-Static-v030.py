import subprocess,sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'regenerated-v030'
if out.exists():raise SystemExit('Use a new output directory')
contract=ROOT/'generator/vikunja-live-swagger.json'
cmd=[sys.executable,'-m','generator_v56','context-generate','--openapi',str(contract),'--output',str(out/'spec/js'),'--name','vikunja','--base-url','http://127.0.0.1:3456/api/v1','--instances-per-entity','2','--seed','1','--negative-schema','--method-adapter',str(ROOT/'generator/method_adapter_v010.json')]
for path in ('/projects','/projects/{id}/tasks','/labels'):cmd+=['--resource',path]
subprocess.run(cmd,cwd=ROOT/'generator/source',check=True)
raw=json.loads(contract.read_text());routes=[]
for path,ops in raw['paths'].items():
 if '/tasks/' in path and '/labels' in path:
  for method,op in ops.items():
   routes.append({'path':path,'method':method.upper(),'description':op.get('description',op.get('summary','')),'source_pointer':'#/paths/'+path.replace('~','~0').replace('/','~1')+'/'+method,'status':'DISCOVERED_NOT_RENDERED_OR_EXECUTED'})
plan={'version':'v030','status':'STATIC_MODEL_GENERATED_RELATION_EXECUTION_PENDING','contract_sha256':hashlib.sha256(contract.read_bytes()).hexdigest(),'instances_per_entity':2,'seed':1,'relation_operations':routes,'blocked':['Checkpoint supports independent resources only','Relation stories and independent relation verifiers pending','No live acceptance; do not run this model on live server yet'],'full_coverage':False}
(out/'relation-plan-v030.json').write_text(json.dumps(plan,indent=2))
print('V030_STATIC_GENERATION_COMPLETE; live execution not enabled')
