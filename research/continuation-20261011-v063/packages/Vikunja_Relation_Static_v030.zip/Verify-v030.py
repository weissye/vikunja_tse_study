import json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST_v030.json').read_text())
for n,h in m.items():
 if hashlib.sha256((r/n).read_bytes()).hexdigest()!=h:raise SystemExit('Mismatch: '+n)
print('V030_INTEGRITY_PASS',len(m))
