$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_RELATION_STATIC v030'
& python (Join-Path $PSScriptRoot 'Verify-v030.py')
if ($LASTEXITCODE -ne 0) {throw 'Integrity failed.'}
& python (Join-Path $PSScriptRoot 'Test-Static-v030.py')
if ($LASTEXITCODE -ne 0) {throw 'Static mapping tests failed.'}
$output=Join-Path $PSScriptRoot ('generated-v030-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
& python (Join-Path $PSScriptRoot 'Generate-Static-v030.py') $output
if ($LASTEXITCODE -ne 0) {throw 'Generation failed.'}
Write-Host "Generated JS: $output\spec\js"
Write-Host 'STATIC ONLY. Live relation acceptance is not implemented in this delivery.'
