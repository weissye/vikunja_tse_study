import json,sys,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'generator/source'))
from generator_v56.render.context_model import build_model
from generator_v56.parsing.swagger_context import normalize_context_contract
raw,_=normalize_context_contract(json.loads((ROOT/'generator/vikunja-live-swagger.json').read_text()))
c,entities=build_model(raw,['/projects','/projects/{id}/tasks','/labels'],2,1)
task=next(e for e in entities if e['name']=='ModelsTask')
assert task['detail']=='/tasks/{id}'
assert task['path_dependencies']==[{'parameter':'id','target':'ModelsProject'}]
assert any(d.get('path_only') and d['target']=='ModelsProject' for d in task['dependencies'])
ambiguous=copy.deepcopy(raw);ambiguous['paths']['/another-task/{id}']={'get':copy.deepcopy(raw['paths']['/tasks/{id}']['get'])}
try:build_model(ambiguous,['/projects','/projects/{id}/tasks','/labels'],2,1)
except ValueError as e:assert 'Ambiguous/missing item GET' in str(e)
else:raise AssertionError('Ambiguous response matching must block')
print('V030_STATIC_TEST_PASS: split route, Context parent dependency, ambiguous mapping blocked')
