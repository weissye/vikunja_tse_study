import json,subprocess,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine-v010/source'))
from generator_v56.render.context_model import build_model
from generator_v56.parsing.swagger_context import normalize_context_contract
from generator_v56.render.context_relations import infer_relations

def catalog():
 source=ROOT/'engine-v010/vikunja-live-swagger.json';raw,_=normalize_context_contract(json.loads(source.read_text()))
 c,entities=build_model(raw,['/projects','/projects/{id}/tasks','/labels'],2,1)
 spec=infer_relations(c,entities)
 target=next(e for e in entities if e['name']==spec['target_type'])
 if c.resolve(target['update_schema']['properties']['title']).get('type')!='string':raise ValueError('Negative type rules require contract string field')
 spec['negative_field_pointer']='#/definitions/models.Label/properties/title'
 spec['negative_field_type']='string'
 cases=[]
 task_type=spec['child_type'];task=next(e for e in entities if e['name']==task_type)
 for field in ('title','description'):
  if c.resolve(task['update_schema']['properties'][field]).get('type')!='string':raise ValueError('Task field lacks string contract')
 spec['shared_task_update_method']=task['update_method'].upper()
 spec['shared_task_update_codes']=[int(x) for x in task['update']['responses'] if x.isdigit() and 200<=int(x)<300]
 spec['negative_field_pointer']='#/definitions/models.Task/properties/title'
 if c.resolve(task['update_schema']['properties'][spec['parent_field']]).get('type')!='integer':raise ValueError('Task project identifier lacks integer update field')
 spec['negative_field_pointers']={'title':'#/definitions/models.Task/properties/title',spec['parent_field']:'#/definitions/models.Task/properties/'+spec['parent_field']}
 spec['move_authority']='Writable project_id field in task POST schema; movement and collection consistency are explicit research hypotheses, not a guarantee derived from schema alone'
 for index in (1,2):
  logical=task_type+'_'+str(index)
  for creator,other in [('A','B'),('B','A')]:
   move=dict(actor=other,field=spec['parent_field'],value='@{ID_'+spec['parent_type']+'_2}',task=logical)
   back=dict(actor=other,field=spec['parent_field'],value='@{ID_'+spec['parent_type']+'_1}',task=logical)
   remove=dict(actor=other,action='detach',label=spec['target_type']+'_1',task=logical)
   attach=dict(actor=creator,action='attach',label=spec['target_type']+'_1',task=logical)
   cases.append(dict(case_id='cross-user-links-task-'+str(index)+'-creator-'+creator,subjects={'task':logical,'other_task':task_type+'_'+str(3-index),'label':spec['target_type']+'_1','second_label':spec['target_type']+'_2'},steps=[move,remove,attach,back],prefix_actor=creator,comparison_group=logical,order='creator-'+creator,negative_target=logical,negative_cases=[dict(rule_id='STRING_TYPE_ARRAY',field='title',value=[]),dict(rule_id='INTEGER_TYPE_OBJECT',field=spec['parent_field'],value={})],expected_checks=138))
 return {'version':'v055','contract_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'family':'shared_tasks','project_membership_observer':True,'relation_spec':spec,'items':cases,'authenticated_clients':2,'same_user':False,'true_concurrency':False,'mutation_steps_per_case':4,'prefix_depth_parameter':False,'setup_prefix':['Authenticate two different users','Grant project Read & Write permission','Verify sharing entry','Verify same project/task identities','Verify allowed task update by second user','Save shared baseline'],'authority':'Sharing permission=1 is explicitly Read & Write in models.ProjectUser; task fields and update operation derive from contract; preservation and readback are recorded research hypotheses','full_system_coverage':False,'deferred':['Shared label mutation','Forbidden-resource tests','True concurrency','General prefix depth']}

def generate(run,case,proxy,resources=None):
 run=run.resolve()
 plan=dict(version='v055',family='shared_tasks',mode='resume' if resources is not None else 'bootstrap',relation_spec=catalog()['relation_spec'],case_id=case['case_id'],subjects=case['subjects'],resources=resources or [],relations=[],seed=1,steps=case['steps'],expected_checks=case['expected_checks'],comparison_group=case['comparison_group'],order=case['order'],negative_target=case['negative_target'],negative_cases=case['negative_cases'],project_membership_observer=True,preserve_task_labels=True,prefix_actor=case['prefix_actor'],final_memberships={case['subjects']['task']:[case['subjects']['label'],case['subjects']['second_label']],case['subjects']['other_task']:[case['subjects']['label'],case['subjects']['second_label']]})
 run.mkdir(parents=True,exist_ok=True);(run/'checkpoint-plan-v055.json').write_text(json.dumps(plan,indent=2))
 cmd=[sys.executable,'-m','generator_v56','context-generate','--openapi',str(ROOT/'engine-v010/vikunja-live-swagger.json'),'--output',str(run/'project/spec/js'),'--name','vikunja','--base-url',proxy,'--instances-per-entity','2','--seed','1','--negative-schema','--method-adapter',str(ROOT/'engine-v010/method_adapter_v010.json'),'--checkpoint-plan',str(run/'checkpoint-plan-v055.json')]
 for path in ('/projects','/projects/{id}/tasks','/labels'):cmd+=['--resource',path]
 proc=subprocess.run(cmd,cwd=ROOT/'engine-v010/source',capture_output=True,text=True,timeout=60);(run/'generation.log').write_text(proc.stdout+proc.stderr)
 if proc.returncode:raise RuntimeError('Generator failed; inspect generation.log')
 return run/'project'
if __name__=='__main__':
 out=Path(sys.argv[1]).resolve();generate(out,catalog()['items'][0],'http://127.0.0.1:3456/api/v1');(out/'relation-catalog-v055.json').write_text(json.dumps(catalog(),indent=2));print('V055_GENERATED_NOT_NATIVE_EXECUTED',out)
