"""Contract task-label pagination: complete only after empty page."""
def collect(task,fetch,max_pages=100):
 ids=[];seen=set()
 for page in range(1,max_pages+1):
  code,items=fetch('/tasks/'+task+'/labels?page='+str(page)+'&per_page=50')
  if code!=200 or not isinstance(items,list):return dict(complete=False,reason='PAGE_UNAVAILABLE',page=page)
  if not items:return dict(complete=True,ids=ids,pages=page)
  for item in items:
   if not isinstance(item,dict) or type(item.get('id')) is not int or item['id'] in seen:return dict(complete=False,reason='INVALID_OR_DUPLICATE_PAGE',page=page)
   seen.add(item['id']);ids.append(item['id'])
 return dict(complete=False,reason='PAGE_CAP')
