# v079 — Teams and saved filters in one unified model

Base: live-accepted v078. All generic source files are byte-identical to v078; `GENERIC_SOURCE_SHA256_v078.json` and the test verify this. The source gate, nested-route support, DAL, original verifiers and recovery mechanism remain unchanged. Scope/rule selection is external data. The emitter still reads only generated contract IR and research configuration.

## Model and expected acceptance coverage

Seven types, three instances each: Project, Task, Label, ProjectView, TaskComment, Team, SavedFilter. One Provengo project / three JS files, 21 lifecycle bthreads. Expected:

- 21 successful creations.
- 15 positive updates (projects, tasks, labels, views, teams).
- 36 independent lifecycle GETs; comments and saved filters have creation/readback only.
- 18 independent negative bthreads: TYPE_ARRAY and MIN_LENGTH for task title, label title and team name, each across three instances.
- 18 verified recoveries and continuation in the same JVM after a retained finding.
- The same 15 relationship observations: Task->Project, View->Project and Comment->Task. The additions are standalone resources; team/project membership and filter-result/task semantics are not introduced.

Provengo chooses interleaving among all workflows and negative checks. Per-resource observation isolation uses declared `logicalId` plus `affected`; child writes affecting a protected parent are blocked, disjoint writes remain enabled. Correct footprints are required; undocumented/transitive side effects are not automatically known.

The empty-label-title finding remains active. Original failed oracles remain false after restoration. Empty task title behavior remains under separate triage: the observed task retains its title and changes `updated`, unlike a label that persists an empty title. Do not call these identical semantic bugs.

## Saved filter mapping and verification

`input-source/acceptance-plan-v079.json` selects the new scope and uses the existing `request-mappings-v073.json` upstream mapping. That mapping was accepted live in v073 and creates `{title, filters:{filter:"done = false"}}`. This is an explicit external contract-gap mapping/fixture, not claimed automatically inferred from the missing request schema.

The generated independent GET verifier checks stable identity, title and the request-derived query projection. Extra server-owned response fields are allowed by the existing recursive generic verifier; a changed query is rejected. A local Node test executes that actual generated callback in both cases. Saved-filter updates and invalid-input checks are not emitted by the current model and are not counted as tested. Filter semantic correctness over a task population is also not established by this projection check.

Team name/type rules come from the contract catalogue. Their original responses and post-write states will determine PASS/FINDING/INCONCLUSIVE; no expected outcome is fabricated. Teams add create, readback, description update, readback and six negative checks. Membership and multi-user behavior remain future work.

## Runtime / recovery

The accepted v075-v078 negative-write recovery protocol remains unchanged: cold snapshot of current persistent prefix, original mutation response and independent original post-write GET retained, optional private failed-state snapshot, rollback, strict supported storage equality before restart and complete observed resource-prefix comparison after restart. Authentication is validated after restarts and renewed only when invalid. The same native JVM/pending bthreads remain alive.

Missing observations are INCONCLUSIVE; unsafe restoration blocks continuation. Timed-out mutations are never replayed. Positive create/update/delete failure recovery remains unsupported. Full contract coverage, deletion, multiple users and all relationships are not claimed.

Use the isolated local research SUT with no other clients during rollback. Snapshots cover its configured SQLite/files state. Process memory/clocks/external services and unobserved API resources are outside the claims. Exclusive Home named volumes use the existing cached helper container; Work bind paths must match `<StudyRoot>/deployment/state/db` and `files`. Bind metadata scope covers content, Windows mode and exact modification times, excluding ACLs/creation times/Linux ownership.

Frozen Vikunja v2.6.0: `http://127.0.0.1:3456/api/v1`, existing `vikunja-research-sut`. Contract SHA256: `171e238314089ca9b1c5c6fa3f87cf7f80a7c2a55934d1d6c228b39d48b65843`. JAR SHA256: `dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b`. Minimum 2 GB free; actual snapshot needs depend on existing storage. The server must already be running.

```powershell
& .\Run-Recovery-v079.ps1 -StudyRoot 'C:\work\temp\vikunja_tse_study' -Username 'SBT-tester' -RunLive
```

For Home use `D:\Yeshayahu\Temp\vikunja_tse_study`. JAR defaults to `<StudyRoot>/Provengo-2026-01-10.uber.jar`; override with `-ProvengoJar`. Omit `-RunLive` for static generation. This creates a NEW acceptance run/resources, leaving v078 evidence untouched.

Review ZIP contains generated inputs/JS, native log, request/response journal, recovery ledger, relationship audit, result and manifest. Private snapshots stay local. Logs close before packaging. Generated example JS is at `example/project/spec/js`; its proxy port is illustrative.

## Validation and interpretation

Local tests passed: all generic-source byte identity to v078, 21 lifecycles/18 negative bthreads, request projection for saved filters, generated JS syntax, nested-route callback execution, footprint isolation, relationship refusal, recovery/failed-observation/authentication tests and log sealing. There is no frozen JAR/SUT on the build host, so native/live acceptance remains required.

`V079_STATIC_READY`: generation only.

`V079_RECOVERY_ACCEPTANCE_COMPLETED_WITH_FINDINGS`: expected resource/update/negative/recovery coverage and relationship audit completed, original finding retained, and a later negative check completed in the same JVM. Inconclusive checks are separately reported; this is not a claim that all semantic oracles passed.

`V079_COMPLETE_NO_FINDING_CONTINUATION_NOT_PROVEN`: completed without demonstrating post-finding continuation.

`NOT_ACCEPTED`: preserve the printed review ZIP and private snapshots; do not count symbolic subsequent selections as live coverage.
