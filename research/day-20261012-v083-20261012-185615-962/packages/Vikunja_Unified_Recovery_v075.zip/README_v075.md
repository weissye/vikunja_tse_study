# v075 changes over v074

The v074 live review created six resources but stopped in the first negative case, before verified recovery. It did not record the original mutation response or failed post-write GET. Its native log hash did not match the review manifest. Authentication invalidation after restart remains a hypothesis about that historical run, not a confirmed cause.

v075 records the mutation response immediately, then records the independent post-write GET status/body before parsing or rejecting it. The `/user` authenticated probe runs after cold saves and restores. An invalid session (401/403) causes one bounded renewal sequence; normal probes reuse the token. Login rate limits cause up to four attempts with 60-second waits, without advancing model events or retrying a write. Original authentication probe codes and renewal markers are saved; password/JWT values are not.

Rollback is attempted in `finally`, including failed authentication, ambiguous mutation transport and unavailable post-write observation. If a write timed out, it is never automatically repeated: restoration is verified and the campaign stops with the ambiguity recorded. An unavailable original observation gets `INCONCLUSIVE`, `pass: null`, and null after-projection/changed-fields. It is not called a semantic finding or a pass. Verified restoration can allow later bthreads to proceed after such an observation failure. Findings retain `pass: false`.

The runner now waits for process termination and log-reader closure on ALL exit paths before packaging. Native test-fail-mode entry causes a prompt stop. If the log writer cannot close, it refuses to seal a review instead of publishing a changing log hash.

The scope is unchanged: one project, three generated JS files, six lifecycles, six selected negative checks. Both original v069 and corrected v073 JS remain byte-identical with recovery disabled. This is a new bounded acceptance, not a resume of v074 and not full eight-entity coverage. The original v074 checkpoint remains untouched.

Tests cover expired authentication, renewal exactly once, failed observation with original status retained and verified rollback, ambiguous write with no replay, unsafe restoration refusal, actual subprocess/log closure before manifest, generated callback verdicts and backward compatibility. Native/live acceptance is still required on your host. A technical recovery acceptance with findings can include independently reported inconclusive checks; it does not mean every semantic oracle was resolved.

## Retained architecture and usage

## What this delivery implements

An opt-in recovery policy in the generic two-input emitter. The preprocessing stage produces `contract-ir.json`; external experiment settings produce `research-config.json`. The emitter reads only those inputs. It emits one Provengo project with `stories.vikunja.js`, `interfaces.vikunja.js` and `dal.js`.

Provengo chooses event interleaving among independent lifecycle, negative and Context verifier bthreads. The HTTP recovery transport never selects, reorders or replays workflow events. A negative write is one selected REST action; its recovery work completes before that action returns. No second native process is launched.

The bounded acceptance selects projects and labels, three instances each. Six lifecycle bthreads each create, verify, update and verify their resource. Six negative bthreads test the label title's contract-derived type and minimum-length constraints. This is **not** all eight entity types, all dependencies, multiple users, or the full 612-check catalogue. Rule selection is an explicit research-configuration input.

## Recovery protocol and evidence

1. A resource-local negative observation gate protects the tested resource. A matching preparation GET must precede its mutation.
2. Immediately before the selected negative mutation, independently read every resource created in this run and cold-save the current SQLite/files state. This is the current interleaved prefix, not an old initial fixture.
3. Send the original mutation to the SUT; retain its actual input, status, response and independent post-write GET. A candidate finding also gets a private failed-state snapshot.
4. Restore the checkpoint. Check persistent content and supported metadata strictly **before restarting the SUT**. Then independently compare the complete observed resource prefix with its pre-window state.
5. Return the original mutation response unchanged. The generated verifier reads a local outcome endpoint with the original post-write state (or its recorded unavailability) and restored state. `NEGATIVE_CHECK.pass` stays false for an accepted invalid write or changed state. `RECOVERY_CHECK` separately confirms restoration.
6. A verified restoration permits the selected bthread to complete; all other suspended bthreads remain in the same JVM. An unverified restoration, missing evidence, unknown resource, repeated case, native failure or timeout blocks continuation.

The existing DAL does not commit negative-attempt writes into expected resource state. Therefore no fictitious expected-state mutation needs to be undone in this bounded protocol. The JS verifier also compares the restored projection with its stored pre-write projection. This is **not** a serializer/restorer for arbitrary Context state or Java stacks. Recovery after failed positive create/update/delete is not implemented; those failures remain fatal.

`gateway-journal.jsonl` retains original request/response records. `recovery-ledger.json` retains full before/restored API views, their SHA256 fingerprints and strict storage-verification results. `native.log` retains original negative oracle markers and separate recovery markers. The final review ZIP includes the generated JS, both input files and these evidence files with a SHA256 manifest. Products databases and `.private-snapshots` stay locally available and are excluded from the review ZIP.

A normal 4xx negative write is also rolled back in v075. This conservative acceptance protocol tests isolation and prevents hidden persistent side effects; snapshotting every test is not claimed to be a scalable production search strategy.

## Storage / environment

- Frozen SUT: Vikunja v2.6.0, local `http://127.0.0.1:3456/api/v1`.
- Contract SHA256: `171e238314089ca9b1c5c6fa3f87cf7f80a7c2a55934d1d6c228b39d48b65843`.
- JAR SHA256: `dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b`.
- Work binds: `<StudyRoot>/deployment/state/db` and `files`; exact paths, content, Windows mode and nanosecond modification times are checked. ACLs, creation times and Linux ownership are outside this adapter's coverage.
- Home named volumes: exclusive writable mounts at `/db` and `/app/vikunja/files`; existing helper container `vikunja-increment8-2-files-init` supplies a cached image. Tar entry content, modes, ownership and directory times are verified.
- No mixed mounts, remote target, shared/overlapping storage or symlinks/reparse points.
- The existing server must be running. The password is requested once; authenticated probes determine whether renewal is necessary. No password or raw JWT is saved in the review.
- At least 2 GB free disk space; actual snapshot space also depends on current database/files size.
- Use an isolated research SUT with no other clients during acceptance: rollback covers the entire configured storage. Do not run two recovery launchers together.

Persistent storage and observed resources are covered. Process memory, time, queues, external services and unobserved API resources are not claimed to be identical. Cold storage equality is checked before restart; API equality is checked after restart. Storage backend code is retained from the earlier verified v010/v023 mechanism; v075 integration still needs native/live acceptance on your host.

## Commands

Static generation (no Docker changes / requests):

```powershell
& .\Run-Recovery-v075.ps1 -StudyRoot 'C:\work\temp\vikunja_tse_study'
```

Work live acceptance:

```powershell
& .\Run-Recovery-v075.ps1 -StudyRoot 'C:\work\temp\vikunja_tse_study' -Username 'SBT-tester' -RunLive
```

Home live acceptance:

```powershell
& .\Run-Recovery-v075.ps1 -StudyRoot 'D:\Yeshayahu\Temp\vikunja_tse_study' -Username 'SBT-tester' -RunLive
```

The JAR defaults to `<StudyRoot>/Provengo-2026-01-10.uber.jar`; use `-ProvengoJar` if needed. The launcher creates a NEW acceptance run and NEW research resources; it does not resume a previous v069/v073 run.

The generated acceptance example is under `example/project/spec/js`. Its loopback transport URL is a static example only. The live launcher regenerates with its own local transport port.

## Acceptance / coverage interpretation

`V075_STATIC_READY`: generation only, no native/live result.

`V075_RECOVERY_ACCEPTANCE_COMPLETED_WITH_FINDINGS`: native success, one JVM, all six resources created, six positive updates, all six distinct negative checks and verified restorations, original finding retained, at least one later negative check completed after the first finding.

`V075_COMPLETE_NO_FINDING_CONTINUATION_NOT_PROVEN`: all selected checks completed but continuation after a finding was not demonstrated. This is not reported as acceptance of the known-bug recovery criterion.

`NOT_ACCEPTED`: preserve the review ZIP and local private snapshots; inspect the error, do not infer that remaining checks ran.

`Test-Recovery-v075.py` uses a fake SUT/storage backend to test failure retention, prefix preservation, subsequent workflow progress and unsafe restoration rejection. It checks v069 and corrected v073 byte identity with recovery disabled, generated JS syntax, and executes the actual generated verifier callback in Node. These tests are **not** a native Provengo run or live server test. There is no JAR/server in the build environment.

## Method boundary

This delivery adds a configurable renderer capability; it does not encode research phase numbers in model generation. The runner knows the bounded acceptance's expected coverage, separate from the generic emitter. Source templates change before files are emitted; generated JS is never hand patched.

Existing dependencies and original Context/stories/interfaces/DAL remain in the generic source and reference models. The bounded two-root acceptance itself does not demonstrate dependent entities or all parent-order cases. Those must be covered in the next expansion after recovery acceptance passes.
