import sys,json,argparse
from pathlib import Path
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'source'))
from input_pipeline import compile_ir,research_config
from generic_emitter import emit
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--proxy-url',default='http://127.0.0.1:13474');a=p.parse_args()
if a.output.exists():raise SystemExit('Use a new directory')
a.output.mkdir(parents=True)
ir=compile_ir(root/'input-source/contract.json',{'resources':['/projects','/labels']},root/'input-source/method_adapter.json')
cfg=research_config(name='vikunja',base_url=a.proxy_url);cfg['experiment_id']='recovery-acceptance-v074';cfg['missing_information']['policy']='block';cfg['recovery']={'policy':'cold_snapshot_restore','negative_rule_ids':['ModelsLabel/title/MIN_LENGTH','ModelsLabel/title/TYPE_ARRAY']}
for n,v in [('contract-ir.json',ir),('research-config.json',cfg)]:
 (a.output/n).write_text(json.dumps(v,indent=2),encoding='utf-8')
emit(a.output/'contract-ir.json',a.output/'research-config.json',a.output/'project')
print('V074_ONE_MODEL_RECOVERY_ACCEPTANCE_GENERATED')
