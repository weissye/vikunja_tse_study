"""Loopback recovery transport. It never chooses or reorders model events."""
import json, hashlib, re, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

def fingerprint(v):
    return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()

class RecoveryGateway:
    def __init__(self,target,token,backend,run,entities):
        self.target=target.rstrip('/'); self.token=token; self.backend=backend; self.run=Path(run)
        self.entities={e['name']:e for e in entities}; self.registry={}; self.prepared={}; self.outcomes={}
        self.records=[]; self.recoveries=[]; self.error=None
    def record(self,record):
        record=dict(record,index=len(self.records)); self.records.append(record)
        with (self.run/'gateway-journal.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps(record,sort_keys=True)+'\n'); f.flush()
    def request(self,path,method='GET',body=None):
        if not path.startswith('/') or path.startswith('//') or '..' in path.split('/'):
            raise ValueError('Unsafe target path')
        headers={'Content-Type':'application/json','Authorization':'Bearer '+self.token}
        req=urllib.request.Request(self.target+path,data=body,headers=headers,method=method)
        try:
            with urllib.request.urlopen(req,timeout=45) as r: return r.status,r.read()
        except urllib.error.HTTPError as r: return r.code,r.read()
    def observe(self):
        result={}
        for logical,path in sorted(self.registry.items()):
            status,raw=self.request(path)
            if status!=200: raise RuntimeError('Recovery probe rejected: '+logical+' HTTP '+str(status))
            result[logical]=json.loads(raw)
        return result
    def dispatch(self,path,method,body,headers):
        if self.error: raise RuntimeError('Recovery transport already stopped')
        action=headers.get('X-SBT-Action',''); logical=headers.get('X-SBT-LogicalId','')
        case=headers.get('X-SBT-CaseId','')
        if path.startswith('/__sbt/outcome/'):
            key=path.split('/')[-1]
            if method!='GET' or key!=case or key not in self.outcomes: raise ValueError('Unknown recovery outcome')
            self.record({'category':'recovery-control','case_id':case,'action':'outcome'})
            return 200,json.dumps(self.outcomes[key]).encode()
        if action=='negative_attempt':
            if not re.fullmatch(r'[A-Za-z0-9_.:-]+',case) or case in self.outcomes:
                raise ValueError('Invalid or repeated case identifier')
            if self.prepared.get(case)!=(logical,path) or self.registry.get(logical)!=path:
                raise ValueError('Negative attempt lacks matching preparation/registered resource')
            prefix=self.observe(); snapshot=self.backend.save('before-'+case)
            status,raw=self.request(path,method,body)
            observed_status,observed_raw=self.request(path)
            if observed_status!=200: raise RuntimeError('Original post-write observation unavailable')
            observed=json.loads(observed_raw)
            finding=not 400<=status<500 or observed!=prefix[logical]
            failed_snapshot=self.backend.save('finding-'+case) if finding else None
            self.record({'category':'research','case_id':case,'action':action,'logical_id':logical,
                         'path':path,'method':method,'input':json.loads(body),
                         'status':status,'response':raw.decode('utf-8',errors='replace'),
                         'before':prefix[logical],'original_after':observed,'finding_candidate':finding})
            self.backend.restore(snapshot)
            verification=json.loads((self.run/'restore-verification-v010.json').read_text())
            restored=self.observe()
            equal=prefix==restored
            if not verification.get('strict_equality') or not equal:
                raise RuntimeError('Restored storage/API prefix differs; continuation blocked')
            outcome={'case_id':case,'observed_after':observed,'observed_status':observed_status,
                     'verified_after':restored[logical],'actual_status':status,
                     'snapshot_restored':True,'api_prefix_equal':equal,'safe_to_continue':True,
                     'prefix_before':prefix,'prefix_restored':restored,
                     'prefix_before_sha256':fingerprint(prefix),'prefix_restored_sha256':fingerprint(restored),
                     'snapshot_hashes':snapshot['hashes'],'finding_snapshot_hashes':failed_snapshot['hashes'] if failed_snapshot else None,
                     'storage_verification':verification}
            self.outcomes[case]=outcome; self.recoveries.append(outcome)
            self.record({'category':'recovery','case_id':case,'outcome':outcome})
            return status,raw  # Original mutation response is never replaced with synthetic success.
        status,raw=self.request(path,method,body)
        if action=='create' and 200<=status<300:
            if logical in self.registry: raise ValueError('Repeated logical resource creation')
            entity=self.entities[headers.get('X-SBT-Type','')]; value=json.loads(raw)
            route=value[entity.get('route_field','id')]
            self.registry[logical]=entity['detail'].replace('{'+entity['parameter']+'}',str(route))
        if action=='negative_prepare' and status==200:
            self.prepared[case]=(logical,path)
        self.record({'category':'research','action':action,'logical_id':logical,'case_id':case,
                     'path':path,'method':method,'status':status,
                     'input':json.loads(body) if body else None,'response':raw.decode('utf-8',errors='replace')})
        return status,raw
    def server(self):
        gateway=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_GET(self): self.handle_request()
            def do_POST(self): self.handle_request()
            def do_PUT(self): self.handle_request()
            def do_DELETE(self): self.handle_request()
            def handle_request(self):
                try:
                    body=self.rfile.read(int(self.headers.get('Content-Length','0'))) or None
                    status,raw=gateway.dispatch(self.path,self.command,body,self.headers)
                except Exception as e:
                    gateway.error=str(e)
                    try: gateway.record({'category':'infrastructure-error','error':str(e)})
                    except OSError: pass
                    status,raw=503,json.dumps({'error':'Recovery blocked; inspect local journal'}).encode()
                self.send_response(status); self.send_header('Content-Type','application/json')
                self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
        return HTTPServer(('127.0.0.1',0),Handler)
