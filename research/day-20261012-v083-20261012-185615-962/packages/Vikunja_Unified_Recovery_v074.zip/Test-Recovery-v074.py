"""Meaningful protocol tests, with fake storage/SUT. No claim of native acceptance."""
import copy,json,tempfile,sys,subprocess,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'runtime'));sys.path.insert(0,str(ROOT/'source'))
from recovery_gateway import RecoveryGateway
from input_pipeline import compile_ir,research_config
from generic_emitter import emit
class Backend:
    def __init__(self,run,state):self.run=run;self.state=state;self.saved={};self.calls=[];self.break_restore=False
    def save(self,label):
        self.saved[label]=copy.deepcopy(self.state);self.calls.append(('save',label));return {'folder':label,'hashes':{'fake':'test-only'}}
    def restore(self,snapshot):
        self.calls.append(('restore',snapshot['folder']))
        if not self.break_restore:self.state.clear();self.state.update(copy.deepcopy(self.saved[snapshot['folder']]))
        (self.run/'restore-verification-v010.json').write_text(json.dumps({'strict_equality':not self.break_restore,'includes_directory_mtime':True}))
with tempfile.TemporaryDirectory() as d:
    run=Path(d);state={'/labels/1':{'id':1,'title':'valid'},'/projects/2':{'id':2,'title':'prefix-latest'}}
    b=Backend(run,state);g=RecoveryGateway('http://127.0.0.1:3456/api/v1','not-a-real-token',b,run,[])
    g.registry={'ModelsLabel_1':'/labels/1','ModelsProject_1':'/projects/2'}
    def fake(path,method='GET',body=None):
        if method=='POST':
            value=json.loads(body)
            if isinstance(value.get('title'),list):return 412,b'{"message":"invalid type"}'
            state[path].update(value)
        return 200,json.dumps(state[path]).encode()
    g.request=fake
    def h(action,case):return {'X-SBT-Action':action,'X-SBT-CaseId':case,'X-SBT-LogicalId':'ModelsLabel_1'}
    g.dispatch('/labels/1','GET',None,h('negative_prepare','bug'))
    status,raw=g.dispatch('/labels/1','POST',b'{"title":""}',h('negative_attempt','bug'))
    assert status==200 and json.loads(raw)['title']=='' # Original successful bad write remains evidence.
    assert state['/labels/1']['title']=='valid' and state['/projects/2']['title']=='prefix-latest'
    assert g.outcomes['bug']['observed_after']['title']=='' and g.outcomes['bug']['verified_after']['title']=='valid'
    assert g.outcomes['bug']['prefix_before_sha256']==g.outcomes['bug']['prefix_restored_sha256']
    # A different workflow can advance after restoration; its current prefix is preserved by the next window.
    g.dispatch('/projects/2','POST',b'{"title":"prefix-next"}',{'X-SBT-Action':'update','X-SBT-LogicalId':'ModelsProject_1'})
    g.dispatch('/labels/1','GET',None,h('negative_prepare','later'))
    assert g.dispatch('/labels/1','POST',b'{"title":[]}',h('negative_attempt','later'))[0]==412
    assert state['/projects/2']['title']=='prefix-next' and len(g.recoveries)==2
    g.dispatch('/labels/1','GET',None,h('negative_prepare','unsafe'));b.break_restore=True
    try:g.dispatch('/labels/1','POST',b'{"title":""}',h('negative_attempt','unsafe'))
    except RuntimeError:pass
    else:raise AssertionError('Unsafe restoration was accepted')
    assert 'unsafe' not in g.outcomes
    # Disabled recovery output stays byte-identical to v073 for identical inputs.
    src=ROOT/'input-source';ir=compile_ir(src/'contract.json',src/'SCOPE_v069.json',src/'method_adapter.json',src/'request-mappings-v073.json')
    cfg=research_config(name='vikunja');ip=run/'ir.json';cp=run/'config.json';ip.write_text(json.dumps(ir));cp.write_text(json.dumps(cfg));emit(ip,cp,run/'off')
    for ref in (ROOT/'reference-v073').glob('*.js'):assert ref.read_bytes()==(run/'off/spec/js'/ref.name).read_bytes()
    old=compile_ir(src/'contract.json',src/'SCOPE_v069.json',src/'method_adapter.json');ip.write_text(json.dumps(old));emit(ip,cp,run/'old')
    for ref in (ROOT/'reference-v069').glob('*.js'):assert ref.read_bytes()==(run/'old/spec/js'/ref.name).read_bytes()
    subprocess.run([sys.executable,str(ROOT/'Build-Acceptance-v074.py'),'--output',str(run/'on')],check=True)
    js=run/'on/project/spec/js';stories=(js/'stories.vikunja.js').read_text()
    assert stories.count('bthread("lifecycle ')==6 and sum(line.startswith('bthread("negative ') for line in stories.splitlines())==6
    assert len(list(js.glob('*.js')))==3
    if shutil.which('node'):
        for f in js.glob('*.js'):subprocess.run(['node','--check',str(f)],check=True)
        subprocess.run(['node',str(ROOT/'Test-Callback-v074.js'),str(js/'interfaces.vikunja.js')],check=True)
print(json.dumps({'version':'v074','status':'STATIC_PROTOCOL_TEST_PASS','native_execution':False,'live_execution':False,'checks':['original finding retained','whole observed prefix restored','later workflow progresses','unsafe recovery blocked','recovery-disabled v073 byte identity','one unified project, six lifecycles and six negative bthreads','generated JS syntax and verifier callback behavior']},indent=2))
