import argparse,getpass,hashlib,json,os,subprocess,sys,threading,time,zipfile,shutil
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'runtime'))
from checkpoint_backend import DockerVolumeBackend,json_request,request,native_markers
from bind_backend import BindBackend
from recovery_gateway import RecoveryGateway
JAR_SHA='dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b'
CONTRACT_SHA='171e238314089ca9b1c5c6fa3f87cf7f80a7c2a55934d1d6c228b39d48b65843'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def pack(run,result):
    (run/'result_v074.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    files=[p for p in run.rglob('*') if p.is_file() and not any(x in p.relative_to(run).parts for x in ('.private-snapshots','products','__pycache__')) and p.name not in ('review_v074.zip','manifest_v074.json')]
    manifest={p.relative_to(run).as_posix():sha(p) for p in sorted(files)}
    (run/'manifest_v074.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    with zipfile.ZipFile(run/'review_v074.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in files+[run/'manifest_v074.json']:z.write(p,p.relative_to(run).as_posix())
def main():
    p=argparse.ArgumentParser();p.add_argument('--study-root',type=Path,required=True);p.add_argument('--jar',type=Path,required=True)
    p.add_argument('--username',default='SBT-tester');p.add_argument('--run-live',action='store_true');a=p.parse_args()
    subprocess.run([sys.executable,str(ROOT/'Verify-v074.py')],check=True)
    run=a.study_root/'runs'/('recovery-v074-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True)
    gateway=None;server=None;process=None;token='';result={'version':'v074','status':'NOT_ACCEPTED','native_execution':False,'live_execution':False}
    try:
        if not a.run_live:
            subprocess.run([sys.executable,str(ROOT/'Build-Acceptance-v074.py'),'--output',str(run/'generated')],check=True)
            result['status']='V074_STATIC_READY'
        else:
            if shutil.disk_usage(a.study_root).free<2*1024**3:raise RuntimeError('At least 2 GB free space is required')
            if sha(a.jar)!=JAR_SHA:raise RuntimeError('Frozen Provengo JAR SHA256 mismatch')
            target='http://127.0.0.1:3456/api/v1'
            if json_request(target+'/info').get('version')!='v2.6.0':raise RuntimeError('Server version mismatch')
            status,raw=request(target+'/docs.json')
            if status!=200 or hashlib.sha256(raw).hexdigest()!=CONTRACT_SHA:raise RuntimeError('Frozen live contract SHA256 mismatch')
            mounts=json.loads(subprocess.run(['docker','inspect','vikunja-research-sut'],check=True,capture_output=True,text=True).stdout)[0]['Mounts']
            types={m['Type'] for m in mounts if m['Destination'] in ('/db','/app/vikunja/files')}
            if types=={'bind'}:backend=BindBackend('vikunja-research-sut',target,run,a.study_root)
            elif types=={'volume'}:backend=DockerVolumeBackend('vikunja-research-sut','vikunja-increment8-2-files-init',target,'',run)
            else:raise RuntimeError('Unsupported storage layout')
            password=getpass.getpass('Vikunja password for '+a.username+': ')
            token=json_request(target+'/login',method='POST',body={'username':a.username,'password':password})['token'];password=None
            backend.token=token
            gateway=RecoveryGateway(target,token,backend,run,[]);server=gateway.server()
            proxy='http://127.0.0.1:'+str(server.server_port)
            subprocess.run([sys.executable,str(ROOT/'Build-Acceptance-v074.py'),'--output',str(run/'generated'),'--proxy-url',proxy],check=True)
            ir=json.loads((run/'generated/contract-ir.json').read_text());gateway.entities={e['name']:e for e in ir['entities']}
            threading.Thread(target=server.serve_forever,daemon=True).start()
            env=dict(os.environ,SBT_AUTH_TOKEN=token)
            process=subprocess.Popen(['java','-jar',str(a.jar.resolve()),'run','--random-seed','1',str((run/'generated/project').resolve())],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
            result.update(native_execution=True,live_execution=True,native_pid=process.pid,native_launches=1)
            lines=[]; fatal=threading.Event()
            def read_log():
                with (run/'native.log').open('w',encoding='utf-8') as f:
                    for line in process.stdout:
                        clean=line.replace(token,'[REDACTED]');lines.append(clean);f.write(clean);f.flush()
                        if 'FAIL:' in clean or 'Test Result: FAIL' in clean: fatal.set()
            reader=threading.Thread(target=read_log,daemon=True);reader.start();started=time.monotonic();heartbeat=started
            print('V074_ONE_NATIVE_PROCESS_STARTED',process.pid,flush=True)
            while process.poll() is None:
                if gateway.error or fatal.is_set() or time.monotonic()-started>1800:
                    process.terminate();process.wait(timeout=30)
                    raise RuntimeError(gateway.error or 'Native failure/timeout; continuation blocked')
                if time.monotonic()-heartbeat>30:
                    print('V074_NATIVE_RUNNING recovered_windows='+str(len(gateway.recoveries)),flush=True);heartbeat=time.monotonic()
                time.sleep(.25)
            reader.join(timeout=10);log=''.join(lines)
            negatives=native_markers(log,'NEGATIVE_CHECK');checks=native_markers(log,'RECOVERY_CHECK')
            findings=[x for x in negatives if x.get('pass') is False]
            ids=[x.get('caseId') for x in negatives]
            expected_ids={'NEG_ModelsLabel_'+str(i)+'_'+str(j) for i in range(1,4) for j in range(2)}
            safe={x.get('caseId') for x in checks}==expected_ids and len(checks)==6 and all(x.get('recovery_verified') is True for x in checks)
            continued=bool(findings and ids.index(findings[0]['caseId'])<len(ids)-1)
            result.update(native_exit=process.returncode,created_resources=len(gateway.registry),positive_updates=sum(r.get('action')=='update' and 200<=r.get('status',0)<300 for r in gateway.records),negative_checks=negatives,recovery_checks=checks,findings=findings,completed_after_first_finding=continued,context_policy='Negative writes do not commit expected state; same JVM and pending bthreads retained',scope={'entity_types':2,'instances_per_type':3,'negative_checks':6})
            if process.returncode!=0 or 'Test Result: SUCCESS' not in log or set(ids)!=expected_ids or len(ids)!=6 or not safe or len(gateway.registry)!=6 or len(gateway.recoveries)!=6 or result['positive_updates']!=6:raise RuntimeError('Native recovery acceptance checks incomplete')
            result['status']='V074_RECOVERY_ACCEPTANCE_COMPLETED_WITH_FINDINGS' if continued else 'V074_COMPLETE_NO_FINDING_CONTINUATION_NOT_PROVEN'
    except Exception as e: result.update(status='NOT_ACCEPTED',error=str(e))
    finally:
        if process and process.poll() is None:process.terminate()
        if server:server.shutdown();server.server_close()
        if gateway:(run/'recovery-ledger.json').write_text(json.dumps(gateway.recoveries,indent=2),encoding='utf-8')
        pack(run,result)
    print('Status:',result['status']);print('Review ZIP:',run/'review_v074.zip')
    if result.get('error'):print('Error:',result['error'])
    return 0 if result['status'] in ('V074_STATIC_READY','V074_RECOVERY_ACCEPTANCE_COMPLETED_WITH_FINDINGS') else 1
if __name__=='__main__':raise SystemExit(main())
