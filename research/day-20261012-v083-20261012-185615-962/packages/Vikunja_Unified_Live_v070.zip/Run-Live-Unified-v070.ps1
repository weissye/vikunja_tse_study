param(
 [string]$StudyRoot='C:\work\temp\vikunja_tse_study',
 [string]$ProjectPath='C:\work\temp\vikunja_tse_study\generated\unified-v069-20261012-072518-562',
 [string]$ProvengoJar=(Join-Path $StudyRoot 'Provengo-2026-01-10.uber.jar'),
 [string]$BaseUrl='http://127.0.0.1:3456/api/v1',
 [string]$Username='SBT-tester',
 [int]$Seed=1,
 [ValidateRange(60,7200)][int]$TimeoutSeconds=1800
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_UNIFIED_LIVE_ACCEPTANCE v070'
& python (Join-Path $PSScriptRoot 'Verify-v070.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
& python (Join-Path $PSScriptRoot 'run_live_v070.py') `
 --study-root $StudyRoot --project $ProjectPath --jar $ProvengoJar `
 --base-url $BaseUrl --username $Username --seed $Seed --timeout $TimeoutSeconds
if ($LASTEXITCODE -ne 0) {throw 'Acceptance incomplete or finding recorded. Preserve the printed review ZIP.'}
