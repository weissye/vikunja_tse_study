"""Actuate one pinned unified project; no workflow scheduling outside Provengo."""
import argparse,getpass,hashlib,json,os,re,shutil,subprocess,sys,threading,time,urllib.request,urllib.error,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
JAR_SHA='dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b'
CONTRACT_SHA='171e238314089ca9b1c5c6fa3f87cf7f80a7c2a55934d1d6c228b39d48b65843'
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def write(path,value):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2),encoding='utf-8');tmp.replace(path)
def redact(value,secrets=()):
 for secret in secrets:
  if secret:value=value.replace(secret,'<redacted>')
 value=re.sub(r'\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b','<redacted-jwt>',value)
 value=re.sub(r'(?i)("?(?:password|authorization|access_token)"?\s*[:=]\s*")[^"]*(")',r'\1<redacted>\2',value)
 return value
# intentionally no raw authentication responses are persisted
def request(url,body=None):
 data=None if body is None else json.dumps(body).encode()
 req=urllib.request.Request(url,data=data,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=15) as response:return response.read()
def command(args,timeout=30):
 p=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
 if p.returncode:raise RuntimeError(args[0]+' command failed: '+redact(p.stderr[-1500:]))
 return p.stdout

def json_markers(log,marker):
 records=[]
 for line in log.splitlines():
  at=line.find(marker+' ')
  if at<0:continue
  try:value,_=json.JSONDecoder().raw_decode(line[at+len(marker)+1:]);records.append(value)
  except (json.JSONDecodeError,TypeError):pass
 return records

def analyze(log,exit_code,expected_negatives,expected_resources):
 events=json_markers(log,'CONTEXT_HTTP_CALLBACK');negatives=json_markers(log,'NEGATIVE_CHECK')
 unique={n.get('caseId'):n for n in negatives if n.get('caseId')}
 findings=[n for n in unique.values() if not n.get('pass')]
 created={e.get('logicalId') for e in events if e.get('action')=='create' and 200<=e.get('status',0)<300}
 switches=[];last=None;seen=set();reentry=False
 for i,e in enumerate(events):
  logical=e.get('logicalId')
  if not logical:continue
  if logical!=last:
   if logical in seen and last is not None:reentry=True
   switches.append({'event_index':i,'logicalId':logical,'action':e.get('action')});seen.add(logical);last=logical
 success=exit_code==0 and 'Test Result: SUCCESS' in log
 expected_negative_ids=set(expected_negatives)
 complete=success and set(unique)==expected_negative_ids and not findings and created==set(expected_resources)
 interleaving=reentry and len(seen)>1
 if findings:status='V070_FINDING_RECORDED_RUN_INCOMPLETE'
 elif complete and interleaving:status='V070_LIVE_ACCEPTANCE_PASS'
 elif complete:status='V070_CHECKS_COMPLETE_INTERLEAVING_NOT_OBSERVED'
 elif success:status='V070_NATIVE_SUCCESS_COVERAGE_INCOMPLETE'
 else:status='V070_NATIVE_RUN_INCOMPLETE'
 return {'version':'v070','status':status,'native_exit':exit_code,'native_success':success,'expected_negative_checks':len(expected_negative_ids),'missing_negative_case_ids':sorted(expected_negative_ids-set(unique)),'observed_unique_negative_checks':len(unique),'negative_passes':sum(bool(n.get('pass')) for n in unique.values()),'negative_findings':len(findings),'expected_resource_count':len(expected_resources),'created_resource_count':len(created),'missing_resource_ids':sorted(set(expected_resources)-created),'http_callback_count':len(events),'resource_event_reentry_observed':interleaving,'resource_switch_count':len(switches),'interleaving_scope':'ordered native HTTP callbacks from different logical resources; source audits identify independent bthreads; not proof of exhaustive schedules or simultaneous HTTP','live_execution':True},events,negatives,switches

def pack(run,result,secrets):
 write(run/'result_v070.json',result)
 files=[p for p in run.rglob('*') if p.is_file() and p.suffix!='.zip' and p.name!='manifest_v070.json' and 'products' not in p.relative_to(run).parts]
 # Only selected source/config/JSON and sanitized logs are in this tree.
 for p in files:
  if 'project' not in p.relative_to(run).parts and p.suffix in {'.json','.jsonl','.log','.txt'}:
   text=p.read_text(encoding='utf-8');p.write_text(redact(text,secrets),encoding='utf-8')
 manifest={str(p.relative_to(run)):digest(p) for p in files};write(run/'manifest_v070.json',manifest)
 with zipfile.ZipFile(run/'review_v070.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p in files+[run/'manifest_v070.json']:z.write(p,p.relative_to(run))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--study-root',type=Path,required=True);ap.add_argument('--project',type=Path,required=True);ap.add_argument('--jar',type=Path,required=True);ap.add_argument('--base-url',required=True);ap.add_argument('--username',default='SBT-tester');ap.add_argument('--seed',type=int,default=1);ap.add_argument('--timeout',type=int,default=1800);a=ap.parse_args()
 run=a.study_root/'runs'/('unified-live-v070-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True)
 result={'version':'v070','status':'V070_PREFLIGHT_NOT_ACCEPTED','live_execution':False};secrets=[];phase='preflight';native=None
 try:
  if shutil.disk_usage(a.study_root).free<2*1024**3:raise RuntimeError('At least 2 GB free space is required')
  if digest(a.jar)!=JAR_SHA:raise RuntimeError('Frozen Provengo JAR SHA256 mismatch')
  version=command(['java','-jar',str(a.jar.resolve()),'--version']);write(run/'runtime.json',{'jar_sha256':JAR_SHA,'version_output':version.strip()})
  inspect=json.loads(command(['docker','inspect','vikunja-research-sut']))[0]
  if not inspect['State']['Running']:raise RuntimeError('Vikunja container is not running; start the existing container first')
  info=json.loads(request(a.base_url.rstrip('/')+'/info'))
  if info.get('version')!='v2.6.0':raise RuntimeError('Vikunja version differs from frozen v2.6.0')
  contract=request(a.base_url.rstrip('/')+'/docs.json')
  if hashlib.sha256(contract).hexdigest()!=CONTRACT_SHA:raise RuntimeError('Live contract differs from the frozen contract')
  pinned=json.loads((ROOT/'model-v069/generated-example/MODEL_v069.json').read_text())
  for name,expected in pinned['file_sha256'].items():
   if digest(a.project/name)!=expected:raise RuntimeError('Generated model differs from accepted v069: '+name)
  if len(list(a.project.rglob('*.js')))!=3:raise RuntimeError('Expected exactly three JavaScript files in one project')
  for folder in ['spec','config']:shutil.copytree(a.project/folder,run/'project'/folder)
  shutil.copy2(a.project/'MODEL_v069.json',run/'MODEL_v069.json')
  # Direct REST base URL is pinned in the generated model.
  if a.base_url.rstrip('/')!='http://127.0.0.1:3456/api/v1':raise RuntimeError('This delivery pins the v069 base URL; regenerate and review before changing it')
  write(run/'preflight.json',{'container':'vikunja-research-sut','image':inspect['Image'],'server_version':info['version'],'contract_sha256':CONTRACT_SHA,'source_project':str(a.project.resolve()),'jar_sha256':JAR_SHA,'seed':a.seed,'one_identity_one_session':True,'model_modified':False})
  phase='authentication';password=getpass.getpass('Vikunja password for '+a.username+': ');secrets.append(password)
  token=json.loads(request(a.base_url.rstrip('/')+'/login',{'username':a.username,'password':password})).get('token')
  if not token:raise RuntimeError('Login response did not contain a token')
  secrets.append(token);password=None
  env=dict(os.environ,SBT_AUTH_TOKEN=token);phase='native';start=datetime.now(timezone.utc).isoformat();print('V070 native Provengo run started; one unified model',flush=True)
  native=subprocess.Popen(['java','-jar',str(a.jar.resolve()),'run','--random-seed',str(a.seed),str((run/'project').resolve())],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
  lines=[]
  def drain():
   with (run/'native.log').open('w',encoding='utf-8') as f:
    for line in native.stdout:
     safe=redact(line,secrets);lines.append(safe);f.write(safe);f.flush()
  reader=threading.Thread(target=drain,daemon=True);reader.start();began=time.monotonic();heartbeat=began
  while native.poll() is None:
   now=time.monotonic()
   if now-began>a.timeout:
    native.kill();native.wait();reader.join(timeout=10);raise TimeoutError('Native run exceeded configured timeout; partial log preserved')
   if now-heartbeat>=30:
    print('Native run active; completed negative evidence records:',sum('NEGATIVE_CHECK ' in x for x in lines),flush=True);heartbeat=now
   time.sleep(.25)
  reader.join(timeout=15);log=''.join(lines)
  cat=json.loads((run/'project/spec/js/negative_catalog.json').read_text());expected_neg=['NEG_'+plan['id']+'_'+str(i) for k,v in pinned['bindings'].items() for plan in v for i,_ in enumerate([c for c in cat['cases'] if c['resource']==k])]
  resources=[p['id'] for plans in pinned['bindings'].values() for p in plans]
  result,events,negatives,switches=analyze(log,native.returncode,expected_neg,resources)
  result.update({'seed':a.seed,'started_utc':start,'ended_utc':datetime.now(timezone.utc).isoformat(),'automatic_recovery':False,'completed_run_required_for_acceptance':True})
  write(run/'http-callbacks.json',events);write(run/'negative-checks.json',negatives);write(run/'resource-interleaving.json',switches)
 except Exception as e:
  result={'version':'v070','status':'V070_INFRASTRUCTURE_STOP' if phase=='native' else 'V070_PREFLIGHT_NOT_ACCEPTED','phase':phase,'error':redact(str(e),secrets),'live_execution':phase=='native','evidence_preserved':True}
 finally:
  if native and native.poll() is None:native.kill();native.wait()
  # Preserve native products locally; exclude them from the shareable review archive.
  # Runtime products can contain credentials and remain private.
  try:
   logs=subprocess.run(['docker','logs','--timestamps','--since','30m','--tail','3000','vikunja-research-sut'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30)
   (run/'server-tail.log').write_text(redact(logs.stdout+logs.stderr,secrets),encoding='utf-8')
  except Exception as e:(run/'server-log-error.txt').write_text(redact(str(e),secrets),encoding='utf-8')
  pack(run,result,secrets)
  review=run/'review_v070.zip';downloads=Path.home()/'Downloads'
  if downloads.is_dir():
   target=downloads/('Vikunja_Unified_Review_v070-'+run.name.split('v070-',1)[1]+'.zip');shutil.copy2(review,target);print('Upload this review ZIP:',target)
  print('Status:',result['status']);print('Review ZIP:',review)
  if result.get('error'):print('Error:',result['error'])
 return 0 if result['status']=='V070_LIVE_ACCEPTANCE_PASS' else 1
if __name__=='__main__':raise SystemExit(main())
