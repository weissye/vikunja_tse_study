import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
manifest=json.loads((r/'MANIFEST_v070.json').read_text())
for n,h in manifest.items():
 if hashlib.sha256((r/n).read_bytes()).hexdigest()!=h:raise SystemExit('Mismatch: '+n)
print('V070_INTEGRITY_PASS',len(manifest))
