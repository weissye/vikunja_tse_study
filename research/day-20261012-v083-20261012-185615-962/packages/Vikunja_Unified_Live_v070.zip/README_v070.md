# v070: live acceptance of the unified v069 model

One user (SBT-tester), one session, one Provengo project. The runner does not
select workflow order or execute a separate ordered campaign. Native Provengo
0.7.5-SNAPSHOT selects events in the unchanged generated v069 model.

## Preflight

Verify frozen JAR SHA256, Docker container running, server v2.6.0, exact live
contract bytes, exactly three JS files and pinned v069 source hashes. Require
2 GB free disk. The launcher requests the password after these checks.
The existing container must already be running; no reset or password change.
Authentication token is supplied via child-process environment only.

## Evidence and verdicts

Review ZIP contains sanitized native log, generated JS/config, source model
report, HTTP callback records, negative-rule evidence, resource switches,
server log tail and SHA256 manifest. Native runtime products are preserved
locally and excluded from the shareable review. No database/files snapshots
are taken or restored in v070. Research resources created by the run remain.

V070_LIVE_ACCEPTANCE_PASS requires native SUCCESS/exit 0, all 24 expected
created resources, all 612 exact expected negative case IDs passing, and
interspersed resource callback sequences (a previously seen resource returns
after another resource). This demonstrates observed resource-event interleaving,
not exhaustive schedules or true simultaneous HTTP.

A failing NEGATIVE_CHECK yields V070_FINDING_RECORDED_RUN_INCOMPLETE. It is
a candidate for analysis, not automatic confirmation of a product bug.
Other native failures, missing coverage, absent interleaving and infrastructure
stops are classified separately. The runner does not weaken verifiers.
A verifier failure terminates the native run; recovery and resumption are not
integrated. All available evidence is retained and packed.

## Validation performed here

Runner unit tests cover acceptance, findings, missing/wrong case IDs, native
failure, redaction, private product preservation and archive hashes. A mocked
complete pipeline checks 24 resources and 612 case IDs. These are local tests;
actual Docker, frozen JAR and live SUT acceptance have not been executed here.

## Work command

Run-Live-Unified-v070.ps1 -StudyRoot C:\work\temp\vikunja_tse_study
-ProjectPath C:\work\temp\vikunja_tse_study\generated\unified-v069-20261012-072518-562
-Username SBT-tester -Seed 1

Default timeout: 1800 seconds. A heartbeat prints every 30 seconds.
The review ZIP is copied to Downloads when that folder is present.
