import sys,json,tempfile,hashlib,zipfile,io
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_live_v070 as runner

def trace(resources,negatives,success=True,failed=None):
 rows=['CONTEXT_HTTP_CALLBACK '+json.dumps({'logicalId':r,'action':'create','method':'PUT','status':201}) for r in resources]
 rows+=['CONTEXT_HTTP_CALLBACK '+json.dumps({'logicalId':resources[0],'action':'verify','method':'GET','status':200})]
 rows+=['NEGATIVE_CHECK '+json.dumps({'caseId':n,'pass':n!=failed,'status':400 if n!=failed else 200}) for n in negatives]
 return '\n'.join(rows)+('\nTest Result: SUCCESS' if success else '\nTest Result: FAILURE')
resources=['A_1','B_1'];checks=['NEG_A_1_0','NEG_B_1_0']
r,*_=runner.analyze(trace(resources,checks),0,checks,resources);assert r['status']=='V070_LIVE_ACCEPTANCE_PASS'
r,*_=runner.analyze(trace(resources,checks,False,checks[0]),1,checks,resources);assert r['status']=='V070_FINDING_RECORDED_RUN_INCOMPLETE'
r,*_=runner.analyze(trace(resources,['other1','other2']),0,checks,resources);assert r['status']=='V070_NATIVE_SUCCESS_COVERAGE_INCOMPLETE'
r,*_=runner.analyze(trace(resources,checks[:1]),0,checks,resources);assert r['status']=='V070_NATIVE_SUCCESS_COVERAGE_INCOMPLETE'
r,*_=runner.analyze('Test Result: FAILURE',1,checks,resources);assert r['status']=='V070_NATIVE_RUN_INCOMPLETE'
assert 'secret_token' not in runner.redact('Authorization secret_token',['secret_token'])
with tempfile.TemporaryDirectory() as tmp:
 run=Path(tmp);(run/'project/products').mkdir(parents=True);(run/'project/products/private.db').write_bytes(b'private secret_token');(run/'native.log').write_text('secret_token');(run/'project/spec').mkdir();(run/'project/spec/model.js').write_text('Authorization: env reference')
 runner.pack(run,{'status':'test'},['secret_token'])
 assert (run/'project/products/private.db').exists()
 with zipfile.ZipFile(run/'review_v070.zip') as z:
  assert not any('products/' in n for n in z.namelist())
  assert b'secret_token' not in z.read('native.log')
  manifest=json.loads(z.read('manifest_v070.json'))
  for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print('V070_RUNNER_TEST_PASS: acceptance, finding, wrong/missing evidence, failure, redaction, private-product preservation and ZIP hashes')
# Simulated complete pipeline: actual external Java/Docker/SUT are not invoked.
from types import SimpleNamespace
pinned=json.loads((runner.ROOT/'model-v069/generated-example/MODEL_v069.json').read_text())
cat=json.loads((runner.ROOT/'model-v069/generated-example/spec/js/negative_catalog.json').read_text())
all_resources=[p['id'] for plans in pinned['bindings'].values() for p in plans]
all_checks=['NEG_'+p['id']+'_'+str(i) for name,plans in pinned['bindings'].items() for p in plans for i,_ in enumerate([c for c in cat['cases'] if c['resource']==name])]
assert len(all_resources)==24 and len(all_checks)==612
class FakeNative:
 def __init__(self,*args,**kwargs):
  self.stdout=io.StringIO(trace(all_resources,all_checks));self.returncode=0
 def poll(self):return 0
 def wait(self):return 0
 def kill(self):self.returncode=-9
with tempfile.TemporaryDirectory() as tmp:
 study=Path(tmp);jar=study/'runtime.jar';jar.write_bytes(b'mocked')
 args=['runner','--study-root',str(study),'--project',str(runner.ROOT/'model-v069/generated-example'),'--jar',str(jar),'--base-url','http://127.0.0.1:3456/api/v1']
 original_digest=runner.digest
 def mocked_digest(path):return runner.JAR_SHA if Path(path)==jar else original_digest(path)
 def mocked_command(args,timeout=30):
  if args[0]=='java':return '0.7.5-SNAPSHOT'
  return json.dumps([{'State':{'Running':True},'Image':'mock-image'}])
 def mocked_request(url,body=None):
  if url.endswith('/info'):return b'{"version":"v2.6.0"}'
  if url.endswith('/docs.json'):return (runner.ROOT/'model-v069/contract.json').read_bytes()
  return b'{"token":"mocked-auth-secret"}'
 with patch.object(sys,'argv',args),patch.object(runner,'digest',mocked_digest),patch.object(runner,'command',mocked_command),patch.object(runner,'request',mocked_request),patch.object(runner.getpass,'getpass',return_value='mocked-password'),patch.object(runner.shutil,'disk_usage',return_value=SimpleNamespace(free=10*1024**3)),patch.object(runner.subprocess,'Popen',FakeNative),patch.object(runner.subprocess,'run',return_value=SimpleNamespace(stdout='mock-server-log',stderr='')),patch.object(runner.Path,'home',return_value=study):
  assert runner.main()==0
 runs=list((study/'runs').iterdir());assert len(runs)==1
 result=json.loads((runs[0]/'result_v070.json').read_text());assert result['observed_unique_negative_checks']==612 and result['created_resource_count']==24
 assert result['status']=='V070_LIVE_ACCEPTANCE_PASS'
print('V070_SIMULATED_PIPELINE_PASS; actual native/live execution remains unperformed')
