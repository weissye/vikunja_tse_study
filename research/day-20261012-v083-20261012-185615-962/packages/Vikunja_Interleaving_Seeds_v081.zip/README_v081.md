# v081 — Additional interleavings of the accepted v080 model

Run seeds 2 and 3 separately. Fixture seed stays 1; entity scope, counts, rule selection, recovery, users, verifiers and generic source stay unchanged. All three generated JS files were compared byte-for-byte with v080 at the same proxy URL: identical. The runtime random seed is independent of fixture generation.

Each invocation creates a fresh set of research resources and runs ONE unified model in ONE Provengo JVM. The two invocations are separate experiments, not a coordinator or preselected workflow order. Provengo selects each event interleaving. Different seeds do not guarantee different traces; compare actual event sequences and normalized logical IDs after execution. Raw server IDs/timestamps will differ across fresh runs.

Expected per run: 24 lifecycle workflows, 24 creations, 15 positive updates, 39 independent lifecycle GETs, 18 negative checks/recoveries and 18 relationship observations. Two accepted runs provide two additional traces, not exhaustive schedule coverage. Known findings remain active and are preserved before rollback.

This version DOES NOT add longer per-resource histories, relation add/remove cycles, extra users, deletion or new contract operations. Those are subsequent model extensions. The bounded recovery limitations from v080 remain: negative writes only; declared affected footprints; independent observed prefix verification; no replay of ambiguous writes or positive failure recovery.

Existing local Vikunja v2.6.0 must be running; use the same frozen JAR in StudyRoot and the same isolated Docker storage. Minimum 2 GB free, with actual needs depending on snapshots. No other clients during rollback. Owner-only share creation/read remains unchanged. Link capabilities are redacted in exported evidence; private snapshots stay local.

```powershell
& .\Run-Recovery-v081.ps1 -StudyRoot 'C:\work\temp\vikunja_tse_study' -Seed 2 -RunLive
& .\Run-Recovery-v081.ps1 -StudyRoot 'C:\work\temp\vikunja_tse_study' -Seed 3 -RunLive
```

Each run requests the password and prints its own review_v081.zip path in a distinct run directory. Upload both review ZIPs. Omit -RunLive for static generation. Home uses D:\Yeshayahu\Temp\vikunja_tse_study. The launcher exposes -ProvengoJar if needed.

The review result records run_seed and fixture_seed. Generic source and JS generation tests passed locally, including explicit 3/3 v080 byte identity. Native/live runs for seeds 2/3 have not yet occurred on the build host. Preserve partial-run evidence on NOT_ACCEPTED; full coverage must be verified independently for each run.
