param(
 [string]$StudyRoot='C:\work\temp\vikunja_tse_study',
 [string]$ProvengoJar=(Join-Path $StudyRoot 'Provengo-2026-01-10.uber.jar'),
 [string]$Username='SBT-tester',
 [ValidateSet(2,3)][int]$Seed=2,
 [switch]$RunLive
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_UNIFIED_RECOVERY v081'
Get-Command python -ErrorAction Stop | Out-Null
$argsList=@((Join-Path $PSScriptRoot 'run_recovery_v081.py'),'--study-root',$StudyRoot,'--jar',$ProvengoJar,'--username',$Username,'--seed',"$Seed")
if ($RunLive) { $argsList+='--run-live' }
& python @argsList
if ($LASTEXITCODE -ne 0) { throw 'v081 acceptance incomplete. Preserve the review ZIP and private snapshots.' }
