"""One project; original renderer; runtime-selected independent bthreads."""
import argparse,json,sys,itertools,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source'))
from generator_v56.parsing.swagger_context import normalize_context_contract
from generator_v56.render.context_model import build_model,generate_context_model
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--instances',type=int,choices=range(1,9),default=3)
parser.add_argument('--seed',type=int,default=1)
parser.add_argument('--base-url',default='http://127.0.0.1:3456/api/v1')
a=parser.parse_args()
if a.output.exists():raise SystemExit('Use a new output directory')
scope=json.loads((root/'SCOPE_v069.json').read_text())
raw=json.loads((root/'contract.json').read_text());spec,_=normalize_context_contract(raw)
c,entities=build_model(spec,scope['resources'],a.instances,a.seed)
from generator_v56.render.unified_instances import build_instance_plans
plans=build_instance_plans(entities,a.instances)
generate_context_model(root/'contract.json',a.output/'spec/js','vikunja',a.base_url,scope['resources'],a.instances,a.seed,negative_schema=True,method_adapter=root/'method_adapter.json',instance_plans=plans)
report={'version':'v069','status':'UNIFIED_GENERATED_NOT_NATIVE_EXECUTED','project_count':1,'context_count':1,'instances_per_independent_entity':a.instances,'instance_counts':{k:len(v) for k,v in plans.items()},'bindings':plans,'resources':scope['resources'],'unsupported_candidates':scope['unsupported_candidates'],'all_contract_operations_covered':False,'negative_scheduling':'independent bthread per rule per instance; eligible after verified creation; no before-update gate','scheduling':'Provengo event selection; no ordered campaign steps','prefix':'runtime event history; no fixed length claim','native_execution':False,'live_execution':False,'actor_scope':'single identity; multi-user integration not yet included','original_renderer':'generator_v56 with source-level v069 changes','known_limits':['A verifier failure still ends the native run; automatic recovery is not integrated in this delivery','8 supported resource families, not all 170 operations','Per-resource oracle isolation restricts writes during a negative observation window']}
(a.output/'MODEL_v069.json').write_text(json.dumps(report,indent=2))
files=list((a.output/'spec/js').glob('*.js'));assert len(files)==3
report['file_sha256']={str(p.relative_to(a.output)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(a.output/'MODEL_v069.json').write_text(json.dumps(report,indent=2))
print('V069_UNIFIED_STATIC_READY: one project, one Context, three JS files')
print('Entity counts:',report['instance_counts'])
