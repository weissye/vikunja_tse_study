import sys,json,itertools
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source'))
from generator_v56.render.unified_instances import build_instance_plans
example=root/'generated-example'
files=list(example.rglob('*.js'));assert len(files)==3
stories=(example/'spec/js/stories.vikunja.js').read_text()
assert stories.count('bthread("lifecycle ')==24
assert 'SHARED_PLAN' not in stories and 'NegativeLifecycleComplete' not in stories
assert not any(example.glob('family-*'))
assert '/__actor/' not in (example/'spec/js/interfaces.vikunja.js').read_text()
entities=[{'name':'Loan','dependencies':[{'target':'Reader'},{'target':'Book'}]},{'name':'Book','dependencies':[]},{'name':'Reader','dependencies':[]}]
plans=build_instance_plans(entities,3)
assert len(plans['Loan'])==9
assert {tuple(sorted(p['bindings'].items())) for p in plans['Loan']}=={tuple(sorted({'Book':'Book_'+str(b),'Reader':'Reader_'+str(r)}.items())) for b,r in itertools.product(range(1,4),repeat=2)}
print('V069_STRUCTURE_PASS: one project, three JS, independent stories, 9 unique parent tuples')
