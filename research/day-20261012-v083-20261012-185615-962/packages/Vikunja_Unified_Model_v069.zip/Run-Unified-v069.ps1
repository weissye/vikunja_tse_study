param(
 [string]$StudyRoot='C:\work\temp\vikunja_tse_study',
 [ValidateRange(1,8)][int]$InstancesPerEntity=3,
 [int]$Seed=1,
 [string]$BaseUrl='http://127.0.0.1:3456/api/v1'
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_UNIFIED_MODEL v069'
& python (Join-Path $PSScriptRoot 'Verify-v069.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
$output=Join-Path $StudyRoot ('generated\unified-v069-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
& python (Join-Path $PSScriptRoot 'Generate-Unified-v069.py') --output $output --instances $InstancesPerEntity --seed $Seed --base-url $BaseUrl
if ($LASTEXITCODE -ne 0) {throw 'Unified generation failed.'}
Write-Host "One Provengo project: $output"
Write-Host "All three JS files: $(Join-Path $output 'spec\js')"
Write-Host 'Static generation completed; native/live acceptance has not yet been performed.'
