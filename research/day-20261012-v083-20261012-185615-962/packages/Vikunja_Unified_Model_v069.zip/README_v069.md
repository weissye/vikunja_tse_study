# Unified model v069

One Provengo project, one Context, exactly three generated JavaScript files:
`spec/js/stories.vikunja.js`, `spec/js/interfaces.vikunja.js`, `spec/js/dal.js`.

The generator sources are included. No generated file is manually edited.
No family-xx projects and no ordered scenario coordinator.

## Scope

Eight supported resource families: projects, tasks, labels, saved filters,
project shares, project views, task comments and teams. Three independent
instances per entity by default. A dependent instance is emitted per tuple
of parent instances. This is not all operations or all relationships. The 15
blocked creation candidates and reasons are retained in SCOPE_v069.json.

The current frozen Vikunja model has only single-parent creation dependencies.
The generic two-parent planner was tested independently: 3 books and 3 readers
produce 9 unique child bindings. This test does not assert library loan semantics.
Dependencies check current Context and wait for any relevant verification;
parent readiness order is irrelevant. Cyclic creation dependencies stop with
an explicit error; later optional links require separate process templates.

## Scheduling

24 lifecycle bthreads, 612 independent negative-rule bthreads, 8 resource
verifier templates, 8 negative verifier templates and resource-local constraints.
Provengo chooses requested, unblocked events. No generator-selected global
order. Negatives are enabled after verified creation and may run before or
after updates; each has its own bthread, rather than a sorted per-resource loop.
Before/attempt/readback negative windows isolate writes to that resource only.
Other resources and workflows remain enabled. Prefix is the actual preceding
event history, not the instance count or a prescribed depth.

## Limits and validation

This is static generation. All three JS files passed Node syntax checks; a
clean rebuild produced identical bytes. Generic dependency readiness tests
passed both parent orders and already-present parents. This is not native
Provengo execution or live SUT acceptance. The runtime must stay at the frozen
0.7.5-SNAPSHOT JAR until compatibility is tested. A native verifier failure
still ends the run; checkpoint/recovery integration is not part of v069.
Single identity only; multi-session and multi-user workflows remain to integrate.
The contract-derived negative rules test inputs, not undocumented permissions.

## Work generation

Run Run-Unified-v069.ps1 -StudyRoot C:\work\temp\vikunja_tse_study
-InstancesPerEntity 3 -Seed 1. The launcher prints the single project path.
No Docker modifications, credentials or live requests occur during generation.
Every JS file and the instance bindings are also included in generated-example.
