# v077 — Unified model with views and task comments

This delivery extends the live-accepted v076 model to five types, three instances each: projects, tasks, labels, project views and task comments. It emits one project with three JS files (Stories, Interfaces, DAL). Provengo selects the interleaving of independent bthreads; the transport never sequences workflows or replays the prefix.

## Expected live coverage

15 lifecycle bthreads: 15 creations, 12 positive updates and 27 independent lifecycle GETs. Comments have creation/readback only: update is not modeled by the existing generator. Task -> Project, View -> Project and Comment -> Task contribute nine dependency links and a depth-two Project -> Task -> Comment chain.

The six label and six task negative checks remain: TYPE_ARRAY and MIN_LENGTH. There are no newly selected negative rules for views/comments in this bounded delivery. The empty-title finding is retained as a failed original oracle, followed by the same verified recovery mechanism. It is not excluded or given a bug-specific generator branch. Recovery from failed positive creation/update/deletion is still not implemented.

Relationship audit requires six Task/Project observations, six View/Project observations and three Comment/Task observations. The contract supplies no `task_id` property on comments: their observation uses the exact nested GET path under the bound task and the returned comment ID. This is weaker than a second independent API representation of membership and is explicitly reported as such.

## Generic nested-route defect discovered during expansion

The old parser selected the FIRST parameter in an item path, confusing a parent's ID with the item's own ID. Old generated view/comment GET paths retained unresolved child placeholders. v077 corrects the generic `context_model.py` implementation:

- Use the final item-path parameter as the conventional item locator, for this supported nested-route pattern.
- Retain parent runtime route locators when a child is created.
- Resolve both parent and child parameters in subsequent positive GET/update routes.

No entity-specific name or known-finding exception is added to this logic. Unsupported/ambiguous route patterns still require separate analysis; the final-parameter convention is not a universal proof for every API topology.

The runtime gateway now derives parent route values from the actual collection creation URI and substitutes the item's own response locator in its registered detail route. It rejects unresolved placeholders. Node tests execute the actual generated callback and verify parent=101 / child=501 for both nested types.

This is an intentional generic implementation correction, unlike v076's unchanged-source scope extension. All other generic source files remain byte-identical to v075. v069/v073 DAL and Stories byte identity is retained; their nested Interfaces intentionally change to correct the defective paths. The exact historical three-JS identity claim is NOT made for those nested reference models. The emitter itself still accepts only contract IR and research configuration.

Nested negative interfaces beyond the selected Task/Label rules are not claimed accepted in this delivery. Full eight-entity coverage, multiple users, deletion and all contract operations remain future work.

## External configuration and fixtures

`input-source/acceptance-plan-v077.json` defines scope, instances, selected rule IDs, relationship observation mappings and the selected view update field. Preprocessing builds `contract-ir.json` and `research-config.json`; only these two files are read by the generic emitter. The plan is a research adapter input, not a third emitter input.

View creation includes `view_kind`, generated from the contract enum (list). View updates use title, explicitly selected in external data instead of the earlier default enum-valued bucket-configuration field. These fixture/update choices are visible research configuration, not claimed automatic semantic discovery. The generated JS is never manually edited.

## Recovery and environment

The v075/v076 mechanism is retained: cold snapshot immediately before each negative write, original mutation response and independent original post-write GET recorded, rollback with strict supported storage metadata/content checks, and whole observed prefix equality after restart. Same JVM/pending bthreads and expected Context are preserved for the supported negative-update protocol. Missing observation remains INCONCLUSIVE; failed rollback blocks continuation. Ambiguous writes are not retried.

Authentication is probed after restarts and renewed only when invalid. Logs close before manifest/ZIP creation. Private database/files snapshots remain local and are excluded from reviews. Use an isolated research SUT with no other clients during rollback; it covers full configured storage. Process memory/clocks/external services and unobserved API resources are not claimed restored.

Frozen local Vikunja v2.6.0: `http://127.0.0.1:3456/api/v1`, container `vikunja-research-sut`. Contract SHA256 `171e238314089ca9b1c5c6fa3f87cf7f80a7c2a55934d1d6c228b39d48b65843`; JAR SHA256 `dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b`. Minimum free disk 2 GB, with actual snapshot needs depending on storage size.

Work binds must match `<StudyRoot>/deployment/state/db` and `files`. Home supports the existing exclusive named volumes and cached helper container `vikunja-increment8-2-files-init`. Mixed/shared storage and links are rejected. Original server must be running. Bind metadata coverage excludes ACL/creation time/Linux ownership.

```powershell
& .\Run-Recovery-v077.ps1 -StudyRoot 'C:\work\temp\vikunja_tse_study' -Username 'SBT-tester' -RunLive
```

For Home use `D:\Yeshayahu\Temp\vikunja_tse_study`. JAR defaults to `<StudyRoot>/Provengo-2026-01-10.uber.jar`; `-ProvengoJar` overrides it. Omit `-RunLive` for static generation. This creates new resources and a new run; original v076 evidence remains unchanged.

## Verification

Local tests passed: preserved findings, strict recovery protocol with fake storage/SUT, ambiguous write/no retry, failed observations, expired authentication renewal, wrong relationship/path refusal, real subprocess log closure, generated JS syntax and executed nested route callbacks. The example is in `example/project/spec/js`; its proxy port is illustrative. Live runs regenerate with the active proxy port.

No native/live run has occurred on the build host. `V077_STATIC_READY` is only generation. `V077_RECOVERY_ACCEPTANCE_COMPLETED_WITH_FINDINGS` requires complete expected coverage, verified restorations and continuation after a retained finding. Inconclusive semantic checks are separately reported. `NOT_ACCEPTED` means preserve the printed review ZIP and private snapshots, and do not count symbolic later selections as live coverage.
