# v076 — Dependent entities in the unified recovery model

## Scope and handling of the known finding

The accepted v075 recovery mechanism is retained. The label empty-title rule is NOT removed, disabled, rewritten as a pass, or handled by an application-specific branch. It remains an ordinary contract-derived negative bthread. If the original response/state violates the rule, its `NEGATIVE_CHECK` remains `pass: false`. The generic recovery transport cold-saves the current prefix, retains original response and failed-state evidence, restores storage, independently verifies the observed resource prefix, and then permits continuation in the same native JVM. An unavailable original observation remains INCONCLUSIVE; failed restoration blocks continuation.

No file under `source/` was changed from v075. `GENERIC_SOURCE_SHA256_v075.json` records those hashes and the test verifies every one. The added model scope, instances, selected rule IDs and acceptance relationship observation mapping are external data in `input-source/acceptance-plan-v076.json`. The preprocessing stage produces `contract-ir.json` and `research-config.json`. These remain the emitter's only two inputs. The emitter does not read the original OpenAPI or the acceptance plan.

The acceptance runner is a research/environment adapter, separate from the generic emitter. It derives expected resources, updates and negative case IDs from the generated instance bindings, selected rules and entity reports. A small external observation mapping for `ModelsTask.project_id` is retained in IR metadata for audit. This mapping reflects the existing generator's expected-body mapping and is checked against the selected schema; it is not claimed as newly inferred semantic knowledge.

## One project, three JS files

- Three projects, three tasks, three labels: nine lifecycle bthreads.
- Each lifecycle creates its resource, waits for independent Context verification, updates its description and waits for independent verification again.
- Each task waits for its bound project in Context. Task_1 -> Project_1, Task_2 -> Project_2, Task_3 -> Project_3. These are THREE parent links, not nine task/project combinations.
- Independent GET verifiers check each task's `project_id` against the selected parent's runtime ID after creation and update. The runner cross-checks these six actual GET responses against the creation URL and parent identity.
- Two selected title rules per task and per label (TYPE_ARRAY and MIN_LENGTH): twelve independent negative bthreads, plus Context verifiers and resource-local isolation blockers.
- Nine successful creations, nine positive updates, eighteen independent lifecycle GETs, twelve selected negative checks and twelve verified recoveries are required for technical acceptance, plus the six parent-relation observations.

The original generator creates all bthreads. Provengo chooses their event interleaving during execution. The recovery transport neither schedules workflows nor replays the prefix. It performs recovery work within a selected negative REST action. No global scenario coordinator or family-by-family execution is introduced.

This remains one user/one session. Task-label relations, multiple users, simultaneous requests, all eight original entity types and recovery from positive create/delete failures are not part of this delivery. Dependencies with multiple distinct parent types and order independence remain in the existing generic source; this one-parent acceptance does not demonstrate every multi-parent case.

## Recovery boundaries / evidence

The existing DAL does not commit negative writes into expected resource state. Restoring persistent SUT state returns it to the existing Context expectation, and the generated verifier independently checks the stored projection. The JVM remains alive, keeping suspended bthreads and runtime variables; this is not JVM-stack serialization or recovery from arbitrary Context mutations.

Snapshots cover the configured SQLite/files storage, with strict supported content/metadata equality before restart. Full API views of all resources created in this acceptance are compared before and after each recovery. Other resources, external systems, process memory and clocks are not claimed to be API-equivalent. Use the isolated research SUT without other clients during rollback.

The password is requested once. Authentication is checked after cold saves/restores and renewed only when invalid. Actual mutation responses and post-write GET responses are recorded before interpretation. A timed-out mutation is not retried: rollback is attempted and verified before stopping with ambiguity. An observation failure can continue only after verified rollback, retaining INCONCLUSIVE evidence.

The review ZIP contains both generated inputs, all three JS files, native log, gateway journal, recovery ledger, relationship audit, result and SHA256 manifest. Private storage snapshots remain in the run directory and are not included. Evidence is packed only after the native process and log writer close.

## Environment and launch

Frozen local server: Vikunja v2.6.0 at `http://127.0.0.1:3456/api/v1`, existing container `vikunja-research-sut`.

Frozen contract SHA256: `171e238314089ca9b1c5c6fa3f87cf7f80a7c2a55934d1d6c228b39d48b65843`.

Frozen Provengo 0.7.5-SNAPSHOT JAR SHA256: `dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b`.

At least 2 GB free space is required; actual snapshot size depends on existing storage. The original server must already be running. Exclusive named volumes (Home) use the existing helper container `vikunja-increment8-2-files-init`. Work bind paths must match `<StudyRoot>/deployment/state/db` and `files`. Mixed/shared/overlapping mounts and links are rejected. Bind metadata scope covers Windows mode and exact mtime; ACLs/creation times/Linux ownership are outside that adapter's scope.

Work:

```powershell
& .\Run-Recovery-v076.ps1 -StudyRoot 'C:\work\temp\vikunja_tse_study' -Username 'SBT-tester' -RunLive
```

Home:

```powershell
& .\Run-Recovery-v076.ps1 -StudyRoot 'D:\Yeshayahu\Temp\vikunja_tse_study' -Username 'SBT-tester' -RunLive
```

Omit `-RunLive` for static generation only. `-ProvengoJar` overrides the default `<StudyRoot>/Provengo-2026-01-10.uber.jar`. Every launch creates a NEW acceptance run/resources; it does not resume v075. Existing v075 evidence stays untouched.

Generated example JS: `example/project/spec/js`. Its loopback proxy URL is only illustrative. Live execution regenerates the same model with the active local proxy port.

## Verification and status interpretation

Local tests exercise actual generated verifier code, fake storage/SUT recovery, invalid authentication renewal, unavailable observation, unsafe restoration, ambiguous write and real subprocess/log closure. Added tests verify nine lifecycles, twelve negative bthreads, task parent waits, the generated task relationship verifier and refusal of an incorrect project ID by the acceptance audit. Every generic source file is byte-identical to v075; v069 and v073 compatibility with recovery disabled also passes.

These are local tests, not native/live acceptance. The build host has no frozen JAR or SUT.

`V076_STATIC_READY`: generation only.

`V076_RECOVERY_ACCEPTANCE_COMPLETED_WITH_FINDINGS`: all selected recovery/coverage criteria completed, an original finding retained and a later negative test completed in the same JVM. Any INCONCLUSIVE semantic checks are explicitly listed separately; this status is not a claim that all oracle checks passed.

`V076_COMPLETE_NO_FINDING_CONTINUATION_NOT_PROVEN`: tests completed but continuation after a finding was not demonstrated.

`NOT_ACCEPTED`: preserve the review ZIP and local private snapshots. Partial completion is not full coverage.
