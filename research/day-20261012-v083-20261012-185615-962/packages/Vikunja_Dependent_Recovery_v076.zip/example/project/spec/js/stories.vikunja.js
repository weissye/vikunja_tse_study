// Generated stories: explicit entity instances; Context-driven verification.
// HTTP paths and request bodies are confined to interfaces.
ctx.bthread("protectWriteAndReadback", "WriteLock.All", function(lock) {
    sync({block:matchesConflictingWrites(lock.logicalId,lock.owner),waitFor:matchesVerified(lock.logicalId,lock.revision)});
});
ctx.bthread("protectPendingVerification", "Verification.Pending", function(resource) {
    sync({block:matchesMutations(resource.id),waitFor:matchesVerified(resource.id,resource.revision)});
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyModelsProjectAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="ModelsProject") return;
    verifyModelsProject(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance ModelsProject_1: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsProject_1", function() {
    var parents=waitForDependencies([],{});
    createModelsProject("ModelsProject_1",{"title":"sbt-1-ModelsProject-1-title"},parents);
    waitFor(matchesVerified("ModelsProject_1",1));
    updateModelsProject(getModelEntity("ModelsProject_1"),{"description":"sbt-1-ModelsProject_1-updated"});
    waitFor(matchesVerified("ModelsProject_1",2));
});

// Instance ModelsProject_2: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsProject_2", function() {
    var parents=waitForDependencies([],{});
    createModelsProject("ModelsProject_2",{"title":"sbt-1-ModelsProject-2-title"},parents);
    waitFor(matchesVerified("ModelsProject_2",1));
    updateModelsProject(getModelEntity("ModelsProject_2"),{"description":"sbt-1-ModelsProject_2-updated"});
    waitFor(matchesVerified("ModelsProject_2",2));
});

// Instance ModelsProject_3: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsProject_3", function() {
    var parents=waitForDependencies([],{});
    createModelsProject("ModelsProject_3",{"title":"sbt-1-ModelsProject-3-title"},parents);
    waitFor(matchesVerified("ModelsProject_3",1));
    updateModelsProject(getModelEntity("ModelsProject_3"),{"description":"sbt-1-ModelsProject_3-updated"});
    waitFor(matchesVerified("ModelsProject_3",2));
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyModelsTaskAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="ModelsTask") return;
    verifyModelsTask(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance ModelsTask_1: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsTask_1", function() {
    var parents=waitForDependencies(["ModelsProject"],{"ModelsProject":"ModelsProject_1"});
    createModelsTask("ModelsTask_1",{"title":"sbt-1-ModelsTask-1-title"},parents);
    waitFor(matchesVerified("ModelsTask_1",1));
    updateModelsTask(getModelEntity("ModelsTask_1"),{"description":"sbt-1-ModelsTask_1-updated"});
    waitFor(matchesVerified("ModelsTask_1",2));
});

// Instance ModelsTask_2: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsTask_2", function() {
    var parents=waitForDependencies(["ModelsProject"],{"ModelsProject":"ModelsProject_2"});
    createModelsTask("ModelsTask_2",{"title":"sbt-1-ModelsTask-2-title"},parents);
    waitFor(matchesVerified("ModelsTask_2",1));
    updateModelsTask(getModelEntity("ModelsTask_2"),{"description":"sbt-1-ModelsTask_2-updated"});
    waitFor(matchesVerified("ModelsTask_2",2));
});

// Instance ModelsTask_3: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsTask_3", function() {
    var parents=waitForDependencies(["ModelsProject"],{"ModelsProject":"ModelsProject_3"});
    createModelsTask("ModelsTask_3",{"title":"sbt-1-ModelsTask-3-title"},parents);
    waitFor(matchesVerified("ModelsTask_3",1));
    updateModelsTask(getModelEntity("ModelsTask_3"),{"description":"sbt-1-ModelsTask_3-updated"});
    waitFor(matchesVerified("ModelsTask_3",2));
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyModelsLabelAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="ModelsLabel") return;
    verifyModelsLabel(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance ModelsLabel_1: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsLabel_1", function() {
    var parents=waitForDependencies([],{});
    createModelsLabel("ModelsLabel_1",{"title":"sbt-1-ModelsLabel-1-title"},parents);
    waitFor(matchesVerified("ModelsLabel_1",1));
    updateModelsLabel(getModelEntity("ModelsLabel_1"),{"description":"sbt-1-ModelsLabel_1-updated"});
    waitFor(matchesVerified("ModelsLabel_1",2));
});

// Instance ModelsLabel_2: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsLabel_2", function() {
    var parents=waitForDependencies([],{});
    createModelsLabel("ModelsLabel_2",{"title":"sbt-1-ModelsLabel-2-title"},parents);
    waitFor(matchesVerified("ModelsLabel_2",1));
    updateModelsLabel(getModelEntity("ModelsLabel_2"),{"description":"sbt-1-ModelsLabel_2-updated"});
    waitFor(matchesVerified("ModelsLabel_2",2));
});

// Instance ModelsLabel_3: creation, independent readback, update, independent readback.
bthread("lifecycle ModelsLabel_3", function() {
    var parents=waitForDependencies([],{});
    createModelsLabel("ModelsLabel_3",{"title":"sbt-1-ModelsLabel-3-title"},parents);
    waitFor(matchesVerified("ModelsLabel_3",1));
    updateModelsLabel(getModelEntity("ModelsLabel_3"),{"description":"sbt-1-ModelsLabel_3-updated"});
    waitFor(matchesVerified("ModelsLabel_3",2));
});
bthread("initialize negative Context rules",function(){request(bp.Event("NegativeCatalogReady",{rules:[{"id":"ModelsTask/title/TYPE_ARRAY","resource":"ModelsTask","field":"title","kind":"TYPE_ARRAY","mutation":"replace","invalid_value":[],"constraint":"type","declared_constraint":"string","source_pointer":"#/definitions/models.Task/properties/title/type","schema_pointer":"#/components/schemas/models.Task/properties/title/type","operation":"POST /tasks/{id}","effective_operation":"POST /tasks/{id}","documented_statuses":["200","400","403","500"],"compound_constraints":[]},{"id":"ModelsTask/title/MIN_LENGTH","resource":"ModelsTask","field":"title","kind":"MIN_LENGTH","mutation":"replace","invalid_value":"","constraint":"minLength","declared_constraint":1,"source_pointer":"#/definitions/models.Task/properties/title/minLength","schema_pointer":"#/components/schemas/models.Task/properties/title/minLength","operation":"POST /tasks/{id}","effective_operation":"POST /tasks/{id}","documented_statuses":["200","400","403","500"],"compound_constraints":[]},{"id":"ModelsLabel/title/TYPE_ARRAY","resource":"ModelsLabel","field":"title","kind":"TYPE_ARRAY","mutation":"replace","invalid_value":[],"constraint":"type","declared_constraint":"string","source_pointer":"#/definitions/models.Label/properties/title/type","schema_pointer":"#/components/schemas/models.Label/properties/title/type","operation":"PUT /labels/{id}","effective_operation":"POST /labels/{id}","documented_statuses":["200","400","403","404","500"],"compound_constraints":[]},{"id":"ModelsLabel/title/MIN_LENGTH","resource":"ModelsLabel","field":"title","kind":"MIN_LENGTH","mutation":"replace","invalid_value":"","constraint":"minLength","declared_constraint":1,"source_pointer":"#/definitions/models.Label/properties/title/minLength","schema_pointer":"#/components/schemas/models.Label/properties/title/minLength","operation":"PUT /labels/{id}","effective_operation":"POST /labels/{id}","documented_statuses":["200","400","403","404","500"],"compound_constraints":[]}]}));});
ctx.bthread("negative verifier ModelsTask","Negative.Pending",function(pending){if(pending.resourceType!=="ModelsTask")return;verifyNegativeModelsTask(pending);request(bp.Event("NegativeVerified",{caseId:pending.caseId}));});
bthread("negative NEG_ModelsTask_1_0",function(){
    waitForResource("ModelsTask_1",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsTask_1",caseId:"NEG_ModelsTask_1_0"}));
    attemptNegativeModelsTask(getModelEntity("ModelsTask_1"),{"id":"ModelsTask/title/TYPE_ARRAY","resource":"ModelsTask","field":"title","kind":"TYPE_ARRAY","mutation":"replace","invalid_value":[],"constraint":"type","declared_constraint":"string","source_pointer":"#/definitions/models.Task/properties/title/type","schema_pointer":"#/components/schemas/models.Task/properties/title/type","operation":"POST /tasks/{id}","effective_operation":"POST /tasks/{id}","documented_statuses":["200","400","403","500"],"compound_constraints":[]},"NEG_ModelsTask_1_0");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsTask_1",caseId:"NEG_ModelsTask_1_0"}));
});
bthread("negative NEG_ModelsTask_1_1",function(){
    waitForResource("ModelsTask_1",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsTask_1",caseId:"NEG_ModelsTask_1_1"}));
    attemptNegativeModelsTask(getModelEntity("ModelsTask_1"),{"id":"ModelsTask/title/MIN_LENGTH","resource":"ModelsTask","field":"title","kind":"MIN_LENGTH","mutation":"replace","invalid_value":"","constraint":"minLength","declared_constraint":1,"source_pointer":"#/definitions/models.Task/properties/title/minLength","schema_pointer":"#/components/schemas/models.Task/properties/title/minLength","operation":"POST /tasks/{id}","effective_operation":"POST /tasks/{id}","documented_statuses":["200","400","403","500"],"compound_constraints":[]},"NEG_ModelsTask_1_1");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsTask_1",caseId:"NEG_ModelsTask_1_1"}));
});
bthread("negative NEG_ModelsTask_2_0",function(){
    waitForResource("ModelsTask_2",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsTask_2",caseId:"NEG_ModelsTask_2_0"}));
    attemptNegativeModelsTask(getModelEntity("ModelsTask_2"),{"id":"ModelsTask/title/TYPE_ARRAY","resource":"ModelsTask","field":"title","kind":"TYPE_ARRAY","mutation":"replace","invalid_value":[],"constraint":"type","declared_constraint":"string","source_pointer":"#/definitions/models.Task/properties/title/type","schema_pointer":"#/components/schemas/models.Task/properties/title/type","operation":"POST /tasks/{id}","effective_operation":"POST /tasks/{id}","documented_statuses":["200","400","403","500"],"compound_constraints":[]},"NEG_ModelsTask_2_0");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsTask_2",caseId:"NEG_ModelsTask_2_0"}));
});
bthread("negative NEG_ModelsTask_2_1",function(){
    waitForResource("ModelsTask_2",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsTask_2",caseId:"NEG_ModelsTask_2_1"}));
    attemptNegativeModelsTask(getModelEntity("ModelsTask_2"),{"id":"ModelsTask/title/MIN_LENGTH","resource":"ModelsTask","field":"title","kind":"MIN_LENGTH","mutation":"replace","invalid_value":"","constraint":"minLength","declared_constraint":1,"source_pointer":"#/definitions/models.Task/properties/title/minLength","schema_pointer":"#/components/schemas/models.Task/properties/title/minLength","operation":"POST /tasks/{id}","effective_operation":"POST /tasks/{id}","documented_statuses":["200","400","403","500"],"compound_constraints":[]},"NEG_ModelsTask_2_1");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsTask_2",caseId:"NEG_ModelsTask_2_1"}));
});
bthread("negative NEG_ModelsTask_3_0",function(){
    waitForResource("ModelsTask_3",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsTask_3",caseId:"NEG_ModelsTask_3_0"}));
    attemptNegativeModelsTask(getModelEntity("ModelsTask_3"),{"id":"ModelsTask/title/TYPE_ARRAY","resource":"ModelsTask","field":"title","kind":"TYPE_ARRAY","mutation":"replace","invalid_value":[],"constraint":"type","declared_constraint":"string","source_pointer":"#/definitions/models.Task/properties/title/type","schema_pointer":"#/components/schemas/models.Task/properties/title/type","operation":"POST /tasks/{id}","effective_operation":"POST /tasks/{id}","documented_statuses":["200","400","403","500"],"compound_constraints":[]},"NEG_ModelsTask_3_0");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsTask_3",caseId:"NEG_ModelsTask_3_0"}));
});
bthread("negative NEG_ModelsTask_3_1",function(){
    waitForResource("ModelsTask_3",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsTask_3",caseId:"NEG_ModelsTask_3_1"}));
    attemptNegativeModelsTask(getModelEntity("ModelsTask_3"),{"id":"ModelsTask/title/MIN_LENGTH","resource":"ModelsTask","field":"title","kind":"MIN_LENGTH","mutation":"replace","invalid_value":"","constraint":"minLength","declared_constraint":1,"source_pointer":"#/definitions/models.Task/properties/title/minLength","schema_pointer":"#/components/schemas/models.Task/properties/title/minLength","operation":"POST /tasks/{id}","effective_operation":"POST /tasks/{id}","documented_statuses":["200","400","403","500"],"compound_constraints":[]},"NEG_ModelsTask_3_1");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsTask_3",caseId:"NEG_ModelsTask_3_1"}));
});
ctx.bthread("negative verifier ModelsLabel","Negative.Pending",function(pending){if(pending.resourceType!=="ModelsLabel")return;verifyNegativeModelsLabel(pending);request(bp.Event("NegativeVerified",{caseId:pending.caseId}));});
bthread("negative NEG_ModelsLabel_1_0",function(){
    waitForResource("ModelsLabel_1",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsLabel_1",caseId:"NEG_ModelsLabel_1_0"}));
    attemptNegativeModelsLabel(getModelEntity("ModelsLabel_1"),{"id":"ModelsLabel/title/TYPE_ARRAY","resource":"ModelsLabel","field":"title","kind":"TYPE_ARRAY","mutation":"replace","invalid_value":[],"constraint":"type","declared_constraint":"string","source_pointer":"#/definitions/models.Label/properties/title/type","schema_pointer":"#/components/schemas/models.Label/properties/title/type","operation":"PUT /labels/{id}","effective_operation":"POST /labels/{id}","documented_statuses":["200","400","403","404","500"],"compound_constraints":[]},"NEG_ModelsLabel_1_0");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsLabel_1",caseId:"NEG_ModelsLabel_1_0"}));
});
bthread("negative NEG_ModelsLabel_1_1",function(){
    waitForResource("ModelsLabel_1",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsLabel_1",caseId:"NEG_ModelsLabel_1_1"}));
    attemptNegativeModelsLabel(getModelEntity("ModelsLabel_1"),{"id":"ModelsLabel/title/MIN_LENGTH","resource":"ModelsLabel","field":"title","kind":"MIN_LENGTH","mutation":"replace","invalid_value":"","constraint":"minLength","declared_constraint":1,"source_pointer":"#/definitions/models.Label/properties/title/minLength","schema_pointer":"#/components/schemas/models.Label/properties/title/minLength","operation":"PUT /labels/{id}","effective_operation":"POST /labels/{id}","documented_statuses":["200","400","403","404","500"],"compound_constraints":[]},"NEG_ModelsLabel_1_1");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsLabel_1",caseId:"NEG_ModelsLabel_1_1"}));
});
bthread("negative NEG_ModelsLabel_2_0",function(){
    waitForResource("ModelsLabel_2",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsLabel_2",caseId:"NEG_ModelsLabel_2_0"}));
    attemptNegativeModelsLabel(getModelEntity("ModelsLabel_2"),{"id":"ModelsLabel/title/TYPE_ARRAY","resource":"ModelsLabel","field":"title","kind":"TYPE_ARRAY","mutation":"replace","invalid_value":[],"constraint":"type","declared_constraint":"string","source_pointer":"#/definitions/models.Label/properties/title/type","schema_pointer":"#/components/schemas/models.Label/properties/title/type","operation":"PUT /labels/{id}","effective_operation":"POST /labels/{id}","documented_statuses":["200","400","403","404","500"],"compound_constraints":[]},"NEG_ModelsLabel_2_0");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsLabel_2",caseId:"NEG_ModelsLabel_2_0"}));
});
bthread("negative NEG_ModelsLabel_2_1",function(){
    waitForResource("ModelsLabel_2",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsLabel_2",caseId:"NEG_ModelsLabel_2_1"}));
    attemptNegativeModelsLabel(getModelEntity("ModelsLabel_2"),{"id":"ModelsLabel/title/MIN_LENGTH","resource":"ModelsLabel","field":"title","kind":"MIN_LENGTH","mutation":"replace","invalid_value":"","constraint":"minLength","declared_constraint":1,"source_pointer":"#/definitions/models.Label/properties/title/minLength","schema_pointer":"#/components/schemas/models.Label/properties/title/minLength","operation":"PUT /labels/{id}","effective_operation":"POST /labels/{id}","documented_statuses":["200","400","403","404","500"],"compound_constraints":[]},"NEG_ModelsLabel_2_1");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsLabel_2",caseId:"NEG_ModelsLabel_2_1"}));
});
bthread("negative NEG_ModelsLabel_3_0",function(){
    waitForResource("ModelsLabel_3",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsLabel_3",caseId:"NEG_ModelsLabel_3_0"}));
    attemptNegativeModelsLabel(getModelEntity("ModelsLabel_3"),{"id":"ModelsLabel/title/TYPE_ARRAY","resource":"ModelsLabel","field":"title","kind":"TYPE_ARRAY","mutation":"replace","invalid_value":[],"constraint":"type","declared_constraint":"string","source_pointer":"#/definitions/models.Label/properties/title/type","schema_pointer":"#/components/schemas/models.Label/properties/title/type","operation":"PUT /labels/{id}","effective_operation":"POST /labels/{id}","documented_statuses":["200","400","403","404","500"],"compound_constraints":[]},"NEG_ModelsLabel_3_0");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsLabel_3",caseId:"NEG_ModelsLabel_3_0"}));
});
bthread("negative NEG_ModelsLabel_3_1",function(){
    waitForResource("ModelsLabel_3",1);
    request(bp.Event("NegativeAcquire",{logicalId:"ModelsLabel_3",caseId:"NEG_ModelsLabel_3_1"}));
    attemptNegativeModelsLabel(getModelEntity("ModelsLabel_3"),{"id":"ModelsLabel/title/MIN_LENGTH","resource":"ModelsLabel","field":"title","kind":"MIN_LENGTH","mutation":"replace","invalid_value":"","constraint":"minLength","declared_constraint":1,"source_pointer":"#/definitions/models.Label/properties/title/minLength","schema_pointer":"#/components/schemas/models.Label/properties/title/minLength","operation":"PUT /labels/{id}","effective_operation":"POST /labels/{id}","documented_statuses":["200","400","403","404","500"],"compound_constraints":[]},"NEG_ModelsLabel_3_1");
    request(bp.Event("NegativeRelease",{logicalId:"ModelsLabel_3",caseId:"NEG_ModelsLabel_3_1"}));
});

// v069: resource-local oracle isolation; independent resources remain enabled.
bthread("resource-local negative observation isolation",function(){
    var positives={},negatives={};
    while(true){
        var event=sync({waitFor:bp.all,block:bp.EventSet("resource-local observation conflicts",function(e){
            var d=e.data||{};
            if(e.name==="NegativeAcquire")return !!positives[d.logicalId]||!!negatives[d.logicalId];
            if(e.name==="ModelWriteBegin")return !!negatives[d.logicalId];
            var m=d.model;
            return !!m && !!negatives[m.logicalId] && (m.action==="create"||m.action==="update");
        })});
        var data=event.data||{};
        if(event.name==="ModelWriteBegin")positives[data.logicalId]=data.revision;
        if(event.name==="ModelVerified" && positives[data.logicalId]===data.revision)delete positives[data.logicalId];
        if(event.name==="NegativeAcquire")negatives[data.logicalId]=data.caseId;
        if(event.name==="NegativeRelease" && negatives[data.logicalId]===data.caseId)delete negatives[data.logicalId];
    }
});
