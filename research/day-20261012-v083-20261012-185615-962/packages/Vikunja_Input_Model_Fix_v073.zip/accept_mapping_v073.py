"""Independent positive-input acceptance; not a full model campaign."""
import argparse,getpass,hashlib,json,re,subprocess,sys,urllib.request,urllib.error,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'source'))
from generator_v56.render.context_model import Contract
SHA='171e238314089ca9b1c5c6fa3f87cf7f80a7c2a55934d1d6c228b39d48b65843'
def write(path,value):path.write_text(json.dumps(value,indent=2),encoding='utf-8')
def http(url,method='GET',body=None,token=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request(url,method=method,headers=headers,data=json.dumps(body).encode() if body is not None else None)
 try:
  with urllib.request.urlopen(req,timeout=15) as r:return r.status,r.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
def build_case(ir,cfg,rule,project):
 e=next(e for e in ir['entities'] if e['path']==rule['path'] and e['create_method']==rule['method'].lower())
 if e['dependencies']:raise ValueError('This input acceptance needs a validated dependency fixture; no IDs are fabricated')
 if e['identity_mode']!='object':raise ValueError('Unsupported acceptance identity mode')
 c=Contract(ir['document']);body={r['field']:c.value(r['schema'],r['salt_template'].format(seed=cfg['fixtures']['seed'])) for r in ir['fixture_recipes'][e['name']]}
 body=json.loads(json.dumps(body).replace('INSTANCE','1'))
 stories=(project/'spec/js'/('stories.'+cfg['model']['name']+'.js')).read_text()
 call='create'+e['name']+'("'+e['name']+'_1",'+json.dumps(body,separators=(',',':'))+',parents);'
 if call not in stories:raise ValueError('Acceptance fixture differs from actual generated model')
 return e,c,body

def projection_matches(actual,expected):
 if isinstance(expected,dict):return isinstance(actual,dict) and all(k in actual and projection_matches(actual[k],v) for k,v in expected.items())
 if isinstance(expected,list):return isinstance(actual,list) and len(actual)==len(expected) and all(projection_matches(a,b) for a,b in zip(actual,expected))
 return actual==expected

def main():
 p=argparse.ArgumentParser();p.add_argument('--study-root',type=Path,required=True);p.add_argument('--ir',type=Path,required=True);p.add_argument('--research-config',type=Path,required=True);p.add_argument('--project',type=Path,required=True);p.add_argument('--username',default='SBT-tester');a=p.parse_args()
 run=a.study_root/'runs'/('mapping-v073-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True);records=[];result={'version':'v073','status':'V073_PREFLIGHT_NOT_ACCEPTED','full_model_execution':False,'native_execution':False};token=None
 try:
  ir=json.loads(a.ir.read_text());cfg=json.loads(a.research_config.read_text());base=cfg['model']['base_url'].rstrip('/')
  if base!='http://127.0.0.1:3456/api/v1':raise ValueError('Acceptance is pinned to the configured local study server')
  raw=subprocess.run(['docker','inspect','vikunja-research-sut'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30)
  if raw.returncode or not json.loads(raw.stdout)[0]['State']['Running']:raise ValueError('Existing Vikunja container is not running')
  status,body=http(base+'/info')
  if status!=200 or json.loads(body).get('version')!='v2.6.0':raise ValueError('Frozen server version mismatch')
  status,body=http(base+'/docs.json')
  if status!=200 or hashlib.sha256(body).hexdigest()!=SHA or ir['source']['sha256']!=SHA:raise ValueError('Frozen live contract mismatch')
  cases=[build_case(ir,cfg,rule,a.project) for rule in ir['request_mappings']['rules']]
  password=getpass.getpass('Vikunja password for '+a.username+': ')
  status,body=http(base+'/login','POST',{'username':a.username,'password':password});password=None
  if status!=200:raise ValueError('Login rejected with HTTP '+str(status))
  token=json.loads(body).get('token')
  if not token:raise ValueError('Login token missing')
  for e,c,fixture in cases:
   status,raw=http(base+e['path'],e['create_method'].upper(),fixture,token)
   try:created=json.loads(raw)
   except json.JSONDecodeError:created={'response_not_json':True}
   records.append({'stage':'create','method':e['create_method'].upper(),'path':e['path'],'body':fixture,'status':status,'response':created})
   if status not in c.response(e['create'])[0]:raise ValueError('Mapped creation rejected with HTTP '+str(status))
   identity=created.get(e['route_field']);resource_id=created.get('id')
   if identity is None or resource_id is None:raise ValueError('Created resource identity missing')
   detail=e['detail'].replace('{'+e['parameter']+'}',str(identity))
   status,raw=http(base+detail,token=token);observed=json.loads(raw)
   checks={'http_success':status in c.response(e['get'])[0],'same_id':observed.get('id')==resource_id,'request_projection_matches':projection_matches(observed,fixture)}
   records.append({'stage':'independent_readback','method':'GET','path':detail,'status':status,'response':observed,'checks':checks})
   if not all(checks.values()):raise ValueError('Independent mapped-resource readback mismatch')
  result.update(status='V073_REQUEST_MAPPING_LIVE_ACCEPTED',mapping_cases=len(cases),live_execution=True,request_and_model_fixture_equal=True,created_resource_ids=[r['response'].get('id') for r in records if r['stage']=='create'],resource_cleanup=False)
 except Exception as e:
  result.update(status='V073_REQUEST_MAPPING_REJECTED' if records else 'V073_PREFLIGHT_NOT_ACCEPTED',error=str(e),live_execution=bool(records))
 finally:
  # Password/token/login responses never enter persisted evidence.
  write(run/'result_v073.json',result);write(run/'http-evidence.json',records)
  write(run/'input_hashes.json',{'ir_sha256':hashlib.sha256(a.ir.read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(a.research_config.read_bytes()).hexdigest()})
  files=[f for f in run.iterdir() if f.is_file()];manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files};write(run/'manifest_v073.json',manifest)
  with zipfile.ZipFile(run/'review_v073.zip','w',zipfile.ZIP_DEFLATED) as z:
   for f in files+[run/'manifest_v073.json']:z.write(f,f.name)
  print('Status:',result['status']);print('Review ZIP:',run/'review_v073.zip')
  if result.get('error'):print('Error:',result['error'])
 return 0 if result['status']=='V073_REQUEST_MAPPING_LIVE_ACCEPTED' else 1
if __name__=='__main__':raise SystemExit(main())
