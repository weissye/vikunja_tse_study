param(
 [string]$StudyRoot='C:\work\temp\vikunja_tse_study',
 [string]$Username='SBT-tester',
 [switch]$RunLive
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_INPUT_AND_MODEL_FIX v073'
& python (Join-Path $PSScriptRoot 'Verify-v073.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
& python (Join-Path $PSScriptRoot 'Test-Mapping-v073.py')
if ($LASTEXITCODE -ne 0) {throw 'Mapping/model tests failed.'}
$workspace=Join-Path $StudyRoot ('generated\mapping-v073-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
$inputs=Join-Path $workspace 'inputs'
& python (Join-Path $PSScriptRoot 'Build-Inputs-v073.py') `
 --contract (Join-Path $PSScriptRoot 'input-source\contract.json') `
 --scope (Join-Path $PSScriptRoot 'input-source\SCOPE_v069.json') `
 --adapter (Join-Path $PSScriptRoot 'input-source\method_adapter.json') `
 --request-mappings (Join-Path $PSScriptRoot 'input-source\request-mappings-v073.json') `
 --output $inputs --instances 3 --seed 1 --name vikunja `
 --base-url 'http://127.0.0.1:3456/api/v1'
if ($LASTEXITCODE -ne 0) {throw 'Mapped IR construction failed.'}
$project=Join-Path $workspace 'project'
& python (Join-Path $PSScriptRoot 'Generate-Generic-v073.py') `
 --ir (Join-Path $inputs 'contract-ir.json') `
 --research-config (Join-Path $inputs 'research-config.json') --output $project
if ($LASTEXITCODE -ne 0) {throw 'Mapped model generation failed.'}
Write-Host "Corrected unified model: $project"
Write-Host 'One project / three JS files / 24 lifecycle bthreads.'
if ($RunLive) {
 & python (Join-Path $PSScriptRoot 'accept_mapping_v073.py') `
  --study-root $StudyRoot --ir (Join-Path $inputs 'contract-ir.json') `
  --research-config (Join-Path $inputs 'research-config.json') `
  --project $project --username $Username
 if ($LASTEXITCODE -ne 0) {throw 'Live input mapping acceptance incomplete; preserve the review ZIP.'}
} else {
 Write-Host 'V073_STATIC_MAPPING_READY; live input acceptance not performed.'
}
Write-Host 'Full native model execution and fail recovery are not part of this focused acceptance.'
