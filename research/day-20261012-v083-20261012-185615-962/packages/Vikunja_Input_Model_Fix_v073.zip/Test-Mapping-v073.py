import sys,json,tempfile,copy,subprocess,shutil,re
from pathlib import Path
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'source'))
from input_pipeline import compile_ir,research_config
from generic_emitter import emit
src=root/'input-source'
with tempfile.TemporaryDirectory() as temp:
 tmp=Path(temp);old=compile_ir(src/'contract.json',src/'SCOPE_v069.json',src/'method_adapter.json')
 new=compile_ir(src/'contract.json',src/'SCOPE_v069.json',src/'method_adapter.json',src/'request-mappings-v073.json')
 assert len(old['issues'])==1 and new['issues']==[]
 changed=[]
 for a,b in zip(old['entities'],new['entities']):
  if a!=b:changed.append(a['name'])
 assert changed==['ModelsSavedFilter']
 cfg=research_config(name='vikunja');ip=tmp/'ir.json';cp=tmp/'research.json';ip.write_text(json.dumps(new));cp.write_text(json.dumps(cfg));emit(ip,cp,tmp/'new')
 stories=(tmp/'new/spec/js/stories.vikunja.js').read_text()
 for i in range(1,4):assert 'createModelsSavedFilter("ModelsSavedFilter_'+str(i)+'",{"title":"sbt-1-ModelsSavedFilter-'+str(i)+'-title","filters":{"filter":"done = false"}},parents);' in stories
 assert stories.count('bthread("lifecycle ')==24
 iface=(tmp/'new/spec/js/interfaces.vikunja.js').read_text();assert 'function verifyModelsSavedFilter(resource)' in iface
 # Legacy/no-overlay path must still reproduce v069 exactly.
 ip.write_text(json.dumps(old));emit(ip,cp,tmp/'old')
 for p in (root/'reference-v069').glob('*.js'):assert p.read_bytes()==(tmp/'old/spec/js'/p.name).read_bytes()
 assert (tmp/'new/spec/js/dal.js').read_bytes()==(tmp/'old/spec/js/dal.js').read_bytes()
 # Strict missing-information policy accepts mapped IR and rejects unmapped IR.
 cfg['missing_information']['policy']='block';cp.write_text(json.dumps(cfg));ip.write_text(json.dumps(new));emit(ip,cp,tmp/'strict-new')
 ip.write_text(json.dumps(old))
 try:emit(ip,cp,tmp/'strict-old')
 except ValueError:pass
 else:raise AssertionError('Unmapped input should be blocked')
 if shutil.which('node'):
  for p in (tmp/'new/spec/js').glob('*.js'):subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
 import hashlib
 assert hashlib.sha256((root/'source/generic_emitter.py').read_bytes()).hexdigest()==json.loads((root/'CORE_COMPATIBILITY.json').read_text())['generic_emitter_sha256']
 print(json.dumps({'version':'v073','status':'MAPPING_MODEL_STATIC_PASS','changed_resource_types':changed,'saved_filter_fixtures_corrected':3,'lifecycle_bthreads':24,'no_overlay_v069_byte_identity':'PASS_3_OF_3','dal_byte_identity':'PASS','strict_policy':'PASS','generic_emitter_unchanged':True,'native_execution':False,'live_execution':False},indent=2))
