# v073 - saved-filter request corrected using live v072 evidence

The v072 review is valid: all its manifest hashes match. PUT /filters sent a
nonempty title, and the server returned HTTP 412 / code 2002 with the explicit
message `filters: non zero value required`. Thus title-only creation is not
valid. This is a failed positive fixture hypothesis, not evidence of a semantic
server bug. v072's status incorrectly said preflight after a live rejection;
v073 classifies that case as V073_REQUEST_MAPPING_REJECTED.

The external upstream mapping now includes both required title and filters.
The latter uses a documented simple fixture `{ "filter": "done = false" }`.
The original contract, generic emitter and renderer remain unchanged. The
mapping retains contract pointers, live rejection evidence and documentation
provenance. The fixture default is explicit external research input, not an
invented universal contract constraint.

The regenerated unified model has one project, three JS files, 24 lifecycle
bthreads and corrected fixtures/expected projections for all three SavedFilters.
No JS file is manually edited. Static tests and simulated input acceptance pass;
actual live acceptance still must be performed on the local server.

The acceptance helper checks the actual generated first fixture and performs
one create plus independent GET. It checks status, ID, title and filters.filter.
Extra server-owned fields in filters are allowed, consistently with the native
request-projection verifier; a changed/missing requested query still fails.
The created filter remains on the server. A review ZIP records request, response
and checks. Authentication responses and secrets are not persisted.

Run-Mapping-v073.ps1 -RunLive asks for the password after preflight and performs
this focused positive-input acceptance. It does not execute the full unified
Provengo campaign. No fail recovery is implemented here. The next stage is the
verified outcome/recovery/continuation mechanism in the unified model.
