import sys,json,tempfile
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root))
import accept_mapping_v072 as accept
ir=json.loads((root/'inputs/contract-ir.json').read_text());cfg=json.loads((root/'inputs/research-config.json').read_text())
e,c,body=accept.build_case(ir,cfg,ir['request_mappings']['rules'][0],root/'generated-example');assert body=={'title':'sbt-1-ModelsSavedFilter-1-title'}
with tempfile.TemporaryDirectory() as tmp:
 study=Path(tmp);args=['accept','--study-root',str(study),'--ir',str(root/'inputs/contract-ir.json'),'--research-config',str(root/'inputs/research-config.json'),'--project',str(root/'generated-example')]
 def mock_http(url,method='GET',body=None,token=None):
  if url.endswith('/info'):return 200,b'{"version":"v2.6.0"}'
  if url.endswith('/docs.json'):return 200,(root/'input-source/contract.json').read_bytes()
  if url.endswith('/login'):return 200,b'{"token":"test-token"}'
  if method=='PUT':return 201,json.dumps({'id':101,**body}).encode()
  return 200,json.dumps({'id':101,'title':'sbt-1-ModelsSavedFilter-1-title'}).encode()
 with patch.object(sys,'argv',args),patch.object(accept,'http',mock_http),patch.object(accept.getpass,'getpass',return_value='test-password'),patch.object(accept.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='[{"State":{"Running":true}}]')):
  assert accept.main()==0
 for p in study.rglob('*.json'):
  assert 'test-password' not in p.read_text() and 'test-token' not in p.read_text()
print('V072_SIMULATED_ACCEPTANCE_PASS; actual live server acceptance remains unperformed here')
