# v072 - fix the saved-filter input mapping and generated model

The generic emitter is byte-identical to v071. The existing renderer and DAL
behavior are unchanged. The correction is an explicit external request mapping
processed before contract facts are compiled into the IR.

## What was corrected

The frozen contract lacks a request-body schema for PUT /filters. v069 emitted
{} as a positive fixture and expected 201. v070 observed 412 and native test-fail
mode suppressed all later actuation. This is a generation/input gap, not proof
of a semantic server defect.

input-source/request-mappings-v072.json binds the missing create body to an
explicit minimal object with required nonempty title. Its source SHA256, response
field constraint pointer, documentation source and live validation requirement
are retained as provenance. It is not presented as a request schema declared in
the original contract or as automatically inferred solely from OpenAPI.

The upstream compiler applies the mapping in memory; the original contract file
is unchanged. The resulting IR generates three SavedFilter creation fixtures
with valid nonempty titles and request-derived expected Context projections.
The ordinary resource verifier then checks ID and title by independent GET.
There are still 24 lifecycle bthreads, one shared Context and three JS files.
No generated JS is hand-edited. Input policy is now strict: remaining unresolved
create input schemas would block generation instead of silently becoming {}.

## Validation

Static checks prove only SavedFilter compiled entity facts changed; all three
SavedFilter fixtures contain the expected titles; DAL is byte-identical; emission
without the external mapping still reproduces v069 3/3; strict missing-input
policy rejects the unmapped baseline; the three generated JS files pass syntax
checks. A mocked acceptance test verifies create/readback reporting and absence
of login secrets in persisted JSON. This is not live/native acceptance.

## Work usage

Run-Mapping-v072.ps1 performs static construction/tests.
Run-Mapping-v072.ps1 -RunLive also asks for the password and performs independent
positive-input acceptance against the frozen local Vikunja server. The fixture
must exactly match the first fixture in the actual generated model. One saved
filter is created and read back; it remains on the server. The result is
V072_REQUEST_MAPPING_LIVE_ACCEPTED only if status, identity and title checks pass.
The review ZIP contains functional HTTP evidence, input hashes and manifest.

This focused acceptance uses Python HTTP calls; it does not execute the full
unified model or claim Provengo interleaving coverage. No extra family project
or external workflow scheduler is introduced into the model.

## Remaining work

Fail-recovery/continuation is not integrated here. Context commits conditional
on real outcomes, recovery of bthread stages and reconciliation after partially
successful writes require the next implementation/acceptance stage. v072 fixes
the specific bad fixture and its generated expectation; it does not solve all
possible runtime divergences or prove all eight families pass live execution.
