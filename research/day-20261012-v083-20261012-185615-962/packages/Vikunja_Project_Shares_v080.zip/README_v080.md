# v080 — Project link shares in the unified model

Base: live-accepted v079. All generic source files remain byte-identical to v079, checked by `GENERIC_SOURCE_SHA256_v079.json`. The upstream acceptance plan adds `/projects/{project}/shares`, three instances and a relationship observation mapping. The original emitter still reads only the generated contract IR and research configuration.

## Expected scope / acceptance

Eight selected types, three instances each: Project, Task, Label, ProjectView, TaskComment, Team, SavedFilter, LinkSharing. One Provengo project / three JS files, 24 lifecycle bthreads. Expected 24 creations, 15 positive updates, 39 independent lifecycle GETs, 18 selected negative checks and verified recoveries, plus 18 relationship observations.

Link shares, comments and saved filters have creation/readback only. No link-share update, deletion, invalid-input test, anonymous link authentication, permission-behavior oracle or cross-user access attempt is added. Three owner-created shares are independently read by the same owner. `permission: 0` is tested as a request-derived stored value, not proof of effective read-only access for another identity. This completes the eight originally selected model types, NOT all contract entities/actions/relations.

All workflows are independent bthreads; Provengo chooses their interleaving. Generic footprint blockers isolate observation windows while disjoint writes remain enabled. Original empty-title findings remain enabled and retain failed verdicts. No application-specific exception hides a finding.

## Validated mapping and external fixture choice

The frozen contract declares `/projects/{project}/shares/{share}` with integer Project ID and Share ID. Creation returns an object with integer `id` and a distinct public `hash`. Owner detail GET uses `id`, not `hash`. The existing nested-route logic retains the parent's locator separately and uses the child's returned ID.

The old automatically selected fixture field was `created`, described by the contract as a server-managed timestamp that cannot be changed. v080's EXTERNAL `fixture_fields_override` instead selects `name` and `permission`; the generic emitter generates values from their schemas. The permission schema defaults to 0. This is an explicit researcher-controlled field selection, not claimed automatically inferred read-only metadata or a kernel change. The original response/request schemas remain available in IR.

The existing saved-filter request mapping from v073 remains in preprocessing. All other field/update/rule choices remain v079. Source-generated JS is never hand edited.

LinkSharing has no `project_id` property in its response. Parent membership is audited using its exact nested owner GET path and returned stable share identity. This is not a second independent representation of membership. Project/Task/View/Comment audits remain enabled.

## Capability redaction in review evidence

The share `hash` can be a capability used by a link client. Sensitive response field names are external IR metadata. The runtime discovers these values at successful creation and redacts them in native logs and exported request/response evidence. It does not replace responses sent to the model or values used in actual SUT comparisons.

Recovery compares the original unredacted API views internally. Exported prefix objects redact capabilities; their exported SHA256 fingerprints are recomputed over the redacted projection. Both original comparison hashes are retained separately as `unredacted_prefix_*_sha256` without exposing values. Tests verify equality/fingerprints on the export and that actual owner response/route identities are unchanged. No password is supplied in the share fixture. Private database/files snapshots remain local and outside the review ZIP.

This runtime export adaptation is generic and driven by IR field metadata; the generic generator source is unchanged. Link hashes are not used to authenticate any request in this model.

## Recovery and environment

The live-accepted negative-write recovery mechanism remains: cold save immediately before each selected negative write, original response and independent post-write GET retained, verified rollback, unchanged JVM/pending bthreads, and continuation only after strict supported storage/API equality. Missing observations remain INCONCLUSIVE; unsafe restoration blocks. Ambiguous writes are not replayed. Positive create/update/delete failure recovery remains unsupported.

Frozen local server: Vikunja v2.6.0 at `http://127.0.0.1:3456/api/v1`, existing container `vikunja-research-sut`. Contract SHA256 `171e238314089ca9b1c5c6fa3f87cf7f80a7c2a55934d1d6c228b39d48b65843`; JAR SHA256 `dda4be276ff517faa06b942d587cad2d342c66d83c9959f7eb3c6c77a8b2fc2b`. Minimum free disk 2 GB; actual snapshot needs depend on existing storage. Original server must be running. Use the isolated research SUT with no other clients during whole-storage rollback.

Work uses exclusive diagnosed binds `<StudyRoot>/deployment/state/db` and `files`; Home uses exclusive named volumes and the existing helper container `vikunja-increment8-2-files-init`. Mixed/shared/overlapping mounts and links are rejected. Bind metadata excludes ACL/creation times/Linux ownership; clocks/process memory/external services/unobserved API state are outside the restoration claim.

```powershell
& .\Run-Recovery-v080.ps1 -StudyRoot 'C:\work\temp\vikunja_tse_study' -Username 'SBT-tester' -RunLive
```

Home: use `D:\Yeshayahu\Temp\vikunja_tse_study`. The JAR defaults to `<StudyRoot>/Provengo-2026-01-10.uber.jar`, overridden with `-ProvengoJar`. Omit `-RunLive` for static generation. This creates new resources and a new run; v079 evidence remains untouched.

Review ZIP includes both inputs, three JS files, native log, journal, recovery ledger, relationship audit, result and manifest. Private snapshots remain local. Logs close before sealing evidence. Example JS is under `example/project/spec/js`; its proxy URL is illustrative.

## Verification

Local tests passed: unchanged generic source hashes, 24 lifecycle/18 negative bthreads, omission of server-managed created fixture, nested parent/item locator resolution, actual share verifier rejecting wrong identity, gateway capability redaction and exported fingerprint verification, saved-filter projection, footprint isolation, relationship rejection, recovery/authentication/observation/log-closure tests. These are not native/live acceptance; the frozen JAR/SUT are unavailable on the build host.

`V080_STATIC_READY`: generation only.

`V080_RECOVERY_ACCEPTANCE_COMPLETED_WITH_FINDINGS`: complete expected coverage and verified recovery, with a retained original finding and a later negative test completed in the same JVM. Any INCONCLUSIVE semantic checks are separately reported.

`NOT_ACCEPTED`: preserve the printed review ZIP/private snapshots. Do not count symbolic events after a failure as live execution.
