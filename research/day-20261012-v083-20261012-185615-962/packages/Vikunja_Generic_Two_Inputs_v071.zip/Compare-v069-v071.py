import argparse,json,hashlib,shutil
from pathlib import Path
r=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--require-identical',action='store_true');a=p.parse_args()
checks={f.name:(a.project/'spec/js'/f.name).is_file() and f.read_bytes()==(a.project/'spec/js'/f.name).read_bytes() for f in (r/'reference').glob('*.js')}
result={'version':'v071','v069_js_byte_identical':all(checks.values()),'files':checks}
(a.project/'COMPATIBILITY_v069.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
if all(checks.values()):
 shutil.copy2(r/'reference/MODEL_v069.json',a.project/'MODEL_v069.json')
 print('V071_V069_BYTE_IDENTICAL_PASS 3/3; legacy report compatibility retained')
else:
 print('V071_OUTPUT_DIFFERS_FROM_V069',checks)
 if a.require_identical:raise SystemExit(1)
