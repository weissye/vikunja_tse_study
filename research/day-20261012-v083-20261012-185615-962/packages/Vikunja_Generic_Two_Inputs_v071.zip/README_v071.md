# v071 - generic two-input generation and backward compatibility

This delivery separates contract compilation from generic emission. It preserves
the v069 baseline exactly. It does not repair the failed filter fixture, change
verifier behavior or integrate fail recovery. No native or live run occurs here.

## Pipeline

1. `Build-Inputs-v071.py` takes a contract, an explicit scope selection and an
   optional evidence-backed method adapter. It normalizes and compiles contract
   facts into `contract-ir.json`. It separately builds `research-config.json`
   from external research settings. The builder may read the original contract.
2. `Generate-Generic-v071.py` takes only those two files and an output destination.
   It never opens the original contract, scope or adapter files, and never calls
   the original contract normalizer or resource-inference function.
3. One project is emitted, with `spec/js/stories.vikunja.js`,
   `spec/js/interfaces.vikunja.js` and `spec/js/dal.js` for this configured name.
   Native Provengo selects interleaving. There is no external story scheduler.

The emitter name is generic. `vikunja`, paths and local address belong to the
sample input/configuration and the study wrapper, not a target-specific branch
in the new emitter. The IR contains 8 compiled resource types, 16 scoped routes
and the 25 schemas required by their transitive reference closure. Operation
structures, compiled entity facts, fixture recipes, negative-rule catalog,
authentication facts, source pointers and inference provenance are retained.
Reference schemas are not silently treated as ownership relationships.

The supplied label method adapter is an externally evidenced mapping; it is
explicitly recorded in the IR and is not claimed to have been inferred solely
from OpenAPI. The scope is researcher-selected. Instance counts and fixture seed
are absent from contract compilation; fixture values are evaluated by emission
using recipes plus the research configuration.

## Supported research controls now

- Model output name and base URL rendering binding. The URL is retained here to
  preserve the exact v069 JS; secrets and actual user credentials are excluded.
- Default instance count 1..8 and independent-entity overrides.
- Dependent entities get one instance per parent-instance tuple, matching v069.
  A dependent override must equal the derived count or it is rejected.
- Fixture seed, negative-schema enable/disable, unified or historical renderer.
- Explicit maximum instance budget and optional event limit. A null event limit
  retains the baseline derived budget; it does not mean unlimited execution.
- Metadata experiment ID, missing-schema policy, one user/one session marker.

Unsupported users/sessions, recovery policies and unknown configuration fields
are rejected. General workflow repetition, extra negative families and more
identity profiles are not silently accepted: these remain future work.

## Known unresolved input and compatibility policy

`ModelsSavedFilter` has no declared creation request schema in the frozen
contract. It is explicitly marked `UNRESOLVED_POSITIVE_INPUT` in the IR. The
provided configuration selects `preserve_baseline_with_warnings` so that the
three JS files remain byte-identical to v069, including its known bad `{}`
fixture. Setting the policy to `block` rejects generation before output creation.
This is deliberate compatibility staging, not a claim that the fixture is valid.
Do not run the baseline live again expecting the v070 failure to be fixed.

## Validation scope

- v069: 3/3 JS files byte-identical.
- v064 and v068: 48/48 historical JS files byte-identical across 16 reference
  projects, using the explicit `legacy_context` compatibility profile.
- Isolated emission works with source code and the two inputs only; no original
  contract, scope selection or method-adapter file is present.
- Guarded tests confirm that emission does not invoke contract recompilation.
- Per-entity configuration changes the dependent binding counts as declared.
- Known missing input, unknown keys, unsupported actors and unsupported recovery
  are rejected when their policies demand it.
- All three baseline generated JS files pass Node syntax checks.
- The 53 original v069 generator source files are byte-identical to the previous
  delivery. Its original CLI remains available for old workflows.

Backward compatibility is proven for these available golden references. It is
not a claim that every historical Mealie/contribution/actor/checkpoint workflow
has been ported to the new two-input interface or tested against a live server.
The reference projects inside `compatibility-reference/` are test data, not a
new split of the generated model. The actual output has one project only.

## Work commands

`Run-Generic-v071.ps1 -StudyRoot C:\work\temp\vikunja_tse_study`

This builds fresh copies of both inputs, emits the baseline, compares all three
JS files to v069, and prints the input and project locations. On exact match it
also writes the legacy `MODEL_v069.json` report for launcher compatibility.
It performs static work only.

To edit research controls, copy/edit the generated configuration outside the
verified package, then supply both external input paths:

`Run-Generic-v071.ps1 -IrPath <contract-ir.json> -ResearchConfigPath <research-config.json>`

Changes to controls may intentionally change JS output. The script reports the
comparison without treating every intended change as a compatibility failure.
`Test-Compatibility-v071.py` executes the reproducible compatibility checks.

## Next stage

With separation and byte identity frozen, the next change can address the
unresolved positive input and the verified fail/recovery/continuation protocol,
while retaining the unified model and independent bthreads. That change must
have its own acceptance evidence and version.
