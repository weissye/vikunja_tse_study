param(
 [string]$StudyRoot='C:\work\temp\vikunja_tse_study',
 [string]$IrPath='',
 [string]$ResearchConfigPath=''
)
$ErrorActionPreference='Stop'
Write-Host 'VIKUNJA_GENERIC_TWO_INPUTS v071 - compatibility stage'
& python (Join-Path $PSScriptRoot 'Verify-v071.py')
if ($LASTEXITCODE -ne 0) {throw 'Package integrity failed.'}
$workspace=Join-Path $StudyRoot ('generated\generic-v071-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
$baseline=([string]::IsNullOrWhiteSpace($IrPath) -and [string]::IsNullOrWhiteSpace($ResearchConfigPath))
if (-not $baseline -and ([string]::IsNullOrWhiteSpace($IrPath) -or [string]::IsNullOrWhiteSpace($ResearchConfigPath))) {throw 'Supply both input file paths.'}
if ($baseline) {
 & python (Join-Path $PSScriptRoot 'Build-Inputs-v071.py') `
  --contract (Join-Path $PSScriptRoot 'input-source\contract.json') `
  --scope (Join-Path $PSScriptRoot 'input-source\SCOPE_v069.json') `
  --adapter (Join-Path $PSScriptRoot 'input-source\method_adapter.json') `
  --output (Join-Path $workspace 'inputs') --instances 3 --seed 1 `
  --name vikunja --base-url 'http://127.0.0.1:3456/api/v1'
 if ($LASTEXITCODE -ne 0) {throw 'Input compilation failed.'}
 $IrPath=Join-Path $workspace 'inputs\contract-ir.json'
 $ResearchConfigPath=Join-Path $workspace 'inputs\research-config.json'
}
$project=Join-Path $workspace 'project'
& python (Join-Path $PSScriptRoot 'Generate-Generic-v071.py') --ir $IrPath --research-config $ResearchConfigPath --output $project
if ($LASTEXITCODE -ne 0) {throw 'Generic generation failed.'}
if ($baseline) {
 & python (Join-Path $PSScriptRoot 'Compare-v069-v071.py') --project $project --require-identical
} else {
 & python (Join-Path $PSScriptRoot 'Compare-v069-v071.py') --project $project
}
if ($LASTEXITCODE -ne 0) {throw 'Baseline compatibility verification failed.'}
Write-Host "Contract IR: $IrPath"
Write-Host "Research configuration: $ResearchConfigPath"
Write-Host "ONE project / THREE JS files: $(Join-Path $project 'spec\js')"
Write-Host 'STATIC COMPATIBILITY ONLY. Known v069 fixture/recovery defects are intentionally unchanged.'
