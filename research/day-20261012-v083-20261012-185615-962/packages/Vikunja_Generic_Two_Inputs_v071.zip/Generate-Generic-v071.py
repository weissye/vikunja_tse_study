import argparse,sys
from pathlib import Path
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'source'))
from generic_emitter import emit
p=argparse.ArgumentParser();p.add_argument('--ir',type=Path,required=True);p.add_argument('--research-config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
r=emit(a.ir,a.research_config,a.output)
print('V071_IR_ONLY_GENERATION_COMPLETE:',a.output);print('JS files:',len(r['file_sha256']));print('Contract files read by emitter: 0');print('Warnings:',len(r['warnings']))
