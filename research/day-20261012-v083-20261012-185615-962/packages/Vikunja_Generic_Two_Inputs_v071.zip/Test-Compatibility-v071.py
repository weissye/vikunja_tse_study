"""Byte identity, legacy golden references and isolated two-file generation."""
import sys,json,tempfile,hashlib,shutil,copy,subprocess
from pathlib import Path
from unittest.mock import patch
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'source'))
from input_pipeline import compile_ir,research_config
from generic_emitter import emit
checks=[]
with tempfile.TemporaryDirectory() as temp:
 tmp=Path(temp);out=tmp/'unified'
 emit(root/'inputs/contract-ir.json',root/'inputs/research-config.json',out)
 for p in (root/'reference').glob('*.js'):assert p.read_bytes()==(out/'spec/js'/p.name).read_bytes(),p.name
 checks.append({'check':'v069 byte identity','js_files':3,'status':'PASS'})
 cases=json.loads((root/'compatibility-reference/cases.json').read_text());count=0
 for index,(key,case) in enumerate(cases.items()):
  ir=compile_ir(root/'input-source/contract.json',{'resources':case['resources']},root/'input-source/method_adapter.json')
  cfg=research_config(case['instances'],case['seed'],'legacy_context','vikunja','http://127.0.0.1:3456/api/v1')
  ip=tmp/('ir'+str(index)+'.json');cp=tmp/('cfg'+str(index)+'.json');ip.write_text(json.dumps(ir));cp.write_text(json.dumps(cfg));target=tmp/('legacy'+str(index));emit(ip,cp,target)
  for filename in case['files']:
   assert (root/'compatibility-reference'/key/filename).read_bytes()==(target/'spec/js'/filename).read_bytes(),(key,filename)
   count+=1
 checks.append({'check':'v064/v068 historical JS','projects':len(cases),'js_files':count,'status':'PASS'})
 # Remove all contract/scope sources from the execution environment. The only
 # JSON reads allowed by the emitter are its two explicit input files.
 isolated=tmp/'isolated';isolated.mkdir();shutil.copytree(root/'source',isolated/'source');shutil.copy2(root/'Generate-Generic-v071.py',isolated/'Generate-Generic-v071.py')
 for n in ['contract-ir.json','research-config.json']:shutil.copy2(root/'inputs'/n,isolated/n)
 assert not list(isolated.rglob('contract.json')) and not list(isolated.rglob('SCOPE*.json'))
 subprocess.run([sys.executable,str(isolated/'Generate-Generic-v071.py'),'--ir',str(isolated/'contract-ir.json'),'--research-config',str(isolated/'research-config.json'),'--output',str(isolated/'result')],cwd=isolated,check=True,capture_output=True)
 for p in (root/'reference').glob('*.js'):assert p.read_bytes()==(isolated/'result/spec/js'/p.name).read_bytes()
 checks.append({'check':'isolated generation without original contract or scope','status':'PASS'})
 # Prove the emitter never calls the original contract compilation/inference.
 with patch('input_pipeline.build_model',side_effect=AssertionError('contract compilation is forbidden in emitter')),patch('input_pipeline.normalize_context_contract',side_effect=AssertionError('normalization is forbidden in emitter')):
  emit(root/'inputs/contract-ir.json',root/'inputs/research-config.json',tmp/'no-compilation')
 checks.append({'check':'emitter does not recompile/renormalize contract','status':'PASS'})
 base=json.loads((root/'inputs/research-config.json').read_text());ip=root/'inputs/contract-ir.json';cp=tmp/'changed.json'
 changed=copy.deepcopy(base);changed['instances']['per_entity']={'ModelsProject':2};cp.write_text(json.dumps(changed));result=emit(ip,cp,tmp/'two-projects');assert len(result['instance_bindings']['ModelsProject'])==2 and len(result['instance_bindings']['ModelsTask'])==2
 checks.append({'check':'per-entity configuration drives child binding counts','status':'PASS'})
 for label,change in [('missing schema block',lambda c:c['missing_information'].update(policy='block')),('unknown config',lambda c:c.update(unimplemented=True)),('unsupported users',lambda c:c['actors'].update(users=2)),('unsupported recovery',lambda c:c['recovery'].update(policy='restore_and_verify'))]:
  cfg=copy.deepcopy(base);change(cfg);cp.write_text(json.dumps(cfg))
  try:emit(ip,cp,tmp/label.replace(' ','-'))
  except ValueError:pass
  else:raise AssertionError('Expected rejection: '+label)
  checks.append({'check':label+' rejected explicitly','status':'PASS'})
 if shutil.which('node'):
  for p in out.rglob('*.js'):subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
  checks.append({'check':'generated JS syntax','js_files':3,'status':'PASS'})
 print(json.dumps({'version':'v071','status':'COMPATIBILITY_PASS','checks':checks,'native_execution':False,'live_execution':False},indent=2))
