import argparse,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'source'))
from input_pipeline import compile_ir,research_config
p=argparse.ArgumentParser();p.add_argument('--contract',type=Path,required=True);p.add_argument('--scope',type=Path,required=True);p.add_argument('--adapter',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--instances',type=int,default=3);p.add_argument('--seed',type=int,default=1);p.add_argument('--profile',choices=['unified','legacy_context'],default='unified');p.add_argument('--name',default='model');p.add_argument('--base-url',required=True);a=p.parse_args()
if a.output.exists():raise SystemExit('Input destination already exists')
ir=compile_ir(a.contract,a.scope,a.adapter);cfg=research_config(a.instances,a.seed,a.profile,a.name,a.base_url);a.output.mkdir(parents=True)
for name,obj in [('contract-ir.json',ir),('research-config.json',cfg)]:
 with (a.output/name).open('w',encoding='utf-8',newline='\n') as f:f.write(json.dumps(obj,indent=2))
print('V071_INPUTS_BUILT',a.output);print('Unresolved input mappings:',len(ir['issues']))
