# Read this first

1. Give Claude CLAUDE_PROMPT_v119.md and this ZIP.
2. Ask it to read RESEARCH_HANDOFF_v119.md completely before suggesting changes.
3. TOOL_INVENTORY_v119.json indexes available historical packages and v103 source files, with hashes. Originals are not included just because they appear in the index.
4. reports/evidence-summary-v119.json contains aggregate facts extracted from supplied reviews and verified against their manifests.
5. tools contains passive/offline code only. No supplied command launches Docker, HTTP test sequences or a native experiment.

## Verify this package after extraction

In PowerShell, from the extracted directory:

```powershell
python .\tools\Verify-Handoff-v119.py .
if ($LASTEXITCODE -ne 0) { throw 'Handoff integrity verification failed.' }
```

## Dependencies and availability

| Item | Role | Available here |
|---|---|---|
| Python 3 standard library | Offline inventory/counter/verifier | Tool source included; interpreter not bundled |
| Windows PowerShell | Researcher's script environment | Not bundled |
| Git | Pinned source/archive continuation | Not bundled |
| Docker Desktop/Linux engine | Local SUT deployment | Not bundled; no operation requested |
| Java/JDK | Provengo runtime | Not bundled |
| Frozen Provengo JAR | Native model execution | Missing here; hash in dossier |
| Vikunja v2.6.0 image | SUT | Not bundled |
| Frozen live contract | IR source | Original inventory/source hash documented; raw file not bundled |
| v103 generic emitter/runtime packages | Historical implementation | Indexed, not bundled |
| v117 static add-on | Independent readback threads | Status/code filenames documented and inventoried; live launcher missing |
| Private DB/files checkpoints | Recovery and exact-prefix continuation | Only on researcher's machine; not bundled or uploaded to Git |

Pinned Git commit from successful user upload: 718a084bf559202193ee036738f081344b92022b.
Snapshot: research/day-v114-20261013-190219-538446.
Repository: https://github.com/weissye/vikunja_tse_study.git.
This handoff did not remotely inspect that repository. The upload confirmation is visible historical evidence. Source should be independently checked before changes.

## Missing/unfinished, not to infer

- No completed v093 overnight result.
- No complete v103 acceptance.
- No three-mode live causal comparison of restart/recovery.
- No positive-error side-effect observations after the three lock failures.
- No minimal causal prefix.
- No completed v117 native/live acceptance package.
- No extension adding multiple NEW updates per session in v117.
- No proof of full entity/action/relationship coverage.
- No proof that interaction modeling caused an incremental semantic-bug discovery.

The public Git snapshot plus this dossier supports source-review continuation. It does not restore the exact live state of either machine.
