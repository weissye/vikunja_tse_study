"""Offline contract-IR catalog. No HTTP, login, scheduling or JS emission."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path


def pointer(path, method):
    return '#/paths/' + path.replace('~', '~0').replace('/', '~1') + '/' + method


def compile_catalog(ir, config):
    entities = ir['entities']
    names = {e['name'] for e in entities}
    candidates, blocked = [], []
    for entity in entities:
        name = entity['name']
        dependencies = entity.get('dependencies', [])
        parents = sorted({d['target'] for d in dependencies})
        unknown = sorted(set(parents) - names)
        if unknown:
            blocked.append({'entity': name, 'reason': 'Missing parent entities', 'parents': unknown})
            continue
        properties = (entity.get('update_schema') or {}).get('properties', {})
        fields = sorted(f for f in entity.get('update_fields', [])
                        if f in properties and not properties[f].get('readOnly'))
        operations = []
        if entity.get('get'):
            operations.append({'role': 'observe', 'method': 'GET', 'path': entity['detail'],
                               'source': pointer(entity['detail'], 'get')})
        if entity.get('update_method') and entity.get('update'):
            operations.append({'role': 'update', 'method': entity['update_method'].upper(),
                               'path': entity['detail'], 'source': pointer(entity['detail'],
                               entity.get('source_update_method', entity['update_method']))})
        if len(operations) != 2:
            blocked.append({'entity': name, 'reason': 'Observable update pair unavailable'})
            continue
        families = [('same_field', (f, f)) for f in fields]
        families += [('disjoint_fields', pair) for pair in itertools.combinations(fields, 2)]
        if parents:
            families += [('parent_child_observation', (f,)) for f in fields]
        for family, pair in families:
            rule = 'UNVERIFIED_SEMANTICS'
            candidate = {
                'entity': name, 'family': family, 'fields': list(pair),
                'operations': operations,
                'affected_resources': [name] + parents,
                'affected_scope': 'Direct resource and declared parents; not proven server effects',
                'preconditions': {'resource_exists': True, 'session_authorized': 'REQUIRES_RUNTIME_VALIDATION',
                                  'parents': parents, 'parent_wait': 'ALL_ORDER_INDEPENDENT'},
                'expectation': {'authority': rule, 'verdict_if_unverified': 'OBSERVATION_ONLY',
                                'reason': 'Schema does not establish update-preservation semantics'},
                'provenance': {'dependencies': dependencies,
                               'field_schemas': {f: properties[f] for f in set(pair)}}
            }
            candidate['id'] = hashlib.sha256(json.dumps(candidate, sort_keys=True).encode()).hexdigest()[:20]
            candidates.append(candidate)
    return {'version': 'v116', 'status': 'STATIC_CATALOG_ONLY',
            'source_sha256': ir['source']['sha256'], 'entity_count': len(entities),
            'candidates': candidates, 'blocked': blocked,
            'research_config_sha256': hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest(),
            'live_execution': False, 'bthreads_emitted': False,
            'limitations': ['Only entities already present in the input IR',
                            'No instance binding, sampling or runtime recovery added',
                            'No semantic oracle inferred from writable-field presence']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ir', type=Path, required=True)
    parser.add_argument('--research-config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = compile_catalog(json.loads(args.ir.read_text(encoding='utf-8-sig')),
                             json.loads(args.research_config.read_text(encoding='utf-8-sig')))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('V116_STATIC_CATALOG_CREATED', len(result['candidates']))


if __name__ == '__main__':
    main()
