"""Verify an extracted documentation package without network access."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
manifest = json.loads((root / 'PACKAGE_MANIFEST_v119.json').read_text(encoding='utf-8'))
for entry in manifest:
    file = (root / entry['path']).resolve()
    if not file.is_relative_to(root) or not file.is_file():
        raise SystemExit('Invalid/missing package file: ' + entry['path'])
    if hashlib.sha256(file.read_bytes()).hexdigest() != entry['sha256']:
        raise SystemExit('Package hash mismatch: ' + entry['path'])
print('V119_HANDOFF_INTEGRITY_PASS', len(manifest))
