"""Read-only acceptance analysis of v117 native logs; does not launch tests."""
import argparse
import json
from collections import Counter
from pathlib import Path


def analyze(plan, log):
    count = plan['planned_readback_audits']
    threads = plan['audit_bthreads']
    if not threads or count % threads:
        raise ValueError('Invalid planned audit counts')
    rounds = count // threads
    expected = {(c['logical_id'], s, n) for c in plan['cases']
                for s in ('A', 'B') for n in range(rounds)}
    if len(expected) != count:
        raise ValueError('Plan has duplicate or inconsistent case counts')
    observed = Counter()
    invalid, excluded, failed = [], 0, False
    for number, line in enumerate(log.splitlines(), 1):
        if any(x in line for x in ('FAIL:', 'Switching to test fail mode',
                                  'Test Fail Mode, skipping actuation')):
            failed = True
        marker = 'CONSISTENCY_AUDIT_COMPLETED '
        if marker not in line:
            continue
        if failed:
            excluded += 1
            continue
        try:
            row, _ = json.JSONDecoder().raw_decode(line.split(marker, 1)[1])
            key = (row['logicalId'], row['session'], row['round'])
            if type(row['round']) is not int or key not in expected:
                raise ValueError('Unplanned completion marker')
            observed[key] += 1
        except (ValueError, KeyError, TypeError) as error:
            invalid.append({'line': number, 'error': str(error)})
    missing = sorted(expected - observed.keys())
    duplicate = [{'key': k, 'count': v} for k, v in observed.items() if v > 1]
    native_success = 'Test Result: SUCCESS' in log and not failed
    complete = not missing and not duplicate and not invalid and native_success
    return {'version': 'v118',
            'status': 'AUDIT_MARKERS_COMPLETE_NATIVE_SUCCESS' if complete else 'NOT_ACCEPTED',
            'planned': len(expected), 'unique_completed_before_failure': len(observed),
            'native_success_marker': native_success, 'failure_detected': failed,
            'missing': missing, 'duplicates': duplicate, 'invalid_markers': invalid,
            'post_failure_markers_excluded': excluded,
            'scope': 'Log marker accounting only; no HTTP or recovery evidence independently verified'}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--plan', type=Path, required=True)
    p.add_argument('--native-log', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    result = analyze(json.loads(a.plan.read_text(encoding='utf-8-sig')),
                     a.native_log.read_text(encoding='utf-8-sig', errors='replace'))
    a.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(result['status'], str(result['unique_completed_before_failure']) + '/' + str(result['planned']))
