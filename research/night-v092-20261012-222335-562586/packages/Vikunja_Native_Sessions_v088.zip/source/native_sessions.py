"""Contract-derived identical behavior templates instantiated for native sessions."""
import json,re

def fields_for(e,c):
 result=[];blocked=[]
 for f,s in e.get('update_schema',{}).get('properties',{}).items():
  s=c.resolve(s)
  reason=None
  if f not in e['update_fields'] or s.get('readOnly'):reason='not writable'
  elif f not in e.get('read_schema',{}).get('properties',{}):reason='not independently observable'
  elif s.get('type')!='string' or s.get('enum') or s.get('format') or s.get('pattern'):reason='unsupported scalar/format/domain constraint'
  elif f in ('id',e['route_field']) or re.search(r'(^created$|^updated$|_at$|_date$|_id$|_hash$)',f):reason='identity/temporal/server metadata candidate'
  if reason:blocked.append({'field':f,'reason':reason})
  else:result.append(f)
 return sorted(result),blocked

def render_sessions(interface,dal,stories,entities,plans,cfg,ir,c):
 if cfg['actors']['shared_workflows']!='derive_from_contract':raise ValueError('Manual workflows are not supported')
 auth=ir['authentication'];report=[]
 # Per-session headers resolve the corresponding runtime token at actuation.
 interface=interface.replace('if(semantic)semantic.actor=RELATION_ACTOR;', '''if(semantic){semantic.session=semantic.session||((semantic.caseId&&/^NEG_[AB]_/.test(semantic.caseId))?semantic.caseId.split("_")[1]:"A");semantic.actor=semantic.session;}''')
 interface=interface.replace('actor:RELATION_ACTOR}', 'actor:semantic.session}')
 interface=interface.replace('url: svc.baseURL + url,','url: nativeSessions[semantic.session].baseURL + url,')
 interface=interface.replace('h["X-SBT-Session"]=semantic.session||"A";', '')
 interface=interface.replace('h["X-SBT-Action"]=semantic.action;', '''h["Authorization"]="Bearer @{TOKEN_"+semantic.session+"}";h["X-SBT-Session"]=semantic.session;h["X-SBT-Action"]=semantic.action;''')
 # Native requestRest wraps transport recovery stages, not model scheduling.
 interface=interface.replace('function requestRest(method, url, body, codes, semantic, callback) {', 'function requestRestRaw(method, url, body, codes, semantic, callback) {')
 interface+='''
function awaitSession(id){while(!ctx.runQuery("Session.Ready").some(function(s){return s.sessionId===id;}))waitFor(bp.EventSet("session ready "+id,function(e){return e.name==="SessionReady"&&e.data.session===id;}));}
function awaitBothSessions(){awaitSession("A");awaitSession("B");}
function requestRest(method,url,body,codes,semantic,callback){
 var sid=semantic.session||((semantic.caseId&&/^NEG_[AB]_/.test(semantic.caseId))?semantic.caseId.split("_")[1]:"A");semantic.session=sid;awaitSession(sid);
 if(semantic.action==="negative_attempt"){
  awaitBothSessions();
  requestRestRaw("POST","/__sbt/checkpoint/"+semantic.caseId,undefined,[200],{action:"checkpoint",logicalId:semantic.logicalId,caseId:semantic.caseId,session:sid},callbackFromSource(""));
  request(bp.Event("SessionsInvalidated",{}));awaitBothSessions();
 }
 var event=requestRestRaw(method,url,body,codes,semantic,callback);
 if(semantic.action==="negative_attempt"){request(bp.Event("SessionsInvalidated",{}));awaitBothSessions();}
 return event;
}
'''
 interface+='var nativeSessions={A:new RESTSession(svc.baseURL,"session-A",{}),B:new RESTSession(svc.baseURL,"session-B",{})};\n'
 loginbody="@{JSON.stringify({username:java.lang.System.getenv('SBT_USERNAME'),password:java.lang.System.getenv('SBT_PASSWORD')})}"
 interface+='function loginSession(id){return sync({request:bp.Event("POST",{lib:"REST",method:"POST",url:nativeSessions[id].baseURL+'+json.dumps(auth['path'])+',headers:{"Content-Type":"application/json","X-SBT-Session":id,"X-SBT-Action":"authenticate"},parameters:{},body:'+json.dumps(loginbody)+',expectedResponseCodes:['+str(auth['status'])+'],model:{action:"authenticate",session:id},callback:callbackFromSource("var value=JSON.parse(response.body);if(!value.'+auth['token_field']+')pvg.fail(\'Token missing\');pvg.rtv.set("+JSON.stringify("TOKEN_"+id)+",value.'+auth['token_field']+');")})});}\n'
 dal+='''
ctx.registerQuery("Session.Ready",function(e){return e.type==="session"&&e.ready;});
ctx.registerEffect("SessionReady",function(d){var id="session_"+d.session;if(ctx.getEntityById&&ctx.getEntityById(id))ctx.removeEntity(id);ctx.insertEntity(ctx.Entity(id,"session",{sessionId:d.session,ready:true}));});
ctx.registerEffect("SessionsInvalidated",function(){ctx.runQuery("Session.Ready").forEach(function(s){ctx.removeEntity(s.id);});});
'''
 # Baseline creates once; no duplicated creates for the second session.
 for e in entities:
  n=e['name']
  stories=re.sub(r'    update'+re.escape(n)+r'\(getModelEntity\([^\n]+\n    waitFor\(matchesVerified\([^\n]+\n','',stories)
  for verb in ('update','verify'):
   pattern=r'(function '+verb+re.escape(n)+r'\(resource)(, delta)?(\) \{)(.*?)(\n\})'
   def patch(m):
    body=m.group(4);body=re.sub(r'(\{action:"(?:prepare|update|read)",)',r'\1session:session||"A",',body)
    # Unique write owner for each session and resource revision.
    body=body.replace('var owner=resource.id+', 'var owner=(session||"A")+"_"+resource.id+')
    body=body.replace('{logicalId:resource.id,owner:owner,revision:', '{logicalId:resource.id,session:session||"A",owner:owner,revision:')
    return m.group(1)+(m.group(2) or '')+', session'+m.group(3)+body+m.group(5)
   interface=re.sub(pattern,patch,interface,flags=re.S)
  fields,blocked=fields_for(e,c)
  for binding in plans[n]:
   logical=binding['id']
   for sid in ('A','B'):
    case='WORK_'+sid+'_'+logical
    report.append({'case_id':case,'logical_id':logical,'session':sid,'entity':n,'fields':fields,'blocked_fields':blocked})
    stories+='\nbthread('+json.dumps(case)+',function(){\n awaitSession('+json.dumps(sid)+');waitForResource('+json.dumps(logical)+',1);\n'
    for f in fields:
     # Unique strings distinct across session and resource, respecting maxLength.
     value='sbt-'+sid+'-'+logical+'-'+f
     maximum=c.resolve(e['update_schema']['properties'][f]).get('maxLength')
     if maximum:value=value[:maximum]
     stories+=' request(bp.Event("OperationAcquire",{logicalId:'+json.dumps(logical)+',session:'+json.dumps(sid)+'}));\n var resource=getModelEntity('+json.dumps(logical)+');var revision=resource.revision+1;\n'
     stories+=' update'+n+'(resource,'+json.dumps({f:value})+','+json.dumps(sid)+');waitFor(matchesVerified('+json.dumps(logical)+',revision));\n'
     stories+=' request(bp.Event("OperationRelease",{logicalId:'+json.dumps(logical)+',session:'+json.dumps(sid)+'}));\n'
    # Independent peer reader has its OWN observation window; no whole-story lock.
    stories+=' request(bp.Event("OperationAcquire",{logicalId:'+json.dumps(logical)+',session:'+json.dumps(sid)+'}));\n verify'+n+'(getModelEntity('+json.dumps(logical)+'),'+json.dumps(sid)+');\n'
    stories+=' request(bp.Event("OperationRelease",{logicalId:'+json.dumps(logical)+',session:'+json.dumps(sid)+'}));\n'
    stories+=' bp.log.info("SESSION_WORKFLOW_COMPLETE "+JSON.stringify({caseId:'+json.dumps(case)+',logicalId:'+json.dumps(logical)+',session:'+json.dumps(sid)+'}));\n});\n'
 # Instantiate each generated negative-test bthread once per session; verifier
 # templates remain single and operate on the shared resource Context.
 pattern=r'bthread\("negative NEG_[^\n]+\n.*?\n\}\);'
 stories=re.sub(pattern,lambda m:'\n'.join(m.group(0).replace('NEG_','NEG_'+sid+'_') for sid in ('A','B')),stories,flags=re.S)
 for sid in ('A','B'):
  stories+='\nbthread("native login '+sid+'",function(){while(true){loginSession("'+sid+'");request(bp.Event("SessionReady",{session:"'+sid+'"}));waitFor(bp.Event("SessionsInvalidated",{}));}});\n'
 stories+='''
bthread("native session readiness and restart gate",function(){
 var ready={},pending=false,windowCase=null;
 while(true){var e=sync({waitFor:bp.all,block:bp.EventSet("requires ready session",function(event){
  var m=event.data&&event.data.model;if(!m)return false;if(m.action==="authenticate")return false;
  if(pending)return true;if(windowCase)return !(ready.A&&ready.B&&m.caseId===windowCase&&(m.action==="negative_attempt"||m.action==="negative_readback"));return !ready[m.session||((m.caseId&&/^NEG_[AB]_/.test(m.caseId))?m.caseId.split("_")[1]:"A")];
 })});var d=e.data||{};
 if(e.name==="SessionsInvalidated"){ready={};pending=false;}
 if(e.name==="SessionReady")ready[d.session]=true;
 if(d.model&&d.model.action==="checkpoint"){windowCase=d.model.caseId;pending=true;}
 if(d.model&&d.model.action==="negative_attempt")pending=true;
 if(d.model&&d.model.action==="negative_readback"&&d.model.caseId===windowCase)windowCase=null;
 }
});
bthread("per-operation shared resource windows",function(){
 var locks={},positive={},negative={};
 while(true){var e=sync({waitFor:bp.all,block:bp.EventSet("operation conflicts",function(event){
  var d=event.data||{},m=d.model;
  if(event.name==="OperationAcquire")return !!locks[d.logicalId]||!!positive[d.logicalId]||!!negative[d.logicalId];
  if(event.name==="NegativeAcquire")return !!locks[d.logicalId];
  if(event.name==="ModelWriteBegin")return !!locks[d.logicalId]&&locks[d.logicalId]!==d.session;
  if(!m||["create","update","delete","negative_attempt"].indexOf(m.action)<0)return false;
  var ids=(m.affected||[]).slice();if(m.logicalId)ids.push(m.logicalId);return ids.some(function(id){return !!locks[id]&&locks[id]!==m.session;});
 })});var d=e.data||{};
 if(e.name==="OperationAcquire")locks[d.logicalId]=d.session;
 if(e.name==="OperationRelease"&&locks[d.logicalId]===d.session)delete locks[d.logicalId];
 if(e.name==="ModelWriteBegin")positive[d.logicalId]=d.revision;
 if(e.name==="ModelVerified"&&positive[d.logicalId]===d.revision)delete positive[d.logicalId];
 if(e.name==="NegativeAcquire")negative[d.logicalId]=d.caseId;
 if(e.name==="NegativeRelease"&&negative[d.logicalId]===d.caseId)delete negative[d.logicalId];
 }
});
'''
 return interface,dal,stories,report
